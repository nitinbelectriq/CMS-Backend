module.exports = {
  secret: 'belectriqcmssecretkey123344'
};