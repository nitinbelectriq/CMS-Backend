var PaytmConfig = {
  mid: "ZbeeSt63143763389791",
  key: "&I7c@L7z0l%8v9Ye",
  callbackUrl: "https://securegw-stage.paytm.in/theia/paytmCallback?",
  host : 'securegw-stage.paytm.in'
};



var SpinImageConfig = {
  ChargerImagePath : "D:\\temp\\fileupload",
  ChargerVirtualPath : "imagebank\\spin\\renewalrequests\\",
  ImageBankPath : "http://imagebank//"
};
module.exports.PaytmConfig = PaytmConfig;
module.exports.SpinImageConfig = SpinImageConfig;