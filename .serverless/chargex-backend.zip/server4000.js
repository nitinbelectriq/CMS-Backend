const express = require("express");

const bodyParser = require("body-parser");
var cors = require('cors');
const nocache = require("nocache");

// ...

//swagger==================

const swaggerJsDoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const swaggerOptions={
  swaggerDefinition:{
    info:{
      title:'CMS APi',
      description : 'description CMS API',
      contact : {
        name : 'EXICOM'
      },
      servers : [
        {url:"http://localhost:4000"}
      ]
    }
  },
  // apis : ['server4000.js']
  apis : ["./routes/*.js"]
}


const swaggerDocs = swaggerJsDoc(swaggerOptions);


//swagger==================

const app = express();
app.use(nocache());

//swagger start ==================
app.use('/swagger',swaggerUi.serve,swaggerUi.setup(swaggerDocs));
//swagger end==================






var port = process.env.PORT || 4000;

var whitelist = ['http://localhost:5300','http://localhost:3000']
var corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) !== -1) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  }
}

app.use(cors());


// parse requests of content-type: application/json
app.use(bodyParser.json());

// parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// simple route
app.get("/", (req, res) => {
  
  res.json({ message: "Welcome to the CMS application." });
});

require("./app/routes/customer.routes.js")(app);
require("./app/routes/brand.routes.js")(app);
require("./app/routes/vehicle.routes.js")(app);
require("./app/routes/charger.routes.js")(app);
require("./app/routes/connector.routes.js")(app);
require("./app/routes/client.routes.js")(app);
require("./app/routes/cpo.routes.js")(app);
require("./app/routes/charging-station.routes.js")(app);
require("./app/routes/charging-model.routes.js")(app);
require("./app/routes/current-type.routes.js")(app);
require("./app/routes/io-type.routes.js")(app);
require("./app/routes/manufacturer.routes.js")(app);
require("./app/routes/communication-protocol.routes.js")(app);
require("./app/routes/charger-model-type.routes")(app);
require("./app/routes/login.routes")(app);
require("./app/routes/charger-type.routes.js")(app);
require("./app/routes/charger-batch.routes.js")(app);
require("./app/routes/version.routes.js")(app);
require("./app/routes/charger-monitoring.routes.js")(app);
require("./app/routes/rf-id.routes.js")(app);
require("./app/routes/user-management.routes.js")(app);
require("./app/routes/role-management.routes.js")(app);
require("./app/routes/master.routes.js")(app);
require("./app/routes/alexa.routes")(app);
require("./app/routes/sub-client.routes.js")(app);
require("./app/routes/analytics.routes")(app);
require("./app/routes/call_back_request.routes")(app);

require("./app/routes/error_log.routes.js")(app);


// set port, listen for requests
app.listen(port, () => {
    console.log(`App running on port ${port}.`)
  })

 module.exports = app;

  