const { sql, pool } = require("./db.js");
const _utility = require("../utility/_utility");
const charger = require("../models/charger.model");

const LoginUser = function (loginuser) {
  this.User_Name = loginuser.User_Name;
  this.User_Password = loginuser.User_Password;
};

const User = function (user) {
  this.id = user.id;
  this.code = user.code;
  this.username = user.username;
  this.password = user.password;
  this.f_Name = user.f_Name;
  this.m_Name = user.m_Name;
  this.l_Name = user.l_Name;
  this.dob = user.dob;
  this.mobile = user.mobile;
  this.alt_mobile = user.alt_mobile;
  this.email = user.email;
  this.address1 = user.address1;
  this.address2 = user.address2;
  this.PIN = user.PIN;
  this.landmark = user.landmark;
  this.city_id = user.city_id;
  this.state_id = user.state_id;
  this.country_id = user.country_id;
  this.PAN = user.PAN;
  this.aadhar = user.aadhar;
  this.device_id = user.device_id;
  this.app_version = user.app_version;
  this.os_version = user.os_version;
  this.user_type = user.user_type;
  this.client_id = user.client_id;
  this.can_expire = user.can_expire;
  this.hint_question = user.hint_question;
  this.hint_answer = user.hint_answer;
  this.last_pass_change = user.last_pass_change;
  this.last_login_date = user.last_login_date;
  this.employee_code = user.employee_code;
  this.is_verified = user.is_verified;
  this.otp = user.otp;
  this.registration_origin = user.registration_origin;
  this.project_code = user.project_code;
  this.status = user.status;
  this.created_date = user.created_date;
  this.created_by = user.created_by;
  this.modify_date = user.modify_date;
  this.modify_by = user.modify_by;
};

LoginUser.findByUsername = (User_Name, result) => {

  sql.query(`SELECT  Id,UserName,Password,client_id,f_Name,l_Name,mobile,email ,user_type,is_verified
    FROM user_mst_new WHERE UserName =? `, User_Name, (err, res) => {

    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }
    result({ kind: "not_found" }, null);
  });
};

//forgotpassword
User.forgotpassword = async (newUser, result) => {
  let final_result;
  var datetime = new Date();
  let otp = await _utility.generateOTP();

  let stmt = `update user_mst_new set 
      otp = '${otp}',is_verified = 'N' 
      where mobile = '${newUser.mobile}' and status = 'Y' `;

  sql.query(stmt, async (err, res) => {

    if (err) {
      result(err, null);
      return;
    }
    let response_send_otp = await _utility.sendOTP('FORGOT_PASSWORD',otp, newUser.mobile, newUser.email);
    if (response_send_otp.message.INFO == "SUBMITTED") {
      final_result = {
        status: true,
        message: 'Please verify user with OTP sent'
      }
    } else {
      final_result = {
        status: false,
        message: 'Please retry'
      }
    }

    result(null, final_result);
  });
};

//forgotpassword
User.Webforgotpassword = async (newUser, result) => {
  let final_result;
  var datetime = new Date();

  let genPass = await _utility.generatePassword();

  let stmt = `update user_mst_new set 
    password = '${genPass}'
    where username = '${newUser.username}' and status = 'Y' `;

  sql.query(stmt, async (err, res) => {
    if (err) {
      result(err, null);
      return;
    }
    let response_send_otp = await _utility.sendOTP('FORGOT_PASSWORD',otp, newUser.mobile, newUser.email);
    if (response_send_otp.message.INFO == "SUBMITTED") {
      final_result = {
        status: true,
        message: 'User OTP successfully. Please verify user with OTP sent'
      }
    } else {
      final_result = {
        status: false,
        message: 'Please retry'
      }
    }

    result(null, final_result);
  });
};

User.updatepassword = (newUser, result) => {

  let final_result;
  var datetime = new Date();

  let stmt = `update user_mst_new set 
        password = '${newUser.password}',registration_origin = '${newUser.registration_origin}',     
        modifyby = ${newUser.modify_by},modify_date = '${datetime.toISOString().slice(0, 10)}' 
        where id=  ${newUser.id} and status = 'Y'`;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }
    final_result = {
      status: true,
      message: 'User password updated successfully.'
    }

    result(null, final_result);
  });
};

User.register = async (newUser, result) => {
  let final_res;
  var datetime = new Date();

  let otp = await _utility.generateOTP();
  let stmt = `insert into user_mst_new (code  ,username  ,password  ,f_Name  ,m_Name  ,l_Name  ,
        dob  ,mobile  ,alt_mobile  ,
        email,device_id,app_version,os_version,
        user_type  ,client_id  ,can_expire  ,hint_question  ,
        hint_answer ,employee_code  ,is_verified ,otp ,registration_origin  ,
        address1  ,address2  ,PIN  ,landmark  ,city_id ,state_id ,country_id ,
        status,created_date,createdby )
      VALUES ('${newUser.code}','${newUser.username}','${newUser.password}','${newUser.f_Name}','${newUser.m_Name}','${newUser.l_Name}',
      '${newUser.dob}','${newUser.mobile}','${newUser.alt_mobile}',
      '${newUser.email}','${newUser.device_id}','${newUser.app_version}','${newUser.os_version}',
      '${newUser.user_type}',${newUser.client_id},'${newUser.can_expire}',${newUser.hint_question},
      '${newUser.hint_answer}','${newUser.employee_code}','N','${otp}','${newUser.registration_origin}',
      '${newUser.address1}','${newUser.address2}',${newUser.PIN},'${newUser.landmark}',${newUser.city_id},${newUser.state_id},${newUser.country_id},
      '${newUser.status}','${datetime.toISOString().slice(0, 10)}',${newUser.created_by}) `;

  let resp;
  try {
    resp = await pool.query(stmt);
    final_res = {
      status: true,
      message: 'SUCCESS',
      data: [{
        id: resp.insertId
      }]
    }

    let response_send_otp = await _utility.sendOTP('REGISTER',otp, newUser.mobile, newUser.email);

  } catch (err) {
    final_res = {
      status: false,
      message: `ERROR : ${err.code}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }
};

User.getOTP = async (newUser, result) => {
  let final_res;
  var datetime = new Date();

  let otp = await _utility.generateOTP();
  let stmt = `update  user_mst_new set otp = ${otp} where id = ${newUser.id} `;

  let resp;
  try {
    resp = await pool.query(stmt);

    let response_send_otp = await _utility.sendOTP('RESEND',otp, newUser.mobile, newUser.email);

    if (response_send_otp.message.INFO == "SUBMITTED") {
      final_res = {
        status: true,
        message: 'OTP sent successfully.'
      }
    } else {
      final_res = {
        status: false,
        message: 'Please retry'
      }
    }
  } catch (err) {
    final_res = {
      status: false,
      message: `ERROR : ${err.code}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }
};

User.getOTPAnonymous = async (newUser, result) => {
  
  let final_res;
  var datetime = new Date();

  let otp = await _utility.generateOTP();
  // let stmt = `update  user_mst_new set otp = ${otp} where id = ${newUser.id} `;

  let resp;
  try {
    // resp = await pool.query(stmt);

    let response_send_otp = await _utility.sendOTP('OTP_FOR_ANONYMOUS',otp, newUser.mobile, newUser.email);

    if (response_send_otp.message.INFO == "SUBMITTED") {
      final_res = {
        status: true,
        message: 'OTP sent successfully.'
      }
    } else {
      final_res = {
        status: false,
        message: 'Please retry'
      }
    }
  } catch (err) {
    final_res = {
      status: false,
      message: `ERROR : ${err.code}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }
};


User.verifyUser = async (newUser, result) => {
  let final_result;
  var datetime = new Date();
  let user_id;

  let stmt = `select otp,id from user_mst_new where 
    mobile = '${newUser.mobile}' and status = 'Y' order by id desc limit 1`;

  sql.query(stmt, async (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    user_id = res[0].id;
    if (newUser.otp != res[0].otp) {
      final_result = {
        status: false,
        message: 'Wrong OTP.'
      }
      result(null, final_result);
      return;
    }
    let stmt = `update user_mst_new set 
      is_verified = 'Y' 
      where mobile = '${newUser.mobile}' and status = 'Y'`;

    sql.query(stmt, async (err, res) => {
      if (err) {
        result(err, null);
        return;
      }

      final_result = {
        status: true,
        message: 'User verified successfully.',
        data: {
          user_id: user_id
        }
      }
      result(null, final_result);
    });
  });
};

module.exports = { LoginUser, User };