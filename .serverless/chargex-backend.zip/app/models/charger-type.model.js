const {sql,pool} = require("./db.js");

const ChargerType = function(chargerType) {
  this.id = chargerType.id ,
  this.name = chargerType.name ,
  this.description = chargerType.description,
  this.status = chargerType.status ,
  this.created_date = chargerType.created_date ,
  this.created_by = chargerType.created_by,
  this.modify_date = chargerType.modify_date ,
  this.modify_by = chargerType.modify_by
};

ChargerType.create = (newCharger, result) => {
  var datetime = new Date();

  let stmt = `insert into charger_type_mst (name,description,status,created_date,createdby )
    VALUES ('${newCharger.name}','${newCharger.description}',
    '${newCharger.status}','${datetime.toISOString().slice(0,10)}',${newCharger.created_by}) `;

  let todo = newCharger;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newCharger });
  });
};

ChargerType.update = (newCharger, result) => {
  var datetime = new Date();

  let stmt = `update charger_type_mst set 
  name = '${newCharger.name}',description = '${newCharger.description}',status = '${newCharger.status}',
  modifyby = ${newCharger.modify_by},modify_date = '${datetime.toISOString().slice(0,10)}' 
  where id =  ${newCharger.id}`;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newCharger });
  });
};




ChargerType.getChargerTypes = result => {

    let stmt = `select id,  name,description,status,created_date,createdby,modifyby,modify_date
      from charger_type_mst
      where status <> 'D'
      order by id desc`;

      sql.query(stmt, (err, res) => {
          if (err) {
            result(err, null);
            return;
          }

          if (res.length) {
            result(null, res);
            return;
          }

          result({ kind: "not_found" }, null);
        });
  };

ChargerType.getActiveChargerTypes =async( result) => {

  let final_res;
    let resp;
    
    let stmt = `select id,  name,description,status,created_date,createdby,modifyby,modify_date
      from charger_type_mst
      where status = 'Y'
      order by id desc`;

      try {
        
        resp = await pool.query(stmt);
    
        final_res = {
          status: resp.length > 0 ? true : false,
          err_code: `ERROR : 0`,
          message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
          count: resp.length,
          data: resp
        }
      } catch (err) {
        
        final_res = {
          status: false,
          err_code: `ERROR : ${err.code}`,
          message: `ERROR : ${err.message}`,
          count: 0,
          data: []
        }
      } finally {
        result(null, final_res);
      }
    

      // sql.query(stmt, (err, res) => {
      //     if (err) {
      //       result(err, null);
      //       return;
      //     }

      //     if (res.length) {
      //       result(null, res);
      //       return;
      //     }

      //     result({ kind: "not_found" }, null);
      //   });
  };

  ChargerType.getChargerTypeById = (id, result) => {

    let stmt = `select id,  name,description,status,created_date,createdby,modifyby,modify_date
      from charger_type_mst
      WHERE id = ?`;
    sql.query(stmt, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
  
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
  
      result(null, res);
    });
  };

  ChargerType.delete = (id, result) => {

    let stmt = `Update charger_type_mst set status = 'D' WHERE id = ?`;
    sql.query(stmt, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
  
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
  
      result(null, res);
    });
  };

module.exports = {
  ChargerType: ChargerType
};