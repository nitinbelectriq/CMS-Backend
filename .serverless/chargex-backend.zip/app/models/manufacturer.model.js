const {sql,pool} = require("./db.js");


// constructor
const Manufacturer = function (manufacturer) {
    this.id = manufacturer.id,
    this.name = manufacturer.name;
    this.description = manufacturer.description;
    this.status = manufacturer.status;
    this.created_date = manufacturer.created_date;
    this.createdby = manufacturer.createdby;
    this.modify_date = manufacturer.modify_date;
    this.modifyby = manufacturer.modifyby;
};


Manufacturer.getManufacturers = result => {
    sql.query(`select id,  name,description,status,created_date,createdby
        from manufacturer_mst where status <> 'D' order by id desc `, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        result(null, res);
    });
};


module.exports = Manufacturer;