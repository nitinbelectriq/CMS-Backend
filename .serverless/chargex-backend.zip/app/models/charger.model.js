const { sql, pool } = require("./db.js");

// constructor
const Charger = function (charger) {
  this.id = charger.id,
    this.name = charger.name,
    this.serial_no = charger.serial_no,
    this.batch_id = charger.batch_id,
    this.station_id = charger.station_id,
    this.model_id = charger.model_id,
    this.current_version_id = charger.current_version_id,
    this.no_of_guns = charger.no_of_guns,
    this.address1 = charger.address1;
  this.address2 = charger.address2;
  this.PIN = charger.PIN;
  this.landmark = charger.landmark;
  this.city_id = charger.city_id;
  this.state_id = charger.state_id;
  this.country_id = charger.country_id;
  this.Lat = charger.Lat,
    this.Lng = charger.Lng,
    this.OTA_Config = charger.OTA_Config,
    this.Periodic_Check_Ref_Time = charger.Periodic_Check_Ref_Time,
    this.Periodicity_in_hours = charger.Periodicity_in_hours,
    this.When_to_Upgrade = charger.When_to_Upgrade,
    this.Upgrade_Specific_Time = charger.Upgrade_Specific_Time,
    this.is_available = charger.is_available,
    this.status = charger.status,
    this.created_date = charger.created_date,
    this.created_by = charger.created_by,
    this.modify_date = charger.modify_date,
    this.modify_by = charger.modify_by,
    this.connector_data = charger.connector_data
};

const ChargerStationMap = function (chargerStationMap) {
  this.id = chargerStationMap.id,
    this.charger_id = chargerStationMap.charger_id,
    this.station_id = chargerStationMap.station_id,
    this.is_available = chargerStationMap.is_available,
    this.status = chargerStationMap.status,
    this.created_date = chargerStationMap.created_date,
    this.created_by = chargerStationMap.created_by,
    this.modify_date = chargerStationMap.modify_date,
    this.modify_by = chargerStationMap.modify_by,
    this.charger_data = chargerStationMap.charger_data
};

const ClientChargerMap = function (clientChargerMap) {
  this.id = clientChargerMap.id,
    this.charger_id = clientChargerMap.charger_id,
    this.client_id = clientChargerMap.client_id,
    this.sub_client_id = clientChargerMap.sub_client_id,
    this.dispatch_status = clientChargerMap.dispatch_status,
    this.dispatch_by = clientChargerMap.dispatch_by,
    this.dispatch_date = clientChargerMap.dispatch_date,
    this.status = clientChargerMap.status,
    this.created_date = clientChargerMap.created_date,
    this.created_by = clientChargerMap.created_by,
    this.modify_date = clientChargerMap.modify_date,
    this.modify_by = clientChargerMap.modify_by,
    this.charger_data = clientChargerMap.charger_data

};

const _TABLE = 'charger_serial_mst';

Charger.create = async (newCharger, result) => {
  var datetime = new Date();
  let stmt = `insert into ${_TABLE} (serial_no,name,model_id,station_id,
    current_version_id,no_of_guns,Lat,Lng,
    OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
    When_to_Upgrade,Upgrade_Specific_Time,is_available,
    address1  ,address2  ,PIN  ,landmark  ,city_id ,state_id ,country_id ,
    status,created_date,createdby )
    VALUES ('${newCharger.serial_no}','${newCharger.name}',${newCharger.model_id},${newCharger.station_id},
    ${newCharger.current_version_id},${newCharger.no_of_guns},${newCharger.Lat},${newCharger.Lng},
    '${newCharger.OTA_Config}','${newCharger.Periodic_Check_Ref_Time}',${newCharger.Periodicity_in_hours},
    '${newCharger.When_to_Upgrade}','${newCharger.Upgrade_Specific_Time}',${newCharger.is_available},
    '${newCharger.address1}','${newCharger.address2}',${newCharger.PIN},'${newCharger.landmark}',${newCharger.city_id},${newCharger.state_id},${newCharger.country_id},
    '${newCharger.status}','${datetime.toISOString().slice(0, 10)}',${newCharger.created_by}) `;
  
  let final_res;
  let resp;
  try {
    resp = await pool.query(stmt);
    final_res = {
      status: true,
      message: 'SUCCESS',
      data: [{
        id: resp
      }]
    }
    await insertModelConnector(newCharger.connector_data, resp.insertId, newCharger.name, newCharger.created_by);
  } catch (err) {
    final_res = {
      status: false,
      message: `ERROR : ${err.code}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

Charger.update = async (newCharger, result) => {
  var datetime = new Date();

  let stmt = `update ${_TABLE} set 
  serial_no = '${newCharger.serial_no}', name = '${newCharger.name}',
  model_id = ${newCharger.model_id},station_id = ${newCharger.station_id}, 
  current_version_id = ${newCharger.current_version_id} ,no_of_guns = ${newCharger.no_of_guns},
  Lat = ${newCharger.Lat}, Lng = ${newCharger.Lng},OTA_Config = '${newCharger.OTA_Config}',
  Periodic_Check_Ref_Time = '${newCharger.Periodic_Check_Ref_Time}',Periodicity_in_hours = ${newCharger.Periodicity_in_hours},
  When_to_Upgrade = '${newCharger.When_to_Upgrade}',Upgrade_Specific_Time = '${newCharger.Upgrade_Specific_Time}',
  is_available = ${newCharger.is_available},address1='${newCharger.address1}'  ,
  address2 ='${newCharger.address2}' ,PIN =${newCharger.PIN} ,landmark ='${newCharger.landmark}' ,
  city_id=${newCharger.city_id} ,state_id=${newCharger.state_id} ,country_id=${newCharger.country_id} ,
  status = '${newCharger.status}',modifyby = ${newCharger.modify_by},modify_date = '${datetime.toISOString().slice(0, 10)}' 
  where id =  ${newCharger.id}`;
  let final_res;
  let resp;
  try {
    resp = await pool.query(stmt);
    final_res = {
      status: true,
      message: 'SUCCESS',
      data: [{
        id: resp
      }]
    }
    await insertModelConnector(newCharger.connector_data, newCharger.id, newCharger.name, newCharger.modify_by);
  } catch (err) {
    final_res = {
      status: false,
      message: `ERROR : ${err.code}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

ClientChargerMap.dispatchChargers = async (data, result) => {
  var datetime = new Date();
  let final_res;
  let resp3;
  let chargers_mapped = [];
  let chargers_not_mapped = [];

  let stmt2 = `insert into client_charger_mapping (client_id,sub_client_id,charger_id,
  dispatch_status,dispatch_by,dispatch_date,
  status,createdby,created_date)
  values ? `;

  let stmt3 = `select id from client_charger_mapping 
    where charger_id = ? and status <>'D'`;

  let values = [];
  try {

    for (let index = 0; index < data.charger_data.length; index++) {

      resp3 = await pool.query(stmt3, [data.charger_data[index].id])

      if (resp3.length > 0) {
        chargers_not_mapped.push({
          id: data.charger_data[index].id,
          serial_no: data.charger_data[index].serial_no,
          remarks: 'DUPLICATE'
        })

      } else {
        values.push([data.client_id, data.sub_client_id, data.charger_data[index].id,
        data.dispatch_status, data.dispatch_by, data.dispatch_date,
        data.status, data.created_by, datetime])

        chargers_mapped.push({
          id: data.charger_data[index].id,
          serial_no: data.charger_data[index].serial_no,
          remarks: 'SUCCESS'
        })

      }
    }

    // resp = await pool.query(stmt);

    if (values.length > 0) {
      resp2 = await pool.query(stmt2, [values]);
    } else {
    }

    final_res = {
      status: values.length > 0 ? true : false,
      message: values.length > 0 ? 'SUCCESS' : 'ALL_DUPLICATE',
      data: [{
        chargers_not_mapped: chargers_not_mapped,
        chargers_mapped: chargers_mapped
      }]
    }
  } catch (err) {
    final_res = {
      status: false,
      message: `ERROR : ${err.code}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

ClientChargerMap.updateClientChargers = async (data, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt3 = `select id from client_charger_mapping 
    where charger_id = ? and status <>'D'`;

  let stmt = `update client_charger_mapping
    set dispatch_date = ? , status = ?,
    modifyby = ?,modify_date = ? 
    where id = ? `;

  try {
    resp3 = await pool.query(stmt3, [data.id])

    if (resp3.length > 0) {
      final_res = {
        status: false,
        message: 'DUPLICATE',
        data: []
      }
    } else {
      resp = await pool.query(stmt, [data.dispatch_date, data.status, data.modify_by, datetime, data.id]);

      final_res = {
        status: true,
        message: 'SUCCESS',
        data: []
      }

    }

  } catch (err) {
    final_res = {
      status: false,
      message: `ERROR : ${err.code}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

ChargerStationMap.addChargerToStation = (newCharger, result) => {
  var datetime = new Date();

  let stmt = `insert into charger_station_mapping (charger_id,station_id,
    status,created_date,createdby )
    VALUES (${newCharger.charger_id},${newCharger.station_id},
    '${newCharger.status}','${datetime.toISOString().slice(0, 10)}',${newCharger.created_by}) `;
  ;
  sql.query(stmt, async (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    let final_result = await updateChargerAddress(newCharger.charger_id, newCharger.station_id, newCharger.created_by)

    result(null, { id: res.insertId, ...newCharger });
  });
};

ChargerStationMap.addChargerToStationMultiple = async (data, result) => {
  // var datetime = new Date();

  // let stmt = `insert into charger_station_mapping (charger_id,station_id,
  //   status,created_date,createdby )
  //   VALUES (${newCharger.charger_id},${newCharger.station_id},
  //   '${newCharger.status}','${datetime.toISOString().slice(0, 10)}',${newCharger.created_by}) `;

  // sql.query(stmt, async (err, res) => {
  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   //let final_result = await updateChargerAddress(newCharger.charger_id, newCharger.station_id, newCharger.created_by)

  //   result(null, { id: res.insertId, ...newCharger });
  // });

  //===============================
  var datetime = new Date();
  let final_res;
  let resp3;
  let chargers_mapped = [];
  let chargers_not_mapped = [];

  let stmt2 = `insert into charger_station_mapping (station_id,charger_id,
  status,created_date,createdby)
  values ? `;

  let stmt3 = `select id from charger_station_mapping 
  where charger_id = ? and status <>'D'`;

  let values = [];
  try {
    
    for (let index = 0; index < data.charger_data.length; index++) {

      
      resp3 = await pool.query(stmt3, [data.charger_data[index].charger_id])
      
      if (resp3.length > 0) {
        chargers_not_mapped.push({
          charger_id: data.charger_data[index].charger_id,
          serial_no: data.charger_data[index].serial_no,
          remarks: 'DUPLICATE'
        })

      } else {
        values.push([data.station_id, data.charger_data[index].charger_id,
        data.status, datetime, data.created_by])

        chargers_mapped.push({
          charger_id: data.charger_data[index].charger_id,
          serial_no: data.charger_data[index].serial_no,
          remarks: 'SUCCESS'
        })

      }
    }

    // resp = await pool.query(stmt);
    
    if (values.length > 0) {

      resp2 = await pool.query(stmt2, [values]);
    } else {
    }

    final_res = {
      status: values.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: values.length > 0 ? 'SUCCESS' : 'ALL_DUPLICATE',
      data: [{
        chargers_not_mapped: chargers_not_mapped,
        chargers_mapped: chargers_mapped
      }]
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};


ChargerStationMap.removeChargerFromStation = async (newCharger, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt = `update charger_station_mapping set status = 'D',
  modifyby = ${newCharger.modify_by}, modify_date = ?
  where id = ${newCharger.id} `;

  try {
    resp = await pool.query(stmt, [datetime]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.affectedRows > 0 ? 'SUCCESS' : 'FAILED',
      data: []
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

  // sql.query(stmt, [datetime], (err, res) => {
  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   result(null, { id: res.insertId, ...newCharger });
  // });
};

Charger.getChargers = async result => {
  let resp = await func_getChargers();
  result(null, resp);
};

Charger.getPlantChargers = result => {

  let stmt = `select csm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
   csm.model_id,cmm.name as model_name , 
  csm.current_version_id, vm.name as version_name , csm.no_of_guns,
  csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
  csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
  When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
  csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date
  from ${_TABLE}  csm inner join version_mst vm on csm.current_version_id = vm.id
  left join city_mst city on csm.city_id = city.id
  left join state_mst sm on csm.state_id = sm.id
  left join country_mst country on csm.country_id = country.id
  
  inner join charging_model_mst cmm on csm.model_id = cmm.id  and cmm.status='Y'
  where csm.id not in (select charger_id from client_charger_mapping where charger_id is not null and status <> 'D' ) 
  and csm.status <> 'D' 
  order by csm.id desc;`;
  

  sql.query(stmt, async (err, res) => {

    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      let children = await getMappedConnectors();

      let final_res = res;

      for (let p = 0; p < res.length; p++) {
        const parent = res[p];
        final_res[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];

          if (parent.id == child.charger_id) {
            final_res[p].connector_data.push(child);
          }
        }
      }

      result(null, final_res);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

Charger.getClientChargers = (userDetails, result) => {
  let stmt = ` select ccm.charger_id,ccm.client_id,ccm.dispatch_date,ccm.dispatch_by,ccm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
   csm.model_id,cmm.name as model_name  ,csmap.station_id ,
  cm.id as client_id,cm.name as client_name,
  chsm.name as station_name ,csm.current_version_id, vm.name as version_name , csm.no_of_guns,
  csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
  csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
  When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
  ccm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date
  from ${_TABLE} csm inner join version_mst vm on csm.current_version_id = vm.id
  inner join charging_model_mst cmm on csm.model_id = cmm.id
  inner join client_charger_mapping ccm on csm.id = ccm.charger_id and ccm.status<>'D'
  inner join client_mst cm on ccm.client_id = cm.id and cm.status='Y'
  left join city_mst city on csm.city_id = city.id
  left join state_mst sm on csm.state_id = sm.id
  left join country_mst country on csm.country_id = country.id
  left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status <>'D'
  left join charging_station_mst chsm on csmap.station_id = chsm.id
  where csm.status <> 'D'  
  order by csm.id desc;`;
  

  sql.query(stmt, async (err, res) => {

    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      let children = await getMappedConnectors();
      let final_res = res;

      for (let p = 0; p < res.length; p++) {
        const parent = res[p];
        final_res[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];

          if (parent.id == child.charger_id) {
            final_res[p].connector_data.push(child);
          }

        }

      }


      result(null, final_res);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

Charger.getClientChargersNotMappedToAnyStation = async (client_id, result) => {

  let final_res;
  let resp;

  let stmt = `select ccm.charger_id, csm.serial_no, csm.name	as charger_display_id
  from client_charger_mapping ccm
  inner join charger_serial_mst csm on ccm.charger_id=csm.id and csm.status='Y'
  where ccm.status='Y' and ccm.client_id = ${client_id}
  and ccm.charger_id not in (select charger_id from charger_station_mapping where status<>'D')  
  order by csm.id desc; `;

  try {

    // resp = await pool.query(stmt);
    

    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count: resp.length,
      data: resp
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }




  // let stmt = ` select ccm.charger_id,ccm.client_id,ccm.dispatch_date,ccm.dispatch_by,ccm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
  //  csm.model_id,cmm.name as model_name  ,csmap.station_id ,
  // cm.id as client_id,cm.name as client_name,
  // chsm.name as station_name ,csm.current_version_id, vm.name as version_name , csm.no_of_guns,
  // csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
  // csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  // csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
  // When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
  // ccm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date
  // from  ${_TABLE} csm inner join version_mst vm on csm.current_version_id = vm.id
  // inner join charging_model_mst cmm on csm.model_id = cmm.id
  // inner join client_charger_mapping ccm on csm.id = ccm.charger_id and ccm.status<>'D'
  // inner join client_mst cm on ccm.client_id = cm.id and cm.status='Y'
  // left join city_mst city on csm.city_id = city.id
  // left join state_mst sm on csm.state_id = sm.id
  // left join country_mst country on csm.country_id = country.id

  // left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status <>'D'
  // left join charging_station_mst chsm on csmap.station_id = chsm.id
  // where csm.status <> 'D'  
  // and csm.
  // order by csm.id desc;`;

  // sql.query(stmt, async (err, res) => {

  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   if (res.length) {
  //     let children = await getMappedConnectors();
  //     let final_res = res;

  //     for (let p = 0; p < res.length; p++) {
  //       const parent = res[p];
  //       final_res[p].connector_data = [];

  //       for (let c = 0; c < children.res.length; c++) {
  //         const child = children.res[c];

  //         if (parent.id == child.charger_id) {
  //           final_res[p].connector_data.push(child);
  //         }

  //       }

  //     }


  //     result(null, final_res);
  //     return;
  //   }

  //   result({ kind: "not_found" }, null);
  // });
};

Charger.getChargersByClient_CPO_StationId = async (data, result) => {
  //all chargers mapped to a client irrespective of those chargers are mapped to other CPO ,station

  let final_resp;
  let resp;
  let key = data.key;
  let value = data.value;
  let stmt2;

  if (key.toUpperCase() != 'CLIENT_ID') {
    if (key.toUpperCase() == 'STATION_ID') {
      stmt2 = `select cm.client_id from charging_station_mst csm inner join cpo_mst cm on csm.cpo_id = cm.id and cm.status ='Y' 
      where csm.id = ${value} and csm.status ='Y' ;`;
    } else if (key.toUpperCase() == 'CPO_ID') {
      stmt2 = `select client_id from  cpo_mst
      where id = ${value} and status ='Y' ;`;
    }

    let resp1 = await pool.query(stmt2);

    try {
      if (resp1.length > 0) {
        value = resp1[0].client_id;
      } else {

        final_resp = {
          status: false,
          message: key.toUpperCase() == 'STATION_ID' ? `No client mapped to this station` : `No client mapped to this CPO`,
          data: []
        }
      }

    } catch (e) {
      debugger
      final_resp = {
        status: false,
        message: `ERROR : ${e.message}`,
        data: []
      }
    }

  }

  let stmt = `  select csm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
   csm.model_id,cmm.name as model_name  ,csmap.station_id ,
  cm.id as client_id,cm.name as client_name,
  chsm.name as station_name ,csm.current_version_id , csm.no_of_guns,
  csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
  csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
  When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
  csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date
  from client_charger_mapping ccm 
  inner join charger_serial_mst csm on ccm.charger_id = csm.id and csm.status = 'Y'
  inner join charging_model_mst cmm on csm.model_id = cmm.id
  inner join client_mst cm on ccm.client_id = cm.id and cm.status='Y'
  left join city_mst city on csm.city_id = city.id
  left join state_mst sm on csm.state_id = sm.id
  left join country_mst country on csm.country_id = country.id
  
  left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status <>'D'
  left join charging_station_mst chsm on csmap.station_id = chsm.id
  where ccm.client_id = ${value} and ccm.status <> 'D';`;

  try {
    resp = await pool.query(stmt);
    final_resp = resp;
    if (resp.length > 0) {
      let children = await getMappedConnectors();

      for (let p = 0; p < resp.length; p++) {
        const parent = resp[p];
        final_resp[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];

          if (parent.charger_id == child.charger_id) {
            final_resp[p].connector_data.push(child);
          }

        }

      }
    }

    resp = {
      status: true,
      message: final_resp.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: final_resp.length,
      data: final_resp
    }
  } catch (err) {
    resp = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    result(null, resp);
  }
};

Charger.getAllChargersByUserId = async (id, result) => {
  //all chargers mapped to a user

  let final_resp;
  let resp;

  let stmt = ` select ucm.id as map_id, ucm.user_id , umn.f_Name as user_f_name, umn.l_Name as user_l_name ,
  ucm.charger_id, csm.name as charger_display_id, csm.serial_no ,
  ucm.status , ucm.createdby,ucm.created_date
  from user_charger_mapping ucm 
  inner join user_mst_new umn on ucm.user_id = umn.id
  inner join charger_serial_mst csm on ucm.charger_id = csm.id
  where ucm.user_id = ${id} and ucm.status = 'Y';`;

  try {
    resp = await pool.query(stmt);
    final_resp = resp;
    if (resp.length > 0) {
      let children = await getMappedConnectors();

      for (let p = 0; p < resp.length; p++) {
        const parent = resp[p];
        final_resp[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];

          if (parent.charger_id == child.charger_id) {
            final_resp[p].connector_data.push(child);
          }

        }

      }
    }

    resp = {
      status: true,
      message: final_resp.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: final_resp.length,
      data: final_resp
    }
  } catch (err) {
    resp = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    result(null, resp);
  }

};


ChargerStationMap.addChargerToStation = (newCharger, result) => {
  var datetime = new Date();

  let stmt = `insert into charger_station_mapping (charger_id,station_id,
    status,created_date,createdby )
    VALUES (${newCharger.charger_id},${newCharger.station_id},
    '${newCharger.status}','${datetime.toISOString().slice(0, 10)}',${newCharger.created_by}) `;
  ;
  sql.query(stmt, async (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    let final_result = await updateChargerAddress(newCharger.charger_id, newCharger.station_id, newCharger.created_by)

    result(null, { id: res.insertId, ...newCharger });
  });
};

//NOT in use as , getChargersByMappedStationId is in use
Charger.getChargersByStationId = (id, result) => {

  let stmt = `select 
      csm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
      model_id,csm.station_id , chsm.name as station_name ,
      csm.current_version_id, vm.name as version_name , csm.no_of_guns,
      csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
      csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
      csm.Lat,csm.Lng,
      csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
      When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
      csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date
      from ${_TABLE} csm inner join version_mst vm on csm.current_version_id = vm.id
      left join city_mst city on csm.city_id = city.id
      left join state_mst sm on csm.state_id = sm.id
      left join country_mst country on csm.country_id = country.id
      
      inner join charging_station_mst chsm on csm.station_id = chsm.id
      where csm.station_id = ? and csm.status = 'Y'
      order by csm.id desc`


  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

Charger.getChargersByMappedStationId = async (id, result) => {
  let resp = await func_getChargersByMappedStationId(id);
  result(null, resp);
};

Charger.getChargerById = (id, result) => {

  let stmt = `select 
      csm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
      batch_id,csm.model_id, cbm.name as charger_batch_name ,csmap.station_id , chsm.name as station_name ,
      csm.current_version_id, vm.name as version_name , csm.no_of_guns,
      csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
      csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
      csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
      When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
      csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date
      from ${_TABLE} csm inner join version_mst vm on csm.current_version_id = vm.id
      left join city_mst city on csm.city_id = city.id
      left join state_mst sm on csm.state_id = sm.id
      left join country_mst country on csm.country_id = country.id
      left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status <>'D'
      left join charging_station_mst chsm on csmap.station_id = chsm.id
      left join charger_batch_mst cbm on csm.batch_id = cbm.id
      where csm.id = ? and csm.status<>'D'`;

  sql.query(stmt, id, async (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    let children = await getMappedConnectors();

    let final_res = res;

    for (let p = 0; p < res.length; p++) {
      const parent = res[p];
      final_res[p].connector_data = [];

      for (let c = 0; c < children.res.length; c++) {
        const child = children.res[c];

        if (parent.charger_id == child.charger_id || parent.id == child.charger_id) {
          final_res[p].connector_data.push(child);
        }
      }
    }

    result(null, final_res);
  });
};

Charger.getChargerByDisplayId = (display_id, result) => {

  // let stmt = `select 
  //     csm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
  //     batch_id,csm.model_id, cbm.name as charger_batch_name ,csmap.station_id , chsm.name as station_name ,
  //     csm.current_version_id, vm.name as version_name , csm.no_of_guns,
  //     csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
  //     csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  //     csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
  //     When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
  //     csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date
  //     from ${_TABLE} csm inner join version_mst vm on csm.current_version_id = vm.id
  //     left join city_mst city on csm.city_id = city.id
  //     left join state_mst sm on csm.state_id = sm.id
  //     left join country_mst country on csm.country_id = country.id
  //     left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status <>'D'
  //     left join charging_station_mst chsm on csmap.station_id = chsm.id
  //     left join charger_batch_mst cbm on csm.batch_id = cbm.id
  //     where csm.name = ?  and csm.status<>'D'`;
  let stmt = `select 
      csm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
      batch_id,csm.model_id, cbm.name as charger_batch_name ,csmap.station_id , chsm.name as station_name ,
      chsm.location_type_id,chsm.cp_name, chsm.mobile as station_mobile , chsm.email as station_email,
      chsm.o_time , chsm.c_time, ltm.name as location_type_name , 
      csm.current_version_id, vm.name as version_name , csm.no_of_guns,
      csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
      csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
      csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
      When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
      csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date
      from ${_TABLE} csm inner join version_mst vm on csm.current_version_id = vm.id
      left join city_mst city on csm.city_id = city.id
      left join state_mst sm on csm.state_id = sm.id
      left join country_mst country on csm.country_id = country.id
      left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status <>'D'
      left join charging_station_mst chsm on csmap.station_id = chsm.id
      left join charger_batch_mst cbm on csm.batch_id = cbm.id
      left join location_type_mst ltm on chsm.location_type_id = ltm.id
      where csm.name = ?  and csm.status<>'D'`;

  sql.query(stmt, display_id, async (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    let children = await getMappedConnectors();

    let final_res = res;

    for (let p = 0; p < res.length; p++) {
      const parent = res[p];
      final_res[p].connector_data = [];

      for (let c = 0; c < children.res.length; c++) {
        const child = children.res[c];

        if (parent.charger_id == child.charger_id || parent.id == child.charger_id) {
          final_res[p].connector_data.push(child);
        }

      }

    }

    result(null, final_res);
  });
};

Charger.getChargerBySerialNo = (params, result) => {

  let stmt = `select 
      chsm.id as map_id, csmap.station_id ,chsm.name as station_name, csm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
      csm.model_id , 
      csm.current_version_id, vm.name as version_name , csm.no_of_guns,
      csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
      csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
      csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
      When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
      csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date,chsm.status as map_status
      from ${_TABLE} csm inner join version_mst vm on csm.current_version_id = vm.id   
      left join city_mst city on csm.city_id = city.id
      left join state_mst sm on csm.state_id = sm.id
      left join country_mst country on csm.country_id = country.id   
      left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status <>'D'
      left join charging_station_mst chsm on csmap.station_id = chsm.id
      
      where csm.serial_no = ?  and csm.status<>'D'`;

  sql.query(stmt, params.srNo, async (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    let children = await getMappedConnectors();

    let final_res = res;

    for (let p = 0; p < res.length; p++) {
      const parent = res[p];
      final_res[p].connector_data = [];

      for (let c = 0; c < children.res.length; c++) {
        const child = children.res[c];

        if (parent.charger_id == child.charger_id || parent.id == child.charger_id) {
          final_res[p].connector_data.push(child);
        }

      }

    }
    result(null, final_res);
  });
};

Charger.delete = (id, result) => {

  let stmt = `Update ${_TABLE} set status = 'D' WHERE id = ?`;
  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};


Charger.deleteChargerFromClient = async (id, user_id, result) => {
  var datetime = new Date();
  let stmt = `Update client_charger_mapping set status = 'D',
    modifyby = ${user_id}, modify_date = ?
  WHERE id = ?`;

  let final_res;
  let res;
  try {

    res = await pool.query(stmt, [datetime, id]);
    final_res = {
      status: true,
      message: `SUCCESS`
    }
  } catch (e) {
    final_res = {
      status: false,
      message: `ERROR : ${e.message}`
    }
  } finally {
    result(null, final_res);
  }
};

async function insertModelConnector(data, charger_id, charger_display_id, created_by) {
  var datetime = new Date();
  let values = [];
  for (let index = 0; index < data.length; index++) {
    values.push([(index + 1), charger_id, data[index].connector_type_id, charger_display_id,
    data[index].status, created_by, datetime.toISOString().slice(0, 10)])
  }

  let stmt = `update charger_connector_mapping set 
      status = 'D' ,
      modify_date = '${datetime.toISOString().slice(0, 10)}' , modifyby = ${created_by} 
      where (charger_id = ${charger_id} or charger_display_id='${charger_display_id}'  )`;
  let stmt2 = `insert into charger_connector_mapping (connector_no,charger_id,connector_type_id,charger_display_id,
    status,createdby,created_date)
    values  ? `;

  let promise = new Promise((resolve, reject) => {
    sql.query(stmt, [values], (err, res) => {
      if (err) {
        reject({ message: "ERROR", error: err });
      }

      sql.query(stmt2, [values], (err, res) => {
        if (err) {
          reject({ message: "ERROR", error: err });
        }

        resolve({ message: "SUCCESS insert", id: res.insertId });
      });
    });
  })
  return await promise;

}

const getMappedConnectors = async () => {

  let stmt = `select ccm.id as map_id,ccm.charger_id,ccm.connector_no,ccm.connector_type_id,
    ccm.current_status,ccm.current_status_date, ccm.charger_display_id ,
    ctm.name as connector_type_name,ccm.heartbeat_interval,cmcm.model_id,cmcm.id,cmcm.io_type_id,
    im.name as io_type_name,cmcm.current_type_id , cutm.name as current_type_name,
    cmcm.voltage,cmcm.phase,cmcm.max_amp,cmcm.power,cmcm.frequency,cmcm.status
    from charger_connector_mapping ccm 
    inner join charger_serial_mst csm on ccm.charger_id = csm.id
    inner join connector_type_mst ctm on ccm.connector_type_id = ctm.id
    inner join charging_model_connector_map cmcm on csm.model_id = cmcm.model_id and ccm.connector_no = cmcm.connector_no and cmcm.status<>'D'
    inner join io_type_mst im on cmcm.io_type_id=im.id
    inner join current_type_mst cutm on cmcm.current_type_id = cutm.id
    where ccm.status ='Y'
    order by ccm.connector_no`;

  let resp = await pool.query(stmt);
  return { res: resp };
}

const deleteMappedConnectors = async (model_id) => {
  let stmt = `update charging_model_connector_map set 
        status = 'D' where model_id = ? `

  let promise = new Promise((resolve, reject) => {
    sql.query(stmt, [model_id], (err, res) => {
      if (err) {
        reject({ message: "ERROR", error: err });
      }

      if (res.length) {

        resolve({ message: "SUCCESS", res: res });
      }
    })
  })

  return await promise;

}

async function updateChargerAddress(charger_id, station_id, modify_by) {
  var datetime = new Date();
  let promise = new Promise((resolve, reject) => {
    let stmt1 = `select address1,  address2,  PIN , landmark , city_id ,state_id, country_id ,lat,lng
      from charging_station_mst
      where id =  ${station_id} `;

    sql.query(stmt1, async (err, res) => {
      if (err) {
        reject({ message: "ERROR", error: err });
      }

      let stmt = `update ${_TABLE} set 
        station_id = ${station_id}, 
        Lat = ${res[0].lat}, Lng = ${res[0].lng},
        address1='${res[0].address1}'  ,address2 ='${res[0].address2}' ,PIN =${res[0].PIN} ,
        landmark ='${res[0].landmark}' ,city_id=${res[0].city_id} ,state_id=${res[0].state_id} ,
        country_id=${res[0].country_id} ,
        modifyby = ${modify_by},modify_date = '${datetime.toISOString().slice(0, 10)}' 
        where id =  ${charger_id} `;

      sql.query(stmt, async (err, res) => {
        if (err) {
          reject({ message: "ERROR", error: err });
        }

        resolve({ message: "SUCCESS", id: res.insertId });
      });
    });
  })
  return await promise;
}


async function func_getChargers() {
  let stmt = ` select csm.id, csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
  batch_id, csm.model_id ,cmm.name as model_name , cbm.name as charger_batch_name ,csmap.station_id , chsm.name as station_name ,
  csm.current_version_id, vm.name as version_name , csm.no_of_guns,
  csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
  csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
  When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
  csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date,
  CASE
    WHEN (TIMESTAMPDIFF(SECOND,last_ping_datetime,now()) <= heartbeat_interval) THEN "ONLINE"
    ELSE "OFFLINE/UNAVALIABLE"
  END as charger_status
  from ${_TABLE} csm 
  left join city_mst city on csm.city_id = city.id
  left join state_mst sm on csm.state_id = sm.id
  left join country_mst country on csm.country_id = country.id
  inner join version_mst vm on csm.current_version_id = vm.id
  left join charger_batch_mst cbm on csm.batch_id = cbm.id
  inner join charging_model_mst cmm on csm.model_id = cmm.id  and cmm.status='Y'
  left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status ='Y'
  left join charging_station_mst chsm on csmap.station_id = chsm.id
  where csm.status = 'Y'
  order by csm.id desc;`;

  let resp;
  let final_res;
  try {
    resp = await pool.query(stmt);
    if (resp.length > 0) {
      let children = await getMappedConnectors();
      final_res = resp;
      for (let p = 0; p < resp.length; p++) {
        const parent = resp[p];
        final_res[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];
          if (parent.charger_id == child.charger_id || parent.id == child.charger_id) {
            if (!!child.current_status) {
              if (child.current_status.toUpperCase() == 'CHARGING') final_res[p].charger_status = 'ONLINE'
            }

            final_res[p].connector_data.push(child);
          }

        }

      }
    }

    resp = {
      status: true,
      message: final_res.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: final_res.length,
      data: final_res
    }
  } catch (err) {
    resp = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    return resp;
  }
}

Charger.getChargersDynamicFilter = async (params, result) => {
  let resp = await func_getChargersDynamicFilter(params);
  result(null, resp);
};


async function func_getChargersDynamicFilter(params) {

  let whereClause = '';
  if (params.cpo_id) whereClause += `  and chsm.cpo_id = ${params.cpo_id} `;
  if (params.station_id) whereClause += ` and csmap.station_id = ${params.station_id} `

  let stmt = ` select csmap.id as map_id,chsm.cpo_id as cpo_id,csm.id as charger_id , csm.serial_no, case when csm.name is null then csm.serial_no else csm.name end as name,
  batch_id, csm.model_id ,cmm.name as model_name , cbm.name as charger_batch_name ,csmap.station_id , chsm.name as station_name ,
  csm.current_version_id, vm.name as version_name , csm.no_of_guns,
  csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
  csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
  When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
  csm.status,csm.created_date,csm.createdby,csm.modifyby,csm.modify_date,
  CASE
    WHEN (TIMESTAMPDIFF(SECOND,last_ping_datetime,now()) <= heartbeat_interval) THEN "ONLINE"
    ELSE "OFFLINE/UNAVALIABLE"
  END as charger_status
  from ${_TABLE} csm 
  left join city_mst city on csm.city_id = city.id
  left join state_mst sm on csm.state_id = sm.id
  left join country_mst country on csm.country_id = country.id
  inner join version_mst vm on csm.current_version_id = vm.id
  left join charger_batch_mst cbm on csm.batch_id = cbm.id
  inner join charging_model_mst cmm on csm.model_id = cmm.id  and cmm.status='Y'
  left join charger_station_mapping csmap on csm.id = csmap.charger_id and csmap.status <>'D'
  left join charging_station_mst chsm on csmap.station_id = chsm.id
  left join cpo_mst cm on chsm.cpo_id = cm.id
  where csm.status = 'Y' ${whereClause}
  order by csm.id desc;`;

  let resp;
  let final_res;
  try {
    resp = await pool.query(stmt);
    final_res = resp;
    if (resp.length > 0) {
      let children = await getMappedConnectors();

      for (let p = 0; p < resp.length; p++) {
        const parent = resp[p];
        final_res[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];
          if (parent.charger_id == child.charger_id || parent.id == child.charger_id) {
            if (!!child.current_status) {
              if (child.current_status.toUpperCase() == 'CHARGING') final_res[p].charger_status = 'ONLINE'
            }

            final_res[p].connector_data.push(child);
          }

        }

      }
    }

    resp = {
      status: true,
      message: final_res.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: final_res.length,
      data: final_res
    }
  } catch (err) {
    resp = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    return resp;
  }
}

async function func_getChargersByMappedStationId(station_id) {
  let stmt = ` select 
      chsm.id as map_id,chsm.station_id ,cst.name as station_name, csm.id as charger_id, csm.serial_no, 
      case when csm.name is null then csm.serial_no else csm.name end as name,
      csm.model_id  ,
      csm.current_version_id, vm.name as version_name , csm.no_of_guns,
      csm.address1  ,csm.address2  ,csm.PIN  ,csm.landmark  ,
      csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
      csm.Lat,csm.Lng,csm.OTA_Config,Periodic_Check_Ref_Time,Periodicity_in_hours,
      When_to_Upgrade,Upgrade_Specific_Time,csm.is_available,
      csm.status as charger_status, csm.heartbeat_interval ,
      chsm.status ,chsm.created_date,chsm.createdby,chsm.modifyby,chsm.modify_date
      from charger_station_mapping chsm
      inner join charger_serial_mst csm on chsm.charger_id = csm.id and csm.status <>'D'
      left join city_mst city on csm.city_id = city.id
      left join state_mst sm on csm.state_id = sm.id
      left join country_mst country on csm.country_id = country.id
      inner join version_mst vm on csm.current_version_id = vm.id
      inner join charging_station_mst cst on chsm.station_id = cst.id
      where chsm.station_id = ? and chsm.status <> 'D' order by chsm.id ;`;

  let resp;
  let final_res;
  try {
    resp = await pool.query(stmt, [station_id]);

    if (resp.length > 0) {
      let children = await getMappedConnectors();
      final_res = resp;

      for (let p = 0; p < resp.length; p++) {
        const parent = resp[p];
        final_res[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];

          if (parent.charger_id == child.charger_id) {
            final_res[p].connector_data.push(child);
          }

        }

      }
    }

    resp = {
      status: true,
      message: final_res.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: final_res.length,
      data: final_res
    }
  } catch (err) {
    resp = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    return resp;
  }
}

module.exports = {
  Charger: Charger,
  ChargerStationMap: ChargerStationMap,
  ClientChargerMap: ClientChargerMap,
  getMappedConnectors: getMappedConnectors,
  func_getChargers: func_getChargers
};