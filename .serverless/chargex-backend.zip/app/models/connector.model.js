const {sql,pool} = require("./db.js");

const ConnectorTypeVehicleModel = function(connectorTypeVehicleModel) {
    this.id = connectorTypeVehicleModel.id ,
    this.brand_id = connectorTypeVehicleModel.ct_id ,
    this.vehicle_type_id = connectorTypeVehicleModel.vm_id,
    this.status = connectorTypeVehicleModel.status ,
    this.created_date = connectorTypeVehicleModel.created_date ,
    this.created_by = connectorTypeVehicleModel.created_by,
    this.modify_date = connectorTypeVehicleModel.modify_date ,
    this.modify_by = connectorTypeVehicleModel.modify_by
};

  
  ConnectorTypeVehicleModel.getAllConnectorTypesByVehicleModelId = (brandId, result) => {

      sql.query(`SELECT ct_id,ctm.name 
        FROM c_type_v_model_mapping ctvmm inner join connector_type_mst ctm on ctvmm.ct_id = ctm.id
        WHERE vm_id  = ${brandId} and ctvmm.status = 'P'`, (err, res) => {
        if (err) {
          result(err, null);
          return;
        }

        if (res.length) {
          result(null, res);
          return;
        }

        // not found Customer with the id
        result({ kind: "not_found" }, null);
      });
  };
  ConnectorTypeVehicleModel.getAllConnectorTypesByVehicleModelIdPublished = (vModel_id, result) => {

    let stmt = `SELECT ct_id,ctm.name 
    FROM c_type_v_model_mapping ctvmm inner join connector_type_mst ctm on ctvmm.ct_id = ctm.id
    WHERE vm_id  = ${vModel_id} and ctvmm.status = 'P'`;

      sql.query(stmt, (err, res) => {
        if (err) {
          result(err, null);
          return;
        }

        if (res.length) {
          result(null, res);
          return;
        }

        // not found Customer with the id
        result({ kind: "not_found" }, null);
      });
  };

  ConnectorTypeVehicleModel.getAllConnectorTypesExcludingVModelId = (modelId, result) => {
    let stmt = `select ctm.id,ctm.name,ctm.description 
    from connector_type_mst ctm   
    where ctm.status = 'Y' and ctm.id not in (select ct_id from c_type_v_model_mapping where vm_id = ${modelId} and status <> 'D')
    order by ctm.name`;

    sql.query(stmt, (err, res) => {
        if (err) {
          result(err, null);
          return;
        }

        if (res.length>0) {
          result(null, res);
          return;
        }

        // not found Customer with the id
        result({ kind: "not_found" }, null);
      });
  };

  ConnectorTypeVehicleModel.getAllCTypesExcludingOtherAlreadyMapped = (params, result) => {
    let stmt =   `select ctm.id,ctm.name,ctm.description 
    from connector_type_mst ctm   
    where ctm.status = 'Y' 
    and ctm.id not in (select ct_id from c_type_v_model_mapping where vm_id = ${params.vehicleModelId} and ct_id <> ${params.ct_id} and status <> 'D')
    order by ctm.name `;
    
    sql.query(stmt, (err, res) => {
        if (err) {
          result(err, null);
          return;
        }

        if (res.length) {
          result(null, res);
          return;
        }

        // not found Customer with the id
        result({ kind: "not_found" }, null);
      });
  };

  ConnectorTypeVehicleModel.getAllConnectorTypes = ( result) => {
      sql.query(`select ctm.id,ctm.name ,ctm.description,ctm.current_type_id ,
      cutm.name as current_type_name
      from connector_type_mst ctm inner join current_type_mst cutm on ctm.current_type_id = cutm.id
      where ctm.status = 'Y' order by ctm.name`, (err, res) => {
        if (err) {
          result(err, null);
          return;
        }

        if (res.length) {
          result(null, res);
          return;
        }

        // not found Customer with the id
        result({ kind: "not_found" }, null);
      });
  };
  

// module.exports = Vehicle;
module.exports = ConnectorTypeVehicleModel;