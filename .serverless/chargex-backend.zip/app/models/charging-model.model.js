const {sql,pool} = require("./db.js");

// constructor
const ChargingModel = function (chargingModel) {

  this.id = chargingModel.id,
    this.client_id = chargingModel.client_id,
    this.charger_type_id = chargingModel.charger_type_id,
    this.manufacturer_id = chargingModel.manufacturer_id,
    this.charger_model_type_id = chargingModel.charger_model_type_id,
    this.battery_backup = chargingModel.battery_backup,
    this.code = chargingModel.code,
    this.name = chargingModel.name,
    this.description = chargingModel.description,
    this.communication_protocol_id = chargingModel.communication_protocol_id,
    this.communication_mode = chargingModel.communication_mode,
    this.card_reader_type = chargingModel.card_reader_type,
    this.no_of_connectors = chargingModel.no_of_connectors,
    this.connector_data = chargingModel.connector_data,
    this.status = chargingModel.status,
    this.created_date = chargingModel.created_date,
    this.created_by = chargingModel.created_by,
    this.modify_date = chargingModel.modify_date,
    this.modify_by = chargingModel.modify_by
};

const ChargingModelConnector = function (chargingModelConnector) {
  this.id = chargingModelConnector.id,
    this.model_id = chargingModelConnector.model_id,
    this.connector_type_id = chargingModelConnector.connector_type_id,
    this.io_type_id = chargingModelConnector.io_type_id,
    this.current_type_id = chargingModelConnector.current_type_id,
    this.voltage = chargingModelConnector.voltage,
    this.phase = chargingModelConnector.phase,
    this.max_amp = chargingModelConnector.max_amp,
    this.power = chargingModelConnector.power,
    this.frequency = chargingModelConnector.frequency,
    this.status = chargingModelConnector.status,
    this.created_date = chargingModelConnector.created_date,
    this.created_by = chargingModelConnector.created_by,
    this.modify_date = chargingModelConnector.modify_date,
    this.modify_by = chargingModelConnector.modify_by
};

ChargingModel.create = (newChargingModel, result) => {
  var datetime = new Date();

  let stmt = `insert into charging_model_mst (charger_type_id,manufacturer_id,charger_model_type_id,
    battery_backup,code,name,description,communication_protocol_id,
    communication_mode,card_reader_type,no_of_connectors,
    status,created_date,createdby )
    VALUES ( ${newChargingModel.charger_type_id},${newChargingModel.manufacturer_id},${newChargingModel.charger_model_type_id}, 
    '${newChargingModel.battery_backup}','${newChargingModel.code}','${newChargingModel.name}','${newChargingModel.description}',
    ${newChargingModel.communication_protocol_id},'${newChargingModel.communication_mode}','${newChargingModel.card_reader_type}',${newChargingModel.no_of_connectors},
    '${newChargingModel.status}','${datetime.toISOString().slice(0, 10)}',${newChargingModel.created_by}) `;

  let todo = newChargingModel;
      
  sql.query(stmt, async (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    await insertModelConnector(newChargingModel.connector_data, res.insertId, newChargingModel.created_by);

    setTimeout(() => {
      result(null, { id: res.insertId, ...newChargingModel });
    }, 2000);
  });
};

ChargingModel.update = (newChargingModel, result) => {
  var datetime = new Date();

  let stmt = `update charging_model_mst set 
  charger_type_id =${newChargingModel.charger_type_id} ,manufacturer_id =${newChargingModel.manufacturer_id},
  charger_model_type_id = ${newChargingModel.charger_model_type_id},
  battery_backup = '${newChargingModel.battery_backup}',code = '${newChargingModel.code}',
  name = '${newChargingModel.name}',description = '${newChargingModel.description}',
  communication_protocol_id = ${newChargingModel.communication_protocol_id},
  communication_mode = '${newChargingModel.communication_mode}',card_reader_type = '${newChargingModel.card_reader_type}',
  no_of_connectors = ${newChargingModel.no_of_connectors},
  status = '${newChargingModel.status}',
  modifyby = ${newChargingModel.modify_by},modify_date = '${datetime.toISOString().slice(0, 10)}' 
  where id =  ${newChargingModel.id}`;

  sql.query(stmt,async (err, res) => {
    
    if (err) {
      result(err, null);
      return;
    }

    
    await insertModelConnector(newChargingModel.connector_data, newChargingModel.id, newChargingModel.created_by);
    
    result(null, { id: res.insertId, ...newChargingModel });
  });
};

ChargingModel.getChargingModels = async (result) => {
  
  let stmt = `select cpom.id, cpom.charger_type_id,ctm.name as charger_type_name, cpom.manufacturer_id ,
    mm.name as manufacturer_name,
    cpom.charger_model_type_id, cmtm.name as charger_model_type_name ,
    cpom.code, cpom.name ,cpom.description, 
    cpom.communication_protocol_id, cpm.name as communication_protocol_name, 
    cpom.battery_backup,
    cpom.communication_mode,cpom.card_reader_type, cpom.no_of_connectors,
    cpom.status,cpom.created_date,cpom.createdby,cpom.modifyby,cpom.modify_date
    from charging_model_mst cpom inner join charger_type_mst ctm on cpom.charger_type_id = ctm.id
    inner join manufacturer_mst mm on cpom.manufacturer_id = mm.id
    inner join communication_protocol_mst cpm on cpom.communication_protocol_id = cpm.id
    inner join charger_model_type_mst cmtm on cpom.charger_model_type_id = cmtm.id
    where cpom.status = 'Y'
    order by cpom.id desc`;

  sql.query(stmt, async (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {

      

      let children = await getChildren();

      let final_res = res;
      
      for (let p = 0; p < res.length; p++) {
        const parent = res[p];
        final_res[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];

          if (parent.id == child.model_id) {
            final_res[p].connector_data.push(child);
          }
        }
      }

      result(null, final_res);
      return;
    } else {
      result({ kind: "not_found" }, null);
    }
  });
};

ChargingModel.getChargingModelsAll = async (result) => {
  
  let stmt = `select cpom.id, cpom.charger_type_id,ctm.name as charger_type_name, cpom.manufacturer_id ,
    mm.name as manufacturer_name,
    cpom.charger_model_type_id, cmtm.name as charger_model_type_name ,
    cpom.code, cpom.name ,cpom.description, 
    cpom.communication_protocol_id, cpm.name as communication_protocol_name, 
    cpom.battery_backup,
    cpom.communication_mode,cpom.card_reader_type, cpom.no_of_connectors,
    cpom.status,cpom.created_date,cpom.createdby,cpom.modifyby,cpom.modify_date
    from charging_model_mst cpom inner join charger_type_mst ctm on cpom.charger_type_id = ctm.id
    inner join manufacturer_mst mm on cpom.manufacturer_id = mm.id
    inner join communication_protocol_mst cpm on cpom.communication_protocol_id = cpm.id
    inner join charger_model_type_mst cmtm on cpom.charger_model_type_id = cmtm.id
    where cpom.status <> 'D'
    order by cpom.id desc`;

  sql.query(stmt, async (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {

      

      let children = await getChildren();

      let final_res = res;
      
      for (let p = 0; p < res.length; p++) {
        const parent = res[p];
        final_res[p].connector_data = [];

        for (let c = 0; c < children.res.length; c++) {
          const child = children.res[c];

          if (parent.id == child.model_id) {
            final_res[p].connector_data.push(child);
          }
        }
      }

      result(null, final_res);
      return;
    } else {
      result({ kind: "not_found" }, null);
    }
  });
};

ChargingModel.getChargingModelById = (id, result) => {

  let stmt = `select cpom.id, charger_type_id,ctm.name as charger_type_name, cpom.name,cpom.description,cpom.address,
      cpom.logoPath, cpom.mobile,cpom.email,cpom.cp_name,
      cpom.status,cpom.created_date,cpom.createdby,cpom.modifyby,cpom.modify_date
      from charging_model_mst cpom inner join charger_type_mst ctm on cpom.charger_type_id = ctm.id
      WHERE cpom.id = ? `;

  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

ChargingModel.getChargingModelByClientId = (client_id, result) => {

  let stmt = `select cpom.id, client_id,cm.name as client_name, cpom.name,cpom.description,cpom.address,
      cpom.logoPath, cpom.mobile,cpom.email,cpom.cp_name,
      cpom.status,cpom.created_date,cpom.createdby,cpom.modifyby,cpom.modify_date
      from charging_model_mst cpom inner join client_mst cm on cpom.client_id = cm.id
      WHERE cpom.client_id = ? and cpom.status <> 'D'`;
  sql.query(stmt, client_id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};
ChargingModel.getChargingModelByChargerTypeId = (charger_type_id, result) => {

  let stmt = `select cpom.id, charger_type_id,cm.name as charger_type_name, cpom.name,cpom.description,cpom.address,
      cpom.logoPath, cpom.mobile,cpom.email,cpom.cp_name,
      cpom.status,cpom.created_date,cpom.createdby,cpom.modifyby,cpom.modify_date
      from charging_model_mst cpom inner join charger_type_mst cm on cpom.charger_type_id = cm.id
      WHERE cpom.charger_type_id = ? and cpom.status <> 'D'`;
  sql.query(stmt, charger_type_id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

ChargingModel.delete = (id, result) => {
let final_res;
  let stmt = `Update charging_model_mst set status = 'D' WHERE id = ?`;
  sql.query(stmt, id, async (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    } else {
      await deleteChildren(id);
      result(null, res);
      return;
    }
  });
};


async function insertModelConnector(data, model_id, created_by) {
  var datetime = new Date();
  let values = [];

  for (let index = 0; index < data.length; index++) {
    values.push([(index+1),model_id, data[index].connector_type_id, data[index].io_type_id,
      data[index].current_type_id, data[index].voltage, data[index].phase, data[index].max_amp, data[index].power, data[index].frequency,
      data[index].status, created_by, datetime.toISOString().slice(0, 10)])
  }
  
  let stmt = `update charging_model_connector_map set 
    status = 'D' ,
    modify_date = '${datetime.toISOString().slice(0, 10)}' , modifyby = ${created_by} 
    where model_id = ${model_id}`;
    
  let stmt2 = `insert into charging_model_connector_map (connector_no,model_id,connector_type_id,io_type_id,
  current_type_id,voltage,phase,max_amp,power,frequency,
  status,createdby,created_date)
  values  ? `;

  let promise = new Promise((resolve,reject)=>{
    sql.query(stmt, [values], (err, res) => {
      
      if (err) {
        reject( { message: "ERROR", error: err });
      }
  
      sql.query(stmt2, [values], (err, res) => {
        
        if (err) {
          reject( { message: "ERROR", error: err });
        }
    
        resolve( { message: "SUCCESS insert", id: res.insertId });
      });
    });
  })


  
  return await promise;

}


const getChildren = async () => {
  

  let stmt = `select cmcm.id, cmcm.model_id, cmcm.connector_type_id , ctm.name as connector_type_name,
    cmcm.io_type_id, itm.name as io_type_name ,
    cmcm.current_type_id, cutm.name as current_type_name, cmcm.voltage ,cmcm.phase, 
    cmcm.max_amp,  cmcm.power,cmcm.frequency,
    cmcm.status,cmcm.created_date,cmcm.createdby,cmcm.modifyby,cmcm.modify_date
    from charging_model_connector_map cmcm inner join connector_type_mst ctm on cmcm.connector_type_id = ctm.id
    inner join io_type_mst itm on cmcm.io_type_id = itm.id
    inner join current_type_mst cutm on cmcm.current_type_id = cutm.id
    where cmcm.status <> 'D'
    order by cmcm.id desc`;


  let promise = new Promise((resolve, reject) => {
    sql.query(stmt, async (err, res) => {
      

      if (err) {
        reject({ message: "ERROR", error: err });
      }

      if (res.length) {
        resolve({ message: "SUCCESS", res: res });
      }


    });
  })

  return await promise;


}

const deleteChildren = async (model_id) => {
  let stmt = `update charging_model_connector_map set 
      status = 'D' where model_id = ? `

      let final_res;
      let resp;

      try {
        resp = await pool.query(stmt,[model_id]);

        final_res={
          status : true,
          message : 'DELETED',
          data : []
        }
      } catch (e) {
        final_res={
          status : false,
          message : `ERROR : ${e.code} `,
          data : []
        }
      }finally{
        return final_res;
      }

}

module.exports = {
  ChargingModel: ChargingModel,
  ChargingModelConnector: ChargingModelConnector
};