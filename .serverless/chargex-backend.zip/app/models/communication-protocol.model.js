const {sql,pool} = require("./db.js");


// constructor
const CommunicationProtocol = function (commprotocol) {
    this.id = commprotocol.id,
    this.name = commprotocol.name;
    this.description = commprotocol.description;
    this.status = commprotocol.status;
    this.created_date = commprotocol.created_date;
    this.createdby = commprotocol.createdby;
    this.modify_date = commprotocol.modify_date;
    this.modifyby = commprotocol.modifyby;
};


CommunicationProtocol.getAll = result => {
    sql.query(`SELECT id,name,description,status,created_date,createdby 
        FROM communication_protocol_mst  where status <> 'D' order by id desc`, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        result(null, res);
    });
};


module.exports = CommunicationProtocol; 