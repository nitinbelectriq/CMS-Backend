const {sql,pool} = require("./db.js");


// constructor
const IOType = function (ioType) {
    this.id = ioType.id,
    this.name = ioType.name;
    this.description = ioType.description;
    this.status = ioType.status;
    this.created_date = ioType.created_date;
    this.createdby = ioType.createdby;
    this.modify_date = ioType.modify_date;
    this.modifyby = ioType.modifyby;
};


IOType.getAll = result => {
    sql.query("SELECT * FROM io_type_mst where status <>'D'", (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        result(null, res);
    });
};


module.exports = IOType;