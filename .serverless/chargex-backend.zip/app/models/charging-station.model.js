const { sql, pool } = require("./db.js");
const charger_model = require("../models/charger.model.js");
const _utility = require("../utility/_utility");

const ChargingStation = function (chargingStation) {
  this.id = chargingStation.id,
  this.cpo_id = chargingStation.cpo_id,
  this.cpo_name = chargingStation.cpo_name,
  this.name = chargingStation.name,
  this.code = chargingStation.code,
  this.description = chargingStation.description,
  this.address1 = chargingStation.address1;
  this.address2 = chargingStation.address2;
  this.PIN = chargingStation.PIN;
  this.landmark = chargingStation.landmark;
  this.city_id = chargingStation.city_id;
  this.state_id = chargingStation.state_id;
  this.country_id = chargingStation.country_id;
  this.lat = chargingStation.lat,
  this.lng = chargingStation.lng,
  this.location_type_id = chargingStation.location_type_id,
  this.cp_name = chargingStation.cp_name,
  this.mobile = chargingStation.mobile,
  this.email = chargingStation.email,
  this.commissioned_dt = chargingStation.commissioned_dt,
  this.register_as = chargingStation.register_as,
  this.electricity_line_id = chargingStation.electricity_line_id,
  this.o_time = chargingStation.o_time,
  this.c_time = chargingStation.c_time,
  this.status = chargingStation.status,
  this.created_date = chargingStation.created_date,
  this.created_by = chargingStation.created_by,
  this.modify_date = chargingStation.modify_date,
  this.modify_by = chargingStation.modify_by
};

ChargingStation.create = (newCs, result) => {
  var datetime = new Date();

  let stmt = `insert into charging_station_mst ( cpo_id, name, code, description, 
    address1  ,address2  ,PIN  ,landmark  ,city_id ,state_id ,country_id ,
     lat, lng,location_type_id, cp_name,mobile,
     email, commissioned_dt,register_as,electricity_line_id,
     o_time,c_time,status,created_date,createdby)
    VALUES ( ${newCs.cpo_id}, '${newCs.name}','${newCs.code}','${newCs.description}',
    '${newCs.address1}','${newCs.address2}',${newCs.PIN},'${newCs.landmark}',${newCs.city_id},${newCs.state_id},${newCs.country_id},
    ${newCs.lat},${newCs.lng},${newCs.location_type_id},'${newCs.cp_name}',${newCs.mobile},
    '${newCs.email}','${newCs.commissioned_dt}',${newCs.register_as},${newCs.electricity_line_id},
    '${newCs.o_time}','${newCs.c_time}',
    '${newCs.status}','${datetime.toISOString().slice(0, 10)}',${newCs.created_by}) `;

  let todo = newCs;
  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newCs });
  });
};

ChargingStation.update = (newCs, result) => {
  var datetime = new Date();

  let stmt = `update charging_station_mst set 
    cpo_id = ${newCs.cpo_id}, name = '${newCs.name}', code = '${newCs.code}',
    description = '${newCs.description}', address1='${newCs.address1}' ,
    address2 ='${newCs.address2}' ,PIN =${newCs.PIN} ,landmark ='${newCs.landmark}' ,
    city_id=${newCs.city_id} ,state_id=${newCs.state_id} , country_id=${newCs.country_id} ,
    lat=${newCs.lat}, lng =${newCs.lng},location_type_id= ${newCs.location_type_id},
    cp_name = '${newCs.cp_name}',mobile = ${newCs.mobile},email = '${newCs.email}',
    commissioned_dt = '${newCs.commissioned_dt}',register_as = ${newCs.register_as},
    electricity_line_id = ${newCs.electricity_line_id},o_time = '${newCs.o_time}',c_time = '${newCs.c_time}',
    status = '${newCs.status}',modifyby = ${newCs.modify_by},modify_date = '${datetime.toISOString().slice(0, 10)}' 
    where id =  ${newCs.id}`;

  sql.query(stmt, (err, res) => {


    if (err) {
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newCs });
  });
};

ChargingStation.getChargingStations = async result => {

  let ress = await getAllChargingStations();
  result(null, ress);
};

ChargingStation.getChargingStationById = (id, result) => {

  let stmt = `SELECT csm.id, csm.cpo_id, cpom.name as cpo_name , csm.name, csm.code, csm.description,
    csm.address1,  csm.address2,  csm.PIN , csm.landmark , 
    csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
    csm.lat, csm.lng,csm.location_type_id,csm.cp_name,csm.mobile,csm.email,
    csm.commissioned_dt,csm.register_as,csm.electricity_line_id,csm.o_time,csm.c_time,
    csm.status,csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
    FROM charging_station_mst csm inner join cpo_mst cpom on csm.cpo_id = cpom.id 
    inner join city_mst city on csm.city_id = city.id
    inner join state_mst sm on csm.state_id = sm.id
    inner join country_mst country on csm.country_id = country.id
    where csm.id = ? `;
  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

ChargingStation.getChargingStationByCpoId = async (cpo_id, result) => {
  let ress = await getAllChargingStationsByCPOId(cpo_id);
  result(null, ress);
};

ChargingStation.getChargingStationsWithTotalChargersByCPOId = async (cpo_id, result) => {
  let ress = await getAllChargingStationsByCPOId(cpo_id);
  result(null, ress);
};

ChargingStation.getAllChargingStationsWithChargersAndConnectors = async (result) => {
  let stations_details;

  try {
    stations_details = await func_allChargingStationsWithChargersAndConnectors();
  } catch (err) {
  }
  result(null, stations_details);
};

ChargingStation.getAllChargingStationsWithChargersAndConnectorsUW = async (user_id,result) => {
  let stations_details;

  try {
    stations_details = await func_allChargingStationsWithChargersAndConnectorsUW(user_id);
  } catch (err) {
  }
  result(null, stations_details);
};

ChargingStation.getAllChargingStationsWithChargersAndConnectorsCW = async (user_id, result) => {
  let stations_details;
  try {
    
    stations_details = await func_allChargingStationsWithChargersAndConnectorsCW(user_id);
  } catch (err) {
  }
  result(null, stations_details);
};

ChargingStation.getChargingStationByClientId = (client_id, result) => {

  let stmt = `SELECT csm.id, csm.cpo_id, cpom.name as cpo_name , csm.name, csm.code, csm.description, 
    csm.address1,  csm.address2,  csm.PIN , csm.landmark , csm.city_id ,csm.state_id, csm.country_id ,
      csm.lat, csm.lng,csm.location_type_id,csm.cp_name,csm.mobile,csm.email,
      csm.commissioned_dt,csm.register_as,csm.electricity_line_id,csm.o_time,csm.c_time,
      csm.status,csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
      FROM charging_station_mst csm inner join cpo_mst cpom on csm.cpo_id = cpom.id
      WHERE csm.cpo_id in (select id from cpo_mst where client_id = ?) and csm.status = 'Y'`;
  sql.query(stmt, client_id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

ChargingStation.delete = (id, result) => {

  let stmt = `Update charging_station_mst set status = 'D' WHERE id = ?`;
  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};


async function getAllChargingStationsByCPOId(cpo_id) {

  let stmt = `SELECT csm.id, csm.cpo_id, cpom.name as cpo_name , csm.name, csm.code, csm.description, 
    csm.address1,  csm.address2,  csm.PIN , csm.landmark , 
    csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
      csm.lat, csm.lng,csm.location_type_id,csm.cp_name,csm.mobile,csm.email,
      csm.commissioned_dt,csm.register_as,csm.electricity_line_id,csm.o_time,csm.c_time,
      csm.status,csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
      FROM charging_station_mst csm inner join cpo_mst cpom on csm.cpo_id = cpom.id
      inner join city_mst city on csm.city_id = city.id
      inner join state_mst sm on csm.state_id = sm.id
      inner join country_mst country on csm.country_id = country.id
      WHERE csm.cpo_id = ? and csm.status = 'Y'`;

  let ress;
  try {
    ress = await pool.query(stmt, [cpo_id]);

    ress = {
      status: true,
      message: ress.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: ress.length,
      data: ress
    }
  } catch (err) {
    // handle the error
    ress = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    // await db.close();
    return ress;
  }

}

async function func_allChargingStationsWithChargersAndConnectors() {

  let stmt = `SELECT count(chsm.charger_id) as total_chargers,csm.id, csm.cpo_id, cpom.name as cpo_name ,cpom.client_id, csm.name, csm.code, csm.description, 
  csm.address1,  csm.address2,  csm.PIN , csm.landmark , 
  csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  csm.lat, csm.lng,csm.location_type_id,ltm.name as location_type ,csm.cp_name,csm.mobile,csm.email,
  csm.commissioned_dt,csm.register_as as register_as_id , crtm.name as register_as ,
  csm.electricity_line_id , eltm.name as electricity_line ,csm.o_time,csm.c_time,
  csm.status,csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
  FROM charging_station_mst csm 
  left join charger_station_mapping chsm on csm.id = chsm.station_id and chsm.status = 'Y'
  inner join cpo_mst cpom on csm.cpo_id = cpom.id 
  inner join location_type_mst ltm on csm.location_type_id = ltm.id
  inner join charger_registration_type_mst crtm on csm.register_as = crtm.id
  inner join electricity_line_type_mst eltm on csm.electricity_line_id = eltm.id
  inner join city_mst city on csm.city_id = city.id
  inner join state_mst sm on csm.state_id = sm.id
  inner join country_mst country on csm.country_id = country.id
  where csm.status = 'Y' 
  group by csm.id, csm.cpo_id,cpo_name , csm.name, csm.code, csm.description, csm.address1,  
  csm.address2,  csm.PIN , csm.landmark , csm.city_id ,  city_name, csm.state_id,  
  state_name, csm.country_id, country_name,csm.lat, csm.lng,csm.location_type_id,
  location_type ,csm.cp_name,csm.mobile,csm.email,csm.commissioned_dt, register_as_id ,
  register_as ,csm.electricity_line_id , electricity_line ,csm.o_time,csm.c_time,csm.status,
  csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
  order by csm.created_date desc ;`;

  let stations_details;
  let chargers_details;

  try {
    
    stations_details = await pool.query(stmt);
    chargers_details = await charger_model.func_getChargers();
    amenity_details = await func_getAmenitiesStationMapping();

    if (stations_details.length > 0 && chargers_details.data.length > 0) {

      final_stations_details = stations_details;

      for (let p = 0; p < stations_details.length; p++) {
        const parent = stations_details[p];
        final_stations_details[p].chargers = [];

        for (let c = 0; c < chargers_details.data.length; c++) {
          const child = chargers_details.data[c];

          if (parent.id == child.station_id) {
            final_stations_details[p].chargers.push(child);
          }

        }

      }

    } else {

    }

    if (stations_details.length > 0 && amenity_details.data.length > 0) {

      final_stations_details = stations_details;

      for (let p = 0; p < stations_details.length; p++) {
        const parent = stations_details[p];
        final_stations_details[p].amenities = [];

        for (let c = 0; c < amenity_details.data.length; c++) {
          const child = amenity_details.data[c];

          if (parent.id == child.station_id) {
            final_stations_details[p].amenities.push(child);
          }

        }

      }

    } else {

    }

    stations_details = {
      status: true,
      message: stations_details.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: stations_details.length,
      data: stations_details
    }
  } catch (err) {
    // handle the error
    stations_details = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    // await db.close();
    return stations_details;
  }

}

async function func_allChargingStationsWithChargersAndConnectorsUW(user_id) {

  
  let stmt= `SELECT count(chsm.charger_id) as total_chargers,upm.id as favourite_station,csm.id, csm.cpo_id, cpom.name as cpo_name ,cpom.client_id, csm.name, csm.code, csm.description, 
    csm.address1,  csm.address2,  csm.PIN , csm.landmark , 
    csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
    csm.lat, csm.lng,csm.location_type_id,ltm.name as location_type ,csm.cp_name,csm.mobile,csm.email,
    csm.commissioned_dt,csm.register_as as register_as_id , crtm.name as register_as ,
    csm.electricity_line_id , eltm.name as electricity_line ,csm.o_time,csm.c_time,
    csm.status,csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
    FROM charging_station_mst csm 
    left join charger_station_mapping chsm on csm.id = chsm.station_id and chsm.status = 'Y'
    inner join cpo_mst cpom on csm.cpo_id = cpom.id 
    inner join location_type_mst ltm on csm.location_type_id = ltm.id
    inner join charger_registration_type_mst crtm on csm.register_as = crtm.id
    inner join electricity_line_type_mst eltm on csm.electricity_line_id = eltm.id
    inner join city_mst city on csm.city_id = city.id
    inner join state_mst sm on csm.state_id = sm.id
    inner join country_mst country on csm.country_id = country.id
    left join user_preference_mst upm on csm.id = upm.station_id and upm.status = 'Y' and upm.user_id = ${user_id}
    where csm.status = 'Y' 
    group by csm.id, csm.cpo_id,cpo_name , csm.name, csm.code, csm.description, csm.address1,  
    csm.address2,  csm.PIN , csm.landmark , csm.city_id ,  city_name, csm.state_id,  
    state_name, csm.country_id, country_name,csm.lat, csm.lng,csm.location_type_id,
    location_type ,csm.cp_name,csm.mobile,csm.email,csm.commissioned_dt, register_as_id ,
    register_as ,csm.electricity_line_id , electricity_line ,csm.o_time,csm.c_time,csm.status,
    csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
    order by favourite_station desc, csm.name desc ;`;
  
  let stations_details;
  let chargers_details;

  try {
    stations_details = await pool.query(stmt);
    chargers_details = await charger_model.func_getChargers();
    amenity_details = await func_getAmenitiesStationMapping();

    if (stations_details.length > 0 && chargers_details.data.length > 0) {

      final_stations_details = stations_details;

      for (let p = 0; p < stations_details.length; p++) {
        const parent = stations_details[p];
        final_stations_details[p].chargers = [];

        for (let c = 0; c < chargers_details.data.length; c++) {
          const child = chargers_details.data[c];

          if (parent.id == child.station_id) {
            final_stations_details[p].chargers.push(child);
          }

        }

      }

    } 

    if (stations_details.length > 0 && amenity_details.data.length > 0) {

      final_stations_details = stations_details;

      for (let p = 0; p < stations_details.length; p++) {
        const parent = stations_details[p];
        final_stations_details[p].amenities = [];

        for (let c = 0; c < amenity_details.data.length; c++) {
          const child = amenity_details.data[c];

          if (parent.id == child.station_id) {
            final_stations_details[p].amenities.push(child);
          }

        }

      }

    } 

    stations_details = {
      status: true,
      message: stations_details.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: stations_details.length,
      data: stations_details
    }
  } catch (err) {
    // handle the error
    stations_details = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    // await db.close();
    return stations_details;
  }

}
async function func_allChargingStationsWithChargersAndConnectorsCW(user_id) {

  
  let stmt='';
  let clientAndRoleDetails = await _utility.getClientIdAndRoleByUserId(user_id);
  let client_id = clientAndRoleDetails.data[0].client_id;
  let role_code = clientAndRoleDetails.data[0].role_code;
  if(role_code=='SA'){
    stmt = `SELECT count(chsm.charger_id) as total_chargers,csm.id, csm.cpo_id, cpom.name as cpo_name ,cpom.client_id, csm.name, csm.code, csm.description, 
    csm.address1,  csm.address2,  csm.PIN , csm.landmark , 
    csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
    csm.lat, csm.lng,csm.location_type_id,ltm.name as location_type ,csm.cp_name,csm.mobile,csm.email,
    csm.commissioned_dt,csm.register_as as register_as_id , crtm.name as register_as ,
    csm.electricity_line_id , eltm.name as electricity_line ,csm.o_time,csm.c_time,
    csm.status,csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
    FROM charging_station_mst csm 
    left join charger_station_mapping chsm on csm.id = chsm.station_id and chsm.status = 'Y'
    inner join cpo_mst cpom on csm.cpo_id = cpom.id 
    inner join location_type_mst ltm on csm.location_type_id = ltm.id
    inner join charger_registration_type_mst crtm on csm.register_as = crtm.id
    inner join electricity_line_type_mst eltm on csm.electricity_line_id = eltm.id
    inner join city_mst city on csm.city_id = city.id
    inner join state_mst sm on csm.state_id = sm.id
    inner join country_mst country on csm.country_id = country.id
    where csm.status = 'Y' 
    group by csm.id, csm.cpo_id,cpo_name , csm.name, csm.code, csm.description, csm.address1,  
    csm.address2,  csm.PIN , csm.landmark , csm.city_id ,  city_name, csm.state_id,  
    state_name, csm.country_id, country_name,csm.lat, csm.lng,csm.location_type_id,
    location_type ,csm.cp_name,csm.mobile,csm.email,csm.commissioned_dt, register_as_id ,
    register_as ,csm.electricity_line_id , electricity_line ,csm.o_time,csm.c_time,csm.status,
    csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
    order by csm.created_date desc ;`;
  }else{

    stmt = `SELECT count(chsm.charger_id) as total_chargers,csm.id, csm.cpo_id, cpom.name as cpo_name ,cpom.client_id, csm.name, csm.code, csm.description, 
    csm.address1,  csm.address2,  csm.PIN , csm.landmark , 
    csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
    csm.lat, csm.lng,csm.location_type_id,ltm.name as location_type ,csm.cp_name,csm.mobile,csm.email,
    csm.commissioned_dt,csm.register_as as register_as_id , crtm.name as register_as ,
    csm.electricity_line_id , eltm.name as electricity_line ,csm.o_time,csm.c_time,
    csm.status,csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
    FROM charging_station_mst csm 
    left join charger_station_mapping chsm on csm.id = chsm.station_id and chsm.status = 'Y'
    inner join cpo_mst cpom on csm.cpo_id = cpom.id 
    inner join location_type_mst ltm on csm.location_type_id = ltm.id
    inner join charger_registration_type_mst crtm on csm.register_as = crtm.id
    inner join electricity_line_type_mst eltm on csm.electricity_line_id = eltm.id
    inner join city_mst city on csm.city_id = city.id
    inner join state_mst sm on csm.state_id = sm.id
    inner join country_mst country on csm.country_id = country.id
    where csm.status = 'Y' 
    and cpom.client_id = ${client_id}
    group by csm.id, csm.cpo_id,cpo_name , csm.name, csm.code, csm.description, csm.address1,  
    csm.address2,  csm.PIN , csm.landmark , csm.city_id ,  city_name, csm.state_id,  
    state_name, csm.country_id, country_name,csm.lat, csm.lng,csm.location_type_id,
    location_type ,csm.cp_name,csm.mobile,csm.email,csm.commissioned_dt, register_as_id ,
    register_as ,csm.electricity_line_id , electricity_line ,csm.o_time,csm.c_time,csm.status,
    csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
    order by csm.created_date desc ;`;
  }


  let stations_details;
  let chargers_details;

  try {
    stations_details = await pool.query(stmt);
    chargers_details = await charger_model.func_getChargers();
    amenity_details = await func_getAmenitiesStationMapping();

    if (stations_details.length > 0 && chargers_details.data.length > 0) {

      final_stations_details = stations_details;

      for (let p = 0; p < stations_details.length; p++) {
        const parent = stations_details[p];
        final_stations_details[p].chargers = [];

        for (let c = 0; c < chargers_details.data.length; c++) {
          const child = chargers_details.data[c];

          if (parent.id == child.station_id) {
            final_stations_details[p].chargers.push(child);
          }

        }

      }

    } 

    if (stations_details.length > 0 && amenity_details.data.length > 0) {

      final_stations_details = stations_details;

      for (let p = 0; p < stations_details.length; p++) {
        const parent = stations_details[p];
        final_stations_details[p].amenities = [];

        for (let c = 0; c < amenity_details.data.length; c++) {
          const child = amenity_details.data[c];

          if (parent.id == child.station_id) {
            final_stations_details[p].amenities.push(child);
          }

        }

      }

    } 

    stations_details = {
      status: true,
      message: stations_details.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: stations_details.length,
      data: stations_details
    }
  } catch (err) {
    // handle the error
    stations_details = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    // await db.close();
    return stations_details;
  }

}

async function getAllChargingStations() {

  let stmt = `SELECT count(chsm.charger_id) as total_chargers,csm.id, csm.cpo_id, cpom.name as cpo_name , csm.name, csm.code, csm.description, 
  csm.address1,  csm.address2,  csm.PIN , csm.landmark , 
  csm.city_id , city.name as city_name, csm.state_id, sm.name as state_name, csm.country_id, country.name as country_name,
  csm.lat, csm.lng,csm.location_type_id,ltm.name as location_type ,csm.cp_name,csm.mobile,csm.email,
  csm.commissioned_dt,csm.register_as as register_as_id , crtm.name as register_as ,
  csm.electricity_line_id , eltm.name as electricity_line ,csm.o_time,csm.c_time,
  csm.status,csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
  FROM charging_station_mst csm 
  left join charger_station_mapping chsm on csm.id = chsm.station_id and chsm.status = 'Y'
  inner join cpo_mst cpom on csm.cpo_id = cpom.id 
  inner join location_type_mst ltm on csm.location_type_id = ltm.id
  inner join charger_registration_type_mst crtm on csm.register_as = crtm.id
  inner join electricity_line_type_mst eltm on csm.electricity_line_id = eltm.id
  inner join city_mst city on csm.city_id = city.id
  inner join state_mst sm on csm.state_id = sm.id
  inner join country_mst country on csm.country_id = country.id
  where csm.status = 'Y' 
  group by csm.id, csm.cpo_id,cpo_name , csm.name, csm.code, csm.description, csm.address1,  
  csm.address2,  csm.PIN , csm.landmark , csm.city_id ,  city_name, csm.state_id,  
  state_name, csm.country_id, country_name,csm.lat, csm.lng,csm.location_type_id,
  location_type ,csm.cp_name,csm.mobile,csm.email,csm.commissioned_dt, register_as_id ,
  register_as ,csm.electricity_line_id , electricity_line ,csm.o_time,csm.c_time,csm.status,
  csm.created_date,csm.createdby,csm.modify_date,csm.modifyby
  order by csm.created_date desc ;`;
  let ress;
  try {
    ress = await pool.query(stmt);

    ress = {
      status: true,
      message: ress.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: ress.length,
      data: ress
    }
  } catch (err) {
    // handle the error
    ress = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    // await db.close();
    return ress;
  }

}


async function func_getAmenitiesByStationId(station_id) {

  let resp;
  let final_res;

  let stmt = `select sam.id as map_id, sam.station_id,sam.amenity_id , am.name as amenity_name ,
    am.icon_url ,am.status as amenity_status
    from station_amenity_mapping sam 
    inner join amenity_mst am on sam.amenity_id = am.id and am.status = 'Y'
    where sam.status = 'Y' and sam.staion_id = ? order by display_order ;`;

  try {
    resp = await pool.query(stmt,[station_id]);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'FAILED',
      count : 1,
      data: resp
    }
  } catch (err) {
   
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    return final_res;
  }

}

async function func_getAmenitiesStationMapping() {

  let resp;
  let final_res;

  let stmt = `select sam.id as map_id, sam.station_id,sam.amenity_id , am.name as amenity_name ,
    am.icon_url ,am.status as amenity_status
    from station_amenity_mapping sam 
    inner join amenity_mst am on sam.amenity_id = am.id and am.status = 'Y'
    where sam.status = 'Y' order by display_order ;`;

  try {
    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'FAILED',
      count : 1,
      data: resp
    }
  } catch (err) {
   
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    return final_res;
  }

}

module.exports = {
  ChargingStation: ChargingStation
};