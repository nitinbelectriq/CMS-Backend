const { sql, pool } = require("./db.js");
const _utility = require("../utility/_utility");
const User = function (user) {
  this.id = user.id;
  this.code = user.code;
  this.role_id = user.role_id,
  this.cpo_id = user.cpo_id;
  this.user_id = user.user_id;
  this.default_role = user.default_role;
  this.username = user.username;
  this.password = user.password;
  this.f_Name = user.f_Name;
  this.m_Name = user.m_Name;
  this.l_Name = user.l_Name;
  this.dob = user.dob;
  this.mobile = user.mobile;
  this.alt_mobile = user.alt_mobile;
  this.email = user.email;
  this.address1 = user.address1;
  this.address2 = user.address2;
  this.PIN = user.PIN;
  this.landmark = user.landmark;
  this.city_id = user.city_id;
  this.state_id = user.state_id;
  this.country_id = user.country_id;
  this.PAN = user.PAN;
  this.aadhar = user.aadhar;
  this.device_id = user.device_id;
  this.app_version = user.app_version;
  this.os_version = user.os_version;
  this.is_favourite = user.is_favourite;
  this.station_id = user.station_id;
  this.user_type = user.user_type;
  this.client_id = user.client_id;
  this.can_expire = user.can_expire;
  this.hint_question = user.hint_question;
  this.hint_answer = user.hint_answer;
  this.last_pass_change = user.last_pass_change;
  this.last_login_date = user.last_login_date;
  this.employee_code = user.employee_code;
  this.is_verified = user.is_verified;
  this.otp = user.otp;
  this.registration_origin = user.registration_origin;
  this.roles = user.roles;
  this.status = user.status;
  this.created_date = user.created_date;
  this.created_by = user.created_by;
  this.modify_date = user.modify_date;
  this.modify_by = user.modify_by;
};

User.create = async (newUser, result) => {
  var datetime = new Date();
  let final_res;
  let resp;
  let resp1;
  let values = [];

  let stmt = `INSERT INTO user_mst_new
  (cpo_id,username,password,f_Name,m_Name,l_Name,dob,mobile,alt_mobile,email,
  address1,address2,PIN,landmark,city_id,state_id,country_id,PAN,aadhar,
  user_type,client_id,can_expire,employee_code,is_verified,registration_origin,status,
  created_date,createdby)
  VALUES
  (${newUser.cpo_id},'${newUser.username}','${newUser.password}','${newUser.f_Name}','${newUser.m_Name}','${newUser.l_Name}',
  '${newUser.dob}','${newUser.mobile}','${newUser.alt_mobile}','${newUser.email}','${newUser.address1}','${newUser.address2}',${newUser.PIN},
  '${newUser.landmark}',${newUser.city_id},${newUser.state_id},${newUser.country_id},'${newUser.PAN}',
   '${newUser.aadhar}','${newUser.user_type}',${newUser.client_id},'${newUser.can_expire}',
   ${newUser.employee_code},'Y','${newUser.registration_origin}','${newUser.status}',?,${newUser.created_by})`;

  let stmt2 = `INSERT INTO user_role_mapping
  (user_id,role_id,default_role,status,created_date,createdby)
  VALUES
  (?,${newUser.role_id},'Y','Y',?,${newUser.created_by});`;


  try {

    resp = await pool.query(stmt, [datetime]);
    resp1 = await pool.query(stmt2, [resp.insertId, datetime]);

    final_res = {
      status: resp.insertId > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.affectedRows > 0 ? 'SUCCESS' : 'FAILED',
      count: 1,
      data: [{ id: resp.insertId }]
    }
  } catch (err) {

    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

User.update = async (newUserdtl, result) => {
  var datetime = new Date();
  let resp1;
  let resp;


  stmt = `update user_mst_new set 
      cpo_id = '${newUserdtl.cpo_id}', f_name = '${newUserdtl.f_Name}',l_Name = '${newUserdtl.l_Name}',dob = '${newUserdtl.dob}',
      mobile = '${newUserdtl.mobile}',alt_mobile = '${newUserdtl.alt_mobile}', user_type = '${newUserdtl.user_type}',
      email = '${newUserdtl.email}',client_id = '${newUserdtl.client_id}',
      PAN = '${newUserdtl.PAN}',aadhar ='${newUserdtl.aadhar}',
      address1='${newUserdtl.address1}'  ,address2 ='${newUserdtl.address2}' ,PIN =${newUserdtl.PIN} ,
      landmark ='${newUserdtl.landmark}' ,city_id=${newUserdtl.city_id} ,state_id=${newUserdtl.state_id} ,
      country_id=${newUserdtl.country_id} ,	   
      modifyby = ${newUserdtl.modify_by},modify_date = ? ,status='${newUserdtl.status}' 
      where id =  ${newUserdtl.id}`;

  let stmt2 = `UPDATE user_role_mapping
      SET
      user_id =? ,role_id =${newUserdtl.role_id},status ='${newUserdtl.status}' ,modify_date = ?, modifyby =${newUserdtl.modify_by}
      WHERE user_id =${newUserdtl.id} `;

  try {



    resp = await pool.query(stmt, [datetime]);
    resp1 = await pool.query(stmt2, [newUserdtl.id, datetime]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.affectedRows > 0 ? 'SUCCESS' : 'FAILED',
      count: 1,
      data: [{ id: newUserdtl.id }]
    }
  } catch (err) {

    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }
};

User.getUsersCW = async (user_id, result) => {

  let final_res;
  let resp;
  let stmt = '';
  let clientAndRoleDetails = await _utility.getClientIdAndRoleByUserId(user_id);

  let client_id = clientAndRoleDetails.data[0].client_id;
  let role_code = clientAndRoleDetails.data[0].role_code;
  if (role_code == 'SA') {
    stmt = `select umn.id,umn.cpo_id,urm.role_id,rm.name as role_name,cm.name as cpo_name,umn.client_id,cmm.name as client_name,umn.username,umn.f_name,umn.m_name,umn.l_name,umn.dob,umn.mobile,umn.alt_mobile,umn.email,
     umn.employee_code,umn.registration_origin,
     umn.PAN,umn.aadhar,
     umn.address1  ,umn.address2  ,umn.PIN  ,umn.landmark  ,umn.city_id ,umn.state_id ,umn.country_id ,
     umn.status,umn.created_date,umn.createdby,umn.modifyby,umn.modify_date
     from user_mst_new  umn  inner join cpo_mst cm  on umn.cpo_id = cm.id 
     inner join client_mst cmm on umn.client_id=cmm.id
     left join user_role_mapping urm on umn.id=urm.user_id and urm.default_role='Y'
      left join role_mst rm on urm.role_id=rm.id
     where 
     umn.status= 'Y' 
     order by umn.id desc`;
  } else {
    stmt = `select umn.id,umn.cpo_id,urm.role_id,rm.name as role_name,cm.name as cpo_name,cmm.name as client_name,umn.client_id,umn.username,umn.f_name,umn.m_name,umn.l_name,umn.dob,umn.mobile,umn.alt_mobile,umn.email,
     umn.employee_code,umn.registration_origin,
      umn.PAN,umn.aadhar,
      umn.address1  ,umn.address2  ,umn.PIN  ,umn.landmark  ,umn.city_id ,umn.state_id ,umn.country_id ,
      umn.status,umn.created_date,umn.createdby,umn.modifyby,umn.modify_date
      from user_mst_new  umn  inner join cpo_mst cm  on umn.cpo_id = cm.id 
      inner join client_mst cmm on umn.client_id=cmm.id
       inner join user_role_mapping urm on umn.id=urm.user_id and urm.default_role='Y'
        inner join role_mst rm on urm.role_id=rm.id
      where    
      umn.status <> 'D' and umn.client_id =${client_id}
      order by umn.id desc`;

  }

  try {

    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count: resp.length,
      data: resp
    }
  } catch (err) {

    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

User.getActiveUsersCW = async (user_id, result) => {
  
  let final_res;
  let resp;
  let stmt = '';
  let clientAndRoleDetails = await _utility.getClientIdAndRoleByUserId(user_id);

  let client_id = clientAndRoleDetails.data[0].client_id;
  let role_code = clientAndRoleDetails.data[0].role_code;
  if (role_code == 'SA') {
    stmt = `select umn.id,umn.cpo_id,cm.name as cpo_name,umn.client_id,cmm.name as client_name,umn.username,umn.f_name,umn.m_name,umn.l_name,umn.dob,umn.mobile,umn.alt_mobile,umn.email,
    umn.employee_code,umn.registration_origin,
    umn.PAN,umn.aadhar,
    umn.address1  ,umn.address2  ,umn.PIN  ,umn.landmark  ,umn.city_id ,umn.state_id ,umn.country_id ,
    umn.status,umn.created_date,umn.createdby,umn.modifyby,umn.modify_date
    from user_mst_new  umn  inner join cpo_mst cm  on umn.cpo_id = cm.id inner join client_mst cmm on umn.client_id=cmm.id
    where 
    umn.status= 'Y' 
    order by umn.id desc`;
    //  stmt = `select umn.id,umn.cpo_id,cm.name as cpo_name,umn.username,umn.f_name,umn.m_name,umn.l_name,umn.dob,umn.mobile,umn.alt_mobile,umn.email,
    //   umn.employee_code,umn.registration_origin,
    //   umn.PAN,umn.aadhar,
    //   umn.address1  ,umn.address2  ,umn.PIN  ,umn.landmark  ,umn.city_id ,umn.state_id ,umn.country_id ,
    //   umn.status,umn.created_date,umn.createdby,umn.modifyby,umn.modify_date
    //   from user_mst_new  umn  inner join cpo_mst cm  on umn.cpo_id = cm.id
    //   where 
    //   umn.status= 'Y' 
    //   order by umn.id desc`;
  } else {
    stmt = `select umn.id,umn.cpo_id,umn.client_id,cmm.name as client_name,cm.name as cpo_name,umn.username,umn.f_name,umn.m_name,umn.l_name,umn.dob,umn.mobile,umn.alt_mobile,umn.email,
    umn.employee_code,umn.registration_origin,
     umn.PAN,umn.aadhar,
     umn.address1  ,umn.address2  ,umn.PIN  ,umn.landmark  ,umn.city_id ,umn.state_id ,umn.country_id ,
     umn.status,umn.created_date,umn.createdby,umn.modifyby,umn.modify_date
     from user_mst_new  umn  inner join cpo_mst cm  on umn.cpo_id = cm.id inner join client_mst cmm on umn.client_id=cmm.id
     where 
     umn.status='Y' and umn.client_id =${client_id}
     order by umn.id desc`;
    //  stmt = `select umn.id,umn.cpo_id,cm.name as cpo_name,umn.username,umn.f_name,umn.m_name,umn.l_name,umn.dob,umn.mobile,umn.alt_mobile,umn.email,
    //  umn.employee_code,umn.registration_origin,
    //   umn.PAN,umn.aadhar,
    //   umn.address1  ,umn.address2  ,umn.PIN  ,umn.landmark  ,umn.city_id ,umn.state_id ,umn.country_id ,
    //   umn.status,umn.created_date,umn.createdby,umn.modifyby,umn.modify_date
    //   from user_mst_new  umn  inner join cpo_mst cm  on umn.cpo_id = cm.id
    //   where 
    //   umn.status='Y' and umn.client_id = ${client_id}
    //   order by umn.id desc`;

  }

  try {

    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count: resp.length,
      data: resp
    }
  } catch (err) {
    ;
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

User.getActiveUsersByClient = async (client_id, result) => {
  
  let final_res;
  let resp;
  let stmt = '';
 
    stmt = `select umn.id,umn.cpo_id,umn.client_id,cmm.name as client_name,cm.name as cpo_name,umn.username,umn.f_name,umn.m_name,umn.l_name,umn.dob,umn.mobile,umn.alt_mobile,umn.email,
    umn.employee_code,umn.registration_origin,
     umn.PAN,umn.aadhar,
     umn.address1  ,umn.address2  ,umn.PIN  ,umn.landmark  ,umn.city_id ,umn.state_id ,umn.country_id ,
     umn.status,umn.created_date,umn.createdby,umn.modifyby,umn.modify_date
     from user_mst_new  umn  inner join cpo_mst cm  on umn.cpo_id = cm.id inner join client_mst cmm on umn.client_id=cmm.id
     where 
     umn.status='Y' and umn.client_id =${client_id}
     order by umn.id desc`;
    

  try {

    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count: resp.length,
      data: resp
    }
  } catch (err) {
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

User.getUserById = (id, result) => {

  // let stmt = `select id,username,f_name,m_name,l_name,dob,mobile,alt_mobile,email,hint_question,
  //       hint_answer,last_login_date,employee_code,registration_origin,user_type,
  //       PAN,aadhar,
  //     address1  ,address2  ,PIN  ,landmark  ,city_id ,state_id ,country_id ,
  //       status,   created_date,createdby,modifyby,modify_date from user_mst_new
  //       where  id=? and  status <> 'D'`;
  let stmt = `SELECT umn.cpo_id,umn.id,cm.name as client_name,umn.client_id,umn.code,umn.username,umn.password,
  umn.f_Name,umn.m_Name,umn.l_Name,umn.dob,umn.mobile,umn.alt_mobile,
  umn.email,umn.address1,umn.address2,umn.PIN,umn.landmark,umn.city_id,umn.state_id,umn.country_id,
  umn.PAN,umn.aadhar,umn.device_id,umn.app_version,umn.os_version,umn.user_type,umn.client_id,
  umn.can_expire,umn.hint_question,umn.hint_answer,umn.last_pass_change,umn.last_login_date,
  umn.employee_code,umn.is_verified,umn.otp, umn.registration_origin,umn.status,
  umn.created_date,umn.createdby,umn.modify_date,umn.modifyby
  FROM user_mst_new umn inner join client_mst cm on umn.client_id=cm.id where  umn.id= ? and  umn.status <> 'D';`;
  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

User.userChargingHistory = async (id, result) => {


  let whereClause = ``;
  if (id > 0) {
    whereClause = ` where ucl.user_id = ${id}  `
  }

  let stmt = `select ucl.id ,ucl.user_id as user_id_start, CONCAT(um.f_Name, " ", um.l_Name) as user_name_start ,
  ucl.user_id_stop as user_id_stop ,CONCAT(um2.f_Name, " ", um2.l_Name) as user_name_stop,
  ucl.vehicle_id ,ucl.vehicle_number ,
  ucl.mobile ,ucl.mobile_stop ,ucl.charger_display_id ,ucl.connector_no ,ucl.id_tag ,
  ucl.station_id , csm.name as station_name,ucl.charger_transaction_id ,ucl.charging_status ,ucl.action ,
  ucl.message_id ,ucl.message_code ,ucl.meter_reading ,ucl.energy_consumed ,
  ucl.initial_soc ,ucl.final_soc ,ucl.duration ,ucl.auth_status ,ucl.meter_start_value ,
  ucl.meter_start_time ,ucl.meter_stop_value ,ucl.meter_stop_time ,ucl.command_source ,
  ucl.device_id ,ucl.app_version ,ucl.os_version ,ucl.command_source_stop ,ucl.device_id_stop ,
  ucl.app_version_stop ,ucl.os_version_stop ,
  ucl.status ,ucl.created_date ,ucl.createdby ,ucl.modify_date ,ucl.modifyby 
  from user_charging_log ucl 
  left join user_mst_new um on ucl.user_id = um.id
  left join user_mst_new um2 on ucl.user_id_stop = um2.id
  left join charging_station_mst csm on ucl.station_id = csm.id
  ${whereClause} order by id desc;`;

  let res;
  let final_res;

  try {
    //;
    res = await pool.query(stmt, [id]);

    final_res = {
      status: true,
      message: res.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: res.length,
      data: res
    }

  } catch (e) {
    //;
    final_res = {
      status: false,
      message: `ERROR : ${e.code} `,
      count: 0,
      data: []
    }
  } finally {
    return (final_res);
  }



  // sql.query(stmt, id, (err, res) => {
  //   if (err) {
  //     result(null, err);
  //     return;
  //   }

  //   if (res.affectedRows == 0) {
  //     // not found Customer with the id
  //     result({ kind: "not_found" }, null);
  //     return;
  //   }

  //   result(null, res);
  // });
};

User.delete = async (id, user_id, result) => {

  var datetime = new Date();
  let resp1;
  let resp

  let stmt = `Update user_mst_new set  modifyby = ${user_id},modify_date = ? , status = 'D' WHERE id = ${id}`;

  let stmt2 = `UPDATE user_role_mapping
  SET
  status ='D' ,modify_date = ?, modifyby =${user_id}
  WHERE user_id =${id} `;

  try {



    resp = await pool.query(stmt, [datetime]);
    resp1 = await pool.query(stmt2, [datetime]);
    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.affectedRows > 0 ? 'SUCCESS' : 'FAILED',
      count: 1,
      data: [{ id }]
    }
  } catch (err) {

    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

User.userStationMapping = async (newPrefranc, result) => {

  var datetime = new Date();
  let final_res;
  let resp;
  let resp2;
  let values = [];

  let stmt3 = ` select user_id,station_id from user_preference_mst 
                   where station_id =${newPrefranc.station_id} and user_id=${newPrefranc.id} and  status='Y'`;

  let stmt = `insert into user_preference_mst (user_id,station_id,is_favourite,status,
      created_date,created_by )
      VALUES ('${newPrefranc.id}','${newPrefranc.station_id}','${newPrefranc.is_favourite}',
      '${newPrefranc.status}',?,${newPrefranc.created_by})`;


  try {
    resp2 = await pool.query(stmt3)
    resp = await pool.query(stmt, [datetime])

    if (resp3.length > 0) {
      final_res = {
        status: false,
        err_code: `ERROR : ${err.code}`,
        message: `ERROR : ${err.message}`,
        data: []
      }
    } else {
      resp = await pool.query(stmt, [newPrefranc.id, newPrefranc.station_id, newPrefranc.status]);

      final_res = {
        status: resp.insertId > 0 ? true : false,
        err_code: `ERROR : 0`,
        message: resp.insertId > 0 ? 'SUCCESS' : 'FAILED',
        count: 1,
        data: [{ id: resp.insertId }]
      }

    }

  } catch (err) {
    final_res = {
      status: false,
      message: `ERROR : ${err.code}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }


  // try {
  //   
  //   resp = await pool.query(stmt,values);

  //   final_res = {
  //     status: resp.insertId > 0 ? true : false,
  //     err_code: `ERROR : 0`,
  //     message: resp.insertId > 0 ? 'SUCCESS' : 'FAILED',
  //     count : 1,
  //     data: [{id : resp.insertId}]
  //   }
  // } catch (err) {
  //   
  //   final_res = {
  //     status: false,
  //     err_code: `ERROR : ${err.code}`,
  //     message: `ERROR : ${err.message}`,
  //     count : 0,
  //     data: []
  //   }
  // } finally {
  //   result(null, final_res);
  // }
};

User.updateUserStationMapping = async (newUser, result) => {

  var datetime = new Date();

  let stmt = ` update user_preference_mst set 
  is_favourite = ${newUser.is_favourite},    
  status = '${newUser.status}',
  modify_by = ${newUser.modify_by}, modify_date = ?
  where user_id = ${newUser.id} and station_id = ${newUser.station_id}`;

  try {

    // resp = await pool.query(stmt);


    resp = await pool.query(stmt, [datetime]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.affectedRows > 0 ? 'SUCCESS' : 'FAILED',
      count: 1,
      data: [{ id: newUser.id }]
    }
  } catch (err) {
  
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }
};
User.getRoleListWithRolesAssignedToUserCW = async (client_id,user_id, project_id, result) => {
  
  let final_res;
  let resp;
  let stmt;
  // let clientAndRoleDetails = await _utility.getClientIdAndRoleByUserId(user_id);
  // let client_id = clientAndRoleDetails.data[0].client_id;
  // let role_code = clientAndRoleDetails.data[0].role_code;

  // if (role_code == 'SA') {
  //   stmt = `selecT rm.id,rm.code as role_code,rm.name as role_name,rm.client_id,
  //   urm.id as map_id, urm.default_role,urm.user_id,urm.status as map_status,
  //   urm.created_date,urm.createdby,urm.modify_date,urm.modifyby
  //   from role_mst rm 
  //   left join user_role_mapping urm on  rm.id=urm.role_id and urm.user_id=${user_id} and urm.status='Y'
  //   where rm.status='Y' and rm.project_id=${project_id};`;

  // } else {

    stmt = `select rm.id,rm.code as role_code,rm.name as role_name,rm.client_id,
    urm.id as map_id, urm.default_role,urm.user_id,urm.status as map_status,
    urm.created_date,urm.createdby,urm.modify_date,urm.modifyby
    from role_mst rm 
    left join user_role_mapping urm on  rm.id=urm.role_id and urm.user_id=${user_id} and urm.status='Y'
    where rm.status='Y' and rm.client_id=${client_id} and rm.project_id=${project_id};`;

  // }

  try {

    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count: resp.length,
      data: resp
    }
  } catch (err) {

    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }


};

User.getUserRoleMappingCW = async (login_id, project_id, result) => {

  let final_res;
  let resp;
  let stmt;
  let clientAndRoleDetails = await _utility.getClientIdAndRoleByUserId(login_id);
  let client_id = clientAndRoleDetails.data[0].client_id;
  let role_code = clientAndRoleDetails.data[0].role_code;

  if (role_code == 'SA') {
    // stmt = `select rm.id,rm.code as role_code,rm.name as role_name,rm.client_id,
    // urm.id as map_id, urm.default_role,urm.user_id,urm.status as map_status,
    // urm.created_date,urm.createdby,urm.modify_date,urm.modifyby
    // from user_role_mapping urm 
    // inner join role_mst rm on urm.role_id=rm.id and rm.status='Y' and rm.project_id=${project_id}
    // inner join user_mst_new umn on urm.user_id=umn.id and umn.status='Y'  
    // where urm.status='Y' order by urm.id ;`;
    stmt = `select umn.f_name,umn.l_name, umn.username, rm.id as role_id,rm.code as role_code,rm.name as role_name,rm.client_id,
    cm.name as client_name,urm.id as map_id, urm.default_role,urm.user_id,urm.status as map_status,
    urm.created_date,urm.createdby,urm.modify_date,urm.modifyby
    from user_role_mapping urm 
    inner join role_mst rm on urm.role_id=rm.id and rm.status='Y' and rm.project_id=${project_id}
    inner join user_mst_new umn on urm.user_id=umn.id and umn.status='Y' 
    inner join client_mst cm on umn.client_id = cm.id and cm.status='Y'
    where urm.status='Y' order by urm.id ;`;

  } else {

    stmt = `select umn.f_name,umn.l_name, umn.username, rm.id as role_id,rm.code as role_code,rm.name as role_name,rm.client_id,
    cm.name as client_name,urm.id as map_id, urm.default_role,urm.user_id,urm.status as map_status,
    urm.created_date,urm.createdby,urm.modify_date,urm.modifyby
    from user_role_mapping urm 
    inner join role_mst rm on urm.role_id=rm.id and rm.status='Y' and rm.project_id=${project_id}
    inner join user_mst_new umn on urm.user_id=umn.id and umn.status='Y' and  umn.client_id=${client_id}
    inner join client_mst cm on umn.client_id = cm.id and cm.status='Y'
    where urm.status='Y' order by urm.id ;`;
    // stmt = `select rm.id,rm.code as role_code,rm.name as role_name,rm.client_id,
    // urm.id as map_id, urm.default_role,urm.user_id,urm.status as map_status,
    // urm.created_date,urm.createdby,urm.modify_date,urm.modifyby
    // from role_mst rm 
    // left join user_role_mapping urm on  rm.id=urm.role_id and urm.user_id=${user_id} and urm.status='Y'
    // where rm.status='Y' and rm.client_id=${client_id} and rm.project_id=${project_id};`;

  }

  try {

    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count: resp.length,
      data: resp
    }
  } catch (err) {

    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }


};


User.updateUserRoleMapping = async (newUser, result) => {

  var datetime = new Date();

  let stmt = `update user_role_mapping set 
  role_id =${newUser.role_id},status = '${newUser.status}',default_role='${newUser.default_role}',   
  modifyby = ${newUser.modify_by}, modify_date = ?
  where id=${newUser.id} and user_id =${newUser.user_id} and status='Y'`;
 

  try {
 
    resp = await pool.query(stmt, [datetime]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.affectedRows > 0 ? 'SUCCESS' : 'FAILED',
      count: 1,
      data: [{ id: newUser.id }]
    }
  } catch (err) {
   
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }
};

User.userRoleMapping = async (newRole, result) => {
  var datetime = new Date();
  let final_res;
  let resp1;
  let resp2;
  let resp3;
  let resp4;
  let values = [];
  let roles_mapped = [];
  let roles_not_mapped = [];

 debugger;

let stmt1= `update user_role_mapping set 
  status = 'N',  modifyby = ? , modify_date = ?
  where  user_id =${newRole.user_id} and status='Y'`;

  let stmt2 = `select id,default_role from user_role_mapping 
  where user_id =${newRole.user_id} and role_id= ? `;

  let stmt3 = `insert into user_role_mapping (user_id,role_id,default_role,status,created_date,createdby)
  VALUES ? `;

  let stmt4 = `update user_role_mapping set default_role=? ,
  status = 'Y',  modifyby = ?, modify_date = ?
  where  id = ? `;

  try {
    debugger;

    resp1 = await pool.query(stmt1,[newRole.created_by,datetime]);


    for (let index = 0; index < newRole.roles.length; index++) {

     
      resp2 = await pool.query(stmt2, [newRole.roles[index].role_id])
      

      if (resp2.length > 0) {
        if (resp2[0].default_role == newRole.roles[index].default_role) {
          resp3 = await pool.query(stmt4, [newRole.roles[index].default_role,newRole.roles[index].modify_by,newRole.roles[index].modify_date,newRole.roles[index].map_id])
        } else {
          resp3 = await pool.query(stmt4, [newRole.roles[index].default_role,newRole.created_by,datetime,newRole.roles[index].map_id])
        }
      } else {
        values.push([newRole.user_id,newRole.roles[index].role_id,newRole.roles[index].default_role,newRole.status, datetime, newRole.created_by])

        roles_mapped.push({
          role_id: newRole.roles[index].role_id,          
          remarks: 'SUCCESS'
        })

      }
    }
    
    if (values.length > 0) {

      resp4 = await pool.query(stmt3, [values]);
    } else {
    }
    

    final_res = {
      status:  true ,
      err_code: `ERROR : 0`,
      message: 'SUCCESS' ,
      data: [{
        roles_not_mapped: roles_not_mapped,
        roles_mapped: roles_mapped
      }]
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }


};

User.deleteUserRoleMapping = async (id, user_id, result) => {

  var datetime = new Date();
  let resp1;
  let resp
 
  let stmt = `Update user_role_mapping set  modifyby = ${user_id},modify_date = ? , status = 'D' WHERE id =${id};`;

  let stmt2 = `select id,role_id,default_role from user_role_mapping where user_id=${user_id} and status='Y'`;

  try {
    resp1 = await pool.query(stmt2);
    
    if (resp1.length==1) {
      resp = await pool.query(stmt,[datetime]);

      final_res = {
        status:  true ,
        err_code: `ERROR : 0`,
        message: 'SUCCESS',
        count: 0,
        data: []
      }
    } else {
      debugger;
      const resp2 = resp1.filter(role => role.id == id);

      if (resp2[0].default_role=='Y' ) {
        final_res = {
          status:  false ,
          err_code: `ERROR : 1`,
          message: 'Please select another role as default before deleting this role',
          count: 0,
          data: []
        }
      } else {
        resp = await pool.query(stmt,[datetime]);

        final_res = {
          status:  true ,
          err_code: `ERROR : 0`,
          message: 'SUCCESS',
          count: 0,
          data: []
        }
      }
    }


  } catch (err) {

    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

module.exports = { User };