const { sql, pool } = require("./db.js");

// constructor
const RFid = function (rfid) {
  this.id = rfid.id,
    this.name = rfid.name,
    this.description = rfid.description,
    this.rfid_no = rfid.rfid_no,
    this.expiry_date = rfid.expiry_date,
    this.status = rfid.status,
    this.created_date = rfid.created_date,
    this.created_by = rfid.created_by,
    this.modify_date = rfid.modify_date,
    this.modify_by = rfid.modify_by,
    this.client_id = rfid.client_id,
    this.cpo_id = rfid.cpo_id,
    this.rfid_data = rfid.rfid_data
};

RFid.create = (newRfid, result) => {
  var datetime = new Date();

  let stmt = `insert into charger_rfid (name,description,RF_ID_no,expiry_date,
    status,created_date,createdby )
    VALUES ('${newRfid.name}','${newRfid.description}','${newRfid.rfid_no}','${newRfid.expiry_date}',     
    '${newRfid.status}','${datetime.toISOString().slice(0, 10)}',${newRfid.created_by}) `;

  let todo = newRfid;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newRfid });
  });
};

RFid.update = (newRfid, result) => {
  var datetime = new Date();

  let stmt = `update charger_rfid set 
  name = '${newRfid.name}',description = '${newRfid.description}',rf_id_no = '${newRfid.rfid_no}', 
  expiry_date = '${newRfid.expiry_date}', status = '${newRfid.status}',
  modifyby = ${newRfid.modify_by},modify_date = '${datetime.toISOString().slice(0, 10)}' 
  where id=  ${newRfid.id}`;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, { id: res.insertId, ...newRfid });
  });
};

RFid.createCpoRfidMapping = async (data, result) => {
  var datetime = new Date();
  let values = [];
  let final_response = {};
  let created_by = !!data.created_by ? data.created_by : data.modify_by

  try {
    for (let index = 0; index < data.rfid_data.length; index++) {
      values.push([data.client_id, data.cpo_id, data.rfid_data[index].id,
      data.status, created_by, datetime.toISOString().slice(0, 10)])
    }

    let stmt = `update cpo_rfid_mapping set 
      status = 'D' ,
      modify_date = '${datetime.toISOString().slice(0, 10)}' , modifyby = ${created_by} 
      where cpo_id = ${data.cpo_id}  `;

    let resp1 = await pool.query(stmt);
    //

    let stmt2 = `insert into cpo_rfid_mapping (client_id,cpo_id,rfid_id,
    status,createdby,created_date)
    values  ? `;

    let resp2 = await pool.query(stmt2, [values]);
    //

    final_response = {
      status: true,
      message: 'SUCCESS',
      data: []
    }
  } catch (error) {
    //;
    final_response = {
      status: false,
      message: error,
      data: []
    }
  } finally {

    result(null, final_response)
  }

};

RFid.updateCpoRfidMapping = async (data, result) => {
  var datetime = new Date();
  let values = [];
  let final_response = {};
  let created_by = !!data.created_by ? data.created_by : data.modify_by

  try {
    for (let index = 0; index < data.rfid_data.length; index++) {
      values.push([data.client_id, data.cpo_id, data.rfid_data[index].id,
      data.status, created_by, datetime.toISOString().slice(0, 10)])
    }

    let stmt = `update cpo_rfid_mapping set 
      status = 'D' ,
      modify_date = '${datetime.toISOString().slice(0, 10)}' , modifyby = ${created_by} 
      where cpo_id = ${data.cpo_id}  `;

    let resp1 = await pool.query(stmt);
    //

    let stmt2 = `insert into cpo_rfid_mapping (client_id,cpo_id,rfid_id,
    status,createdby,created_date)
    values  ? `;

    let resp2 = await pool.query(stmt2, [values]);
    //

    final_response = {
      status: true,
      message: 'SUCCESS',
      data: []
    }
  } catch (error) {
    //;
    final_response = {
      status: false,
      message: error,
      data: []
    }
  } finally {

    result(null, final_response)
  }

};


RFid.getRFids = result => {

  let stmt = `select id,  name,description,rf_id_no,expiry_date,
    status,created_date,createdby,modifyby,modify_date
      from charger_rfid
      where status <> 'D'
      order by id desc`;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

RFid.getCpoRFidMappingCW = (login_id,result) => {

  let stmt='';
  let clientAndRoleDetails = await _utility.getClientIdAndRoleByUserId(login_id);
  let client_id = clientAndRoleDetails.data[0].client_id;
  let role_code = clientAndRoleDetails.data[0].role_code;
  if(role_code=='SA'){

  stmt = `select crm.id as map_id,  cr.name as rfid_name ,cr.description,cr.rf_id_no,cr.expiry_date,
    CRM.CLIENT_ID, cm.name as cpo_name, clm.name as client_name,
    crm.status,crm.created_date,crm.createdby,crm.modifyby,crm.modify_date
    from  cpo_rfid_mapping  crm inner join charger_rfid cr on crm.rfid_id=cr.id  and cr.status = 'Y'
    inner join cpo_mst cm on crm.cpo_id = cm.id and cm.status = 'Y'
    inner join client_mst clm on cm.client_id = clm.id and clm.status = 'Y'
    where crm.status <> 'D' 
    order by crm.id desc;`;

    }else{
      stmt = `select crm.id as map_id,  cr.name as rfid_name ,cr.description,cr.rf_id_no,cr.expiry_date,
      CRM.CLIENT_ID, cm.name as cpo_name, clm.name as client_name,
      crm.status,crm.created_date,crm.createdby,crm.modifyby,crm.modify_date
      from  cpo_rfid_mapping  crm inner join charger_rfid cr on crm.rfid_id=cr.id  and cr.status = 'Y'
      inner join cpo_mst cm on crm.cpo_id = cm.id and cm.status = 'Y'
      inner join client_mst clm on cm.client_id = clm.id and clm.status = 'Y'
      where crm.status <> 'D' and crm.client_id = ${client_id}
      order by crm.id desc;`;
    }

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

RFid.getRFidsByCpoId = async (cpo_id, result) => {

  let final_res;
  let resp;

  // let stmt = ` select cr.status,crm.id ,crm.client_id , cm.name as client_name,  crm.cpo_id, 
  // cpom.name as cpo_name ,cr.id as rfid_id, cr.rf_id_no as rfid_no, cr.expiry_date, 
  // crm.status ,  crm.created_date ,  crm.createdby ,  crm.modify_date,  crm.modifyby 
  // from cpo_rfid_mapping crm inner join client_mst cm on crm.client_id = cm.id and cm.status='Y'
  // inner join cpo_mst cpom on crm.cpo_id = cpom.id and cpom.status='Y'
  // inner join  charger_rfid cr on crm.rfid_id = cr.id  and cr.status='Y'
  // where crm.cpo_id = ? and crm.status<>'D' order by crm.cpo_id ;`;

  let stmt = `select crm.id as map_id,  cr.name as rfid_name ,cr.description,cr.rf_id_no,cr.expiry_date,
  CRM.CLIENT_ID, cm.name as cpo_name, clm.name as client_name,
  crm.status,crm.created_date,crm.createdby,crm.modifyby,crm.modify_date
  from  cpo_rfid_mapping  crm inner join charger_rfid cr on crm.rfid_id=cr.id  and cr.status = 'Y'
  inner join cpo_mst cm on crm.cpo_id = cm.id and cm.status = 'Y'
  inner join client_mst clm on cm.client_id = clm.id and clm.status = 'Y'
  where crm.status <> 'D' and crm.cpo_id = ?
  order by crm.id desc;`;
  
  try {

    resp = await pool.query(stmt,[cpo_id]);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count: resp.length,
      data: resp
    }
  } catch (err) {

    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }
};

RFid.getAllRFidsWithMappedCPOs = async (cpo_id, result) => {

  let stmt = ` select crm.id , crm.cpo_id,crm.id ,crm.client_id , cm.name as client_name,  crm.cpo_id, cpom.name as cpo_name ,
  cr.id as rfid_id, cr.rf_id_no as rfid_no, cr.expiry_date, 
  crm.status ,  crm.created_date ,  crm.createdby ,  crm.modify_date,  crm.modifyby
  from charger_rfid cr 
  left join cpo_rfid_mapping crm on cr.id = crm.rfid_id and crm.status='Y'
  left join client_mst cm on crm.client_id = cm.id and cm.status='Y'
  left join  cpo_mst cpom on crm.cpo_id = cpom.id and cpom.status='Y'
   where cr.status ='Y' and (crm.cpo_id = ? or crm.cpo_id is null) ;`;

  let final_res;
  let resp;

  try {
    resp = await pool.query(stmt, [cpo_id]);
    final_res = {
      status: true,
      message: 'DATA_FOUND',
      count : resp.length,
      data: resp
    }
  } catch (error) {
    final_res = {
      status: false,
      message: 'DATA_NOT_FOUND',
      count : 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

RFid.getRFno_ById = (id, result) => {

  let stmt = `select id,  name,description,rf_id_no,expiry_date
    status,created_date,createdby,modifyby,modify_date
      from charger_rfid
      WHERE id = ?`;
  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

RFid.delete = (id,user_id, result) => {
  var datetime = new Date();
  let stmt = `Update charger_rfid set status = 'D' ,
  modify_date = ? , modifyby = ?
  WHERE id = ?`;

  sql.query(stmt, [datetime,user_id,id], (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};


RFid.unMapRFidCpoID = async (id,user_id, result) => {
  var datetime = new Date();
  let stmt = `Update cpo_rfid_mapping set status = 'D' ,
  modify_date = ? , modifyby = ?
  WHERE id = ? `;

  let final_res;
  let resp;

  try {
    resp = await pool.query(stmt, [datetime,user_id,id]);

    if (resp.affectedRows > 0) {
      final_res = {
        status: true,
        message: 'DELETED',
        data: []
      }
    } else {
      final_res = {
        status: false,
        message: 'DATA_NOT_FOUND',
        data: []
      }
    }

  } catch (error) {
    //
    final_res = {
      status: false,
      message: 'DATA_NOT_FOUND',
      data: []
    }
  } finally {
    //  
    result(null, final_res);
  }
};

module.exports = {
  RFid: RFid
};