const mysql = require('mysql');
const util = require('util');
const dbConfig = require("../config/db.config.js");

const connection = mysql.createConnection({
  host: dbConfig.HOST,
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  database: dbConfig.DB,
  port : dbConfig.PORT
});


const pool = mysql.createPool({
  connectionLimit : 100, //important
  host: dbConfig.HOST,
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  database: dbConfig.DB,
  port : dbConfig.PORT
});

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL Server!');
});

pool.query = util.promisify(pool.query);

//for future use
// pool.getConnection((err, connection) => {
//   console.log('sql connection');
//   if (err) {
//       console.log(err);
//       if (err.code === 'PROTOCOL_CONNECTION_LOST') {
//           console.error('Database connection was closed.');
//       }
//       if (err.code === 'ER_CON_COUNT_ERROR') {
//           console.error('Database has too many connections.');
//       }
//       if (err.code === 'ECONNREFUSED') {
//           console.error('Database connection was refused.');
//       }
//   }

//   if (connection) connection.release();

//   return
// })


module.exports = {sql : connection,pool};

