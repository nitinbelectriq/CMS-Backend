const { sql, pool } = require("./db.js");

// constructor
const Transaction = function (charger) {
  this.id = charger.id,
    this.name = charger.name,
    this.serial_no = charger.serial_no,
    this.batch_id = charger.batch_id,
    this.station_id = charger.station_id,
    this.model_id = charger.model_id,
    this.current_version_id = charger.current_version_id,
    this.no_of_guns = charger.no_of_guns,
    this.address1 = charger.address1;
  this.address2 = charger.address2;
  this.PIN = charger.PIN;
  this.landmark = charger.landmark;
  this.city_id = charger.city_id;
  this.state_id = charger.state_id;
  this.country_id = charger.country_id;
  this.Lat = charger.Lat,
    this.Lng = charger.Lng,
    this.OTA_Config = charger.OTA_Config,
    this.Periodic_Check_Ref_Time = charger.Periodic_Check_Ref_Time,
    this.Periodicity_in_hours = charger.Periodicity_in_hours,
    this.When_to_Upgrade = charger.When_to_Upgrade,
    this.Upgrade_Specific_Time = charger.Upgrade_Specific_Time,
    this.is_available = charger.is_available,
    this.status = charger.status,
    this.created_date = charger.created_date,
    this.created_by = charger.created_by,
    this.modify_date = charger.modify_date,
    this.modify_by = charger.modify_by,
    this.connector_data = charger.connector_data
};

 
const TransactionList = function (chargerValues) {
  this.id = chargerValues.id,
    this.charger_id = chargerValues.charger_id,
    this.station_id = chargerValues.station_id,
    this.meter_reading = chargerValues.is_available,
    this.status = chargerValues.status,
    this.created_on = chargerValues.created_on  
    this.fdate= chargerValues.fdate,
    this.todate=chargerValues.todate 
};
//-----------Start Analytics--------------------------------//

TransactionList.getTransactionList = async (params, result) => {
  stmt = `SELECT charger_id, count(transaction_id) as total_transaction
  FROM meter_log
  WHERE date(created_on) BETWEEN '${params.fdate}' AND '${params.todate}' and action='StartTransaction' 
  GROUP BY (charger_id)
  ORDER BY charger_id;`
  let final_res;
  let resp;
  //--------------------------------
  try {
    resp = await pool.query(stmt);
    final_resp = resp;
    if (resp.length > 0) {
     // let children = await getMappedConnectors();

      for (let p = 0; p < resp.length; p++) {
        const parent = resp[p];
      //  final_resp[p].connector_data = [];

        // for (let c = 0; c < children.res.length; c++) {
        //   const child = children.res[c];

        //   if (parent.charger_id == child.charger_id) {
        //     final_resp[p].connector_data.push(child);
        //   }

        // }

      }
    }

    resp = {
      status: true,
      message: final_resp.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: final_resp.length,
      data: final_resp
    }
  } catch (err) {
    resp = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    result(null, resp);
  }

  //----------------------------
  // 
  // sql.query(stmt, async (err, res) => {

  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   if (res.length) {
  //    // let children = await getMappedConnectors();

  //     let final_res = res;

  //     for (let p = 0; p < res.length; p++) {
  //       const parent = res[p];
  //       final_res[p].connector_data = [];

  //       // for (let c = 0; c < children.res.length; c++) {
  //       //   const child = children.res[c];

  //       //   if (parent.id == child.charger_id) {
  //       //     final_res[p].connector_data.push(child);
  //       //   }
  //       // }
  //     }

  //     result(null, final_res);
  //     return;
  //   }

  //   result({ kind: "not_found" }, null);
  // });

};

TransactionList.getDurationList = async (params, result) => {
  stmt = `select ml.charger_id,sum(ml.meter_reading)/1000 AS total_energy_consumed
  from meter_log ml,charger_station_mapping csm where date(ml.created_on) BETWEEN '${params.fdate}' and '${params.todate}'
   and action='StartTransaction'  
   GROUP BY (ml.charger_id)
  ORDER BY ml.charger_id;`
  let final_res;
  let resp;
  //--------------------------------
  try {
    resp = await pool.query(stmt);
    final_resp = resp;
    if (resp.length > 0) {
     
      for (let p = 0; p < resp.length; p++) {
        const parent = resp[p];
       
      }
    }

    resp = {
      status: true,
      message: final_resp.length > 0 ? 'DATA_FOUND' : 'DATA_NOT_FOUND',
      count: final_resp.length,
      data: final_resp
    }
  } catch (err) {
    resp = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    result(null, resp);
  }

  
};

//------------End Analytics---------------------------------//


module.exports = {
  TransactionList:TransactionList
  
};