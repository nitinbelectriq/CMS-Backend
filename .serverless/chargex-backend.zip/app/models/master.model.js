const { sql, pool } = require("./db.js");

const Master = function (master) {
  this.id = master.id,
  this.code = master.code,
  this.name = master.name,
  this.description = master.description,
  this.status = master.status,
  this.created_date = master.created_date,
  this.created_by = master.created_by,
  this.modify_date = master.modify_date,
  this.modify_by = master.modify_by
};

const Country = function (country) {
  this.id = country.id,
    this.name = country.name,
    this.description = country.description,
    this.iso_code = country.iso_code,
    this.country_code = country.country_code,
    this.status = country.status,
    this.created_date = country.created_date,
    this.created_by = country.created_by,
    this.modify_date = country.modify_date,
    this.modify_by = country.modify_by
};

const State = function (state) {
  this.id = state.id,
    this.country_id = state.country_id,
    this.name = state.name,
    this.description = state.description,
    this.status = state.status,
    this.created_date = state.created_date,
    this.created_by = state.created_by,
    this.modify_date = state.modify_date,
    this.modify_by = state.modify_by
};

const City = function (city) {
  this.id = city.id,
    this.state_id = city.state_id,
    this.name = city.name,
    this.description = city.description,
    this.status = city.status,
    this.created_date = city.created_date,
    this.created_by = city.created_by,
    this.modify_date = city.modify_date,
    this.modify_by = city.modify_by
};

const Question = function (question) {
  this.id = question.id,
  this.question = question.question,
  this.description = question.description,
  this.status = question.status,
  this.created_date = question.created_date,
  this.created_by = question.created_by,
  this.modify_date = question.modify_date,
  this.modify_by = question.modify_by
};

const ChargerConfigurationKey = function (master) {
  this.id = master.id,
    this.name = master.name,
    this.description = master.description,
    this.data_type = master.data_type,
    this.max_length = master.max_length,
    this.min_length = master.min_length,
    this.display_order = master.display_order,
    this.status = master.status,
    this.created_date = master.created_date,
    this.created_by = master.created_by,
    this.modify_date = master.modify_date,
    this.modify_by = master.modify_by
};

Master.getLocationTypes = result => {

  let stmt = `select id, name , description,
      status,created_date,createdby,modifyby,modify_date
      from location_type_mst 
      where status <> 'D'
      order by name `;
  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

Master.getChargerRegistrationTypes = result => {

  let stmt = `select id, name , description,
      status,created_date,createdby,modifyby,modify_date
      from charger_registration_type_mst 
      where status <> 'D'
      order by name `;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

Master.getElectricitylineTypes = result => {

  let stmt = `select id, name , description,
      status,created_date,createdby,modifyby,modify_date
      from electricity_line_type_mst 
      where status <> 'D'
      order by name `;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};


Country.createCountry = async (data, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt2 = `insert into country_mst (name,description,iso_code,country_code,
    status,createdby,created_date) values (?) `;
  let values = [data.name,data.description,data.iso_code,data.country_code,
    data.status, data.created_by, datetime];
  try {
    resp = await pool.query(stmt2,[values]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: [{id:resp.insertId} ]
    }
  } catch (err) {
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

Country.updateCountry = async (data, result) => {
  var datetime = new Date();
  let final_res;
  let resp;
debugger
  let stmt2 = `update country_mst set name = ? , description = ? ,iso_code = ? ,country_code = ?,
    status = ?,modifyby = ? ,modify_date = ? where id = ? `;
 
  try {
    
    resp = await pool.query(stmt2,[data.name,data.description,data.iso_code,data.country_code,
      data.status, data.modify_by, datetime, data.id]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: []
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

Country.deleteCountry = async (id, user_id, result) => {
  var datetime = new Date();
  let final_res;
  let resp;
debugger
  let stmt2 = `Update country_mst set status = 'D',
  modifyby = ?, modify_date = ?
  WHERE id = ?`;
 
  try {
    
    resp = await pool.query(stmt2,[user_id,datetime,id]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: []
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};


Country.getCountries = result => {
  let stmt = `SELECT id,name, description,status, created_date, modify_date 
    FROM country_mst where status='Y' order by name`;
  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};


Country.getAllCountries = async( result) => {
  let final_res;
  let resp;

  let stmt = `SELECT id,name, description,iso_code,country_code,status, created_date, modify_date 
    FROM country_mst where status<>'D' order by name`;

    try {
      resp = await pool.query(stmt);
  
      final_res = {
        status: resp.length > 0 ? true : false,
        message: resp.length> 0 ? 'SUCCESS' :'NOT FOUND',
        data: resp
      }
    } catch (err) {
      
      final_res = {
        status: false,
        err_code: `ERROR : ${err.code}`,
        message: `ERROR : ${err.message}`,
        data: []
      }
    } finally {
      result(null, final_res);
    }

  // sql.query(stmt, (err, res) => {
  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   if (res.length) {
  //     result(null, res);
  //     return;
  //   }

  //   result({ kind: "not_found" }, null);
  // });
};



State.createState = async (data, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt2 = `insert into state_mst (name,description,country_id,
    status,createdby,created_date) values (?) `;
  let values = [data.name,data.description,data.country_id,
    data.status, data.created_by, datetime];
  try {
    resp = await pool.query(stmt2,[values]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: [{id:resp.insertId} ]
    }
  } catch (err) {
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

State.updateState = async (data, result) => {
  var datetime = new Date();
  let final_res;
  let resp;
debugger
  let stmt2 = `update state_mst set name = ? , description = ? ,country_id = ? ,
    status = ?,modifyby = ? ,modify_date = ? where id = ? `;
 
  try {
    
    resp = await pool.query(stmt2,[data.name,data.description,data.country_id,
      data.status, data.modify_by, datetime, data.id]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: []
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

State.deleteState = async (id, user_id, result) => {
  var datetime = new Date();
  let final_res;
  let resp;
debugger
  let stmt2 = `Update state_mst set status = 'D',
  modifyby = ?, modify_date = ?
  WHERE id = ?`;
 
  try {
    
    resp = await pool.query(stmt2,[user_id,datetime,id]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: []
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};


State.getAllStates = async result => {

  let final_res;
  let resp;

  let stmt = `SELECT sm.id, sm.country_id,cm.name as country_name, sm.name , sm.description,
  sm.status, sm.created_date, sm.createdby  
  FROM state_mst sm inner join country_mst cm on sm.country_id = cm.id 
  where sm.status<>'D' order by sm.name`;

    try {
      resp = await pool.query(stmt);
  
      final_res = {
        status: resp.length > 0 ? true : false,
        message: resp.length> 0 ? 'SUCCESS' :'NOT FOUND',
        count : resp.length,
        data: resp
      }
    } catch (err) {
      
      final_res = {
        status: false,
        err_code: `ERROR : ${err.code}`,
        message: `ERROR : ${err.message}`,
        count : 0,
        data: []
      }
    } finally {
      result(null, final_res);
    }


  // let stmt = `SELECT sm.id, sm.country_id as country_name, sm.name , sm.description,
  //   sm.status, sm.created_date, sm.createdby  
  //   FROM state_mst sm inner join country_mst cm on sm.country_id = cm.id 
  //   where sm.status='Y' order by sm.name`;

  // sql.query(stmt, (err, res) => {
  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   if (res.length) {
  //     result(null, res);
  //     return;
  //   }

  //   // not found Customer with the id
  //   result({ kind: "not_found" }, null);
  // });
};

State.getStates =  result => {
  let stmt = `SELECT sm.id, sm.country_id,cm.name as country_name, sm.name , sm.description,
    sm.status, sm.created_date, sm.createdby  
    FROM state_mst sm inner join country_mst cm on sm.country_id = cm.id 
    where sm.status='Y' order by sm.name`;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};



Country.getCountryByState = (id, result) => {
  var datetime = new Date();

  let stmt = `SELECT cm.id,cm.name , cm.status,cm.created_date,cm.createdby  
    FROM  country_mst cm inner join state_mst sm on cm.id = sm.country_id   
    where sm.id = ? and cm.status='Y' order by cm.name`;

  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.affectedRows == 0) {
      return;
    }
    result(null, res);
  });
};
State.getStateByCountry = (id, result) => {
  var datetime = new Date();

  let stmt = `SELECT sm.id,sm.name , sm.status,sm.created_date,sm.createdby  
    FROM  state_mst sm inner join country_mst cm on sm.country_id=cm.id    
    where cm.id= ? and sm.status='Y' order by sm.name`;

  sql.query(stmt, id, (err, res) => {

    if (err) {
      result(err, null);
      return;
    }

    result(null, res);
  });
};


City.createCity = async (data, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt2 = `insert into city_mst (name,description,state_id,
    status,createdby,created_date) values (?) `;
  let values = [data.name,data.description,data.state_id,
    data.status, data.created_by, datetime];
  try {
    resp = await pool.query(stmt2,[values]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: [{id:resp.insertId} ]
    }
  } catch (err) {
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

City.updateCity = async (data, result) => {
  var datetime = new Date();
  let final_res;
  let resp;
debugger
  let stmt2 = `update city_mst set name = ? , description = ? ,state_id = ? ,
    status = ?,modifyby = ? ,modify_date = ? where id = ? `;
 
  try {
    
    resp = await pool.query(stmt2,[data.name,data.description,data.state_id,
      data.status, data.modify_by, datetime, data.id]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: []
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};

City.deleteCity = async (id, user_id, result) => {
  var datetime = new Date();
  let final_res;
  let resp;
debugger
  let stmt2 = `Update city_mst set status = 'D',
  modifyby = ?, modify_date = ?
  WHERE id = ?`;
 
  try {
    
    resp = await pool.query(stmt2,[user_id,datetime,id]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      message: resp.affectedRows> 0 ? 'SUCCESS' :'FAILED',
      data: []
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      data: []
    }
  } finally {
    result(null, final_res);
  }

};


City.getAllCities = async result => {
  let final_res;
  let resp;
  let stmt = `SELECT cm.id,cm.state_id,sm.name as state_name, cm.name, cm.description,cm.status,cm.created_date,cm.createdby  
      FROM city_mst cm inner join state_mst sm on cm.state_id = sm.id 
      where cm.status<>'D' order by cm.name `;

      try {
        resp = await pool.query(stmt);
    
        final_res = {
          status: resp.length > 0 ? true : false,
          message: resp.length> 0 ? 'SUCCESS' :'NOT FOUND',
          count : resp.length,
          data: resp
        }
      } catch (err) {
        
        final_res = {
          status: false,
          err_code: `ERROR : ${err.code}`,
          message: `ERROR : ${err.message}`,
          count : 0,
          data: []
        }
      } finally {
        result(null, final_res);
      }
};




City.getCities = result => {

  let stmt = `SELECT cm.id,cm.state_id,sm.name as state_name, cm.name, cm.description,cm.status,cm.created_date,cm.createdby   
      FROM city_mst cm inner join state_mst sm on cm.state_id = sm.id 
      where cm.status='Y' order by cm.name `;

  sql.query(stmt, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};


City.getCityByState = (id, result) => {
  var datetime = new Date();

  let stmt = `SELECT cm.id,cm.name , cm.status,cm.created_date,cm.createdby  
    FROM  city_mst cm   inner join state_mst sm on cm.state_id=sm.id   
    where sm.id = ? and cm.status='Y' order by cm.name`;

  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, res);
  });
};

State.getStateByCity = (id, result) => {
  var datetime = new Date();

  let stmt = `SELECT sm.id,sm.name , sm.status,sm.created_date,sm.createdby  
        FROM  state_mst sm   inner join city_mst cm on sm.id=cm.state_id   
        where cm.id = ? and sm.status='Y' order by sm.name`;

  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, res);
  });
};

Country.getCountryStateByPIN = (pin, result) => {
  var datetime = new Date();

  let stmt = `select spm.id as map_id,spm.pin,spm.created_date,spm.createdby,sm.id as state_id,
    sm.name as state_name,cm.id as country_id,cm.name as country_name
    from state_PIN_mapping spm 
    inner join state_mst sm on spm.state_id = sm.id and sm.status = 'Y'
    inner join country_mst cm on sm.country_id = cm.id and cm.status = 'Y'
    where spm.PIN = ? and spm.status = 'Y';`;

  sql.query(stmt, pin, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }

    result(null, res);
  });
};


ChargerConfigurationKey.getChargerConfigurationKeys = (result) => {

  let final_res;

  let stmt = `select id ,name,description,data_type,max_length,min_length,display_order,status,
    created_date,createdby,modify_date,modifyby 
    from charger_config_mst where status = 'Y'`;
  debugger
  sql.query(stmt, (err, res) => {
    debugger
    if (err) {

      final_res = {
        status: false,
        message: `ERROR : ${err.code}`,
        data: []
      }
      result(null, final_res);
      return;
    }

    if (res.length > 0) {
      final_res = {
        status: true,
        message: 'DATA_FOUND',
        count: res.length,
        data: res
      }
    } else {
      final_res = {
        status: false,
        message: 'DATA_NOT_FOUND',
        count: 0,
        data: []
      }
    }

    result(null, final_res);
  });
};

Question.getQuestions = async result => {
  let final_res;
  let resp;
  let stmt = `SELECT qm.id, qm.question, qm.description,
    qm.status,qm.created_date,qm.createdby  
    FROM question_mst qm 
    where qm.status='Y' order by qm.question `;

      try {
        resp = await pool.query(stmt);
    
        final_res = {
          status: resp.length > 0 ? true : false,
          message: resp.length> 0 ? 'SUCCESS' :'DATA NOT FOUND',
          count : resp.length,
          data: resp
        }
      } catch (err) {
        
        final_res = {
          status: false,
          err_code: `ERROR : ${err.code}`,
          message: `ERROR : ${err.message}`,
          count : 0,
          data: []
        }
      } finally {
        result(null, final_res);
      }
};


Master.getProjects = async (params, result) => {

  let final_res;
  let resp;
  

  let stmt =`select id,code,name,description,status,createdby,created_date
  from project_mst
  order by name `;

  try {
   
    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count : resp.length,
      data: resp
    }
  } catch (err) {
  
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    return final_res;
  }
};


Master.getProjectsByCode = async (project_code, result) => {

  let final_res;
  let resp;
  

  let stmt =`select id,code,name,description,status,createdby,created_date
  from project_mst
  where code = '${project_code}'
  order by name `;

  try {
   
    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count : resp.length,
      data: resp
    }
  } catch (err) {
  
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    return  final_res;
  }
};

Master.getNavListByUserId = async (login_id,project_id, result) => {

  let final_res;
  let resp;
  let arr_final_nav_list;
  let arr_nav_list_L1;
  let arr_nav_list_L2;
  let arr_nav_list_L3;
  let arr_nav_list_L4;
  let arr_nav_list_L5;

//role based for fututre
  let stmt =`SELECT mm.id as table_id,mm.nav_level , mm.nav_id as id , mm.title, mm.type,
    mm.icon,mm.url,mm.icon_url,mm.parent_id
    FROM menu_mst mm where mm.status = 'Y' and mm.project_id=${project_id} 
    order by mm.display_order;`;

  try {
   
    debugger;
    resp = await pool.query(stmt);

    arr_nav_list_L1 = resp.filter(x=>x.parent_id == null);
    arr_nav_list_L2 = resp.filter(x=>x.nav_level == 2);
    arr_nav_list_L3 = resp.filter(x=>x.nav_level == 3);
    arr_nav_list_L4 = resp.filter(x=>x.nav_level == 4);
    arr_nav_list_L5 = resp.filter(x=>x.nav_level == 5);

    let childL5 ;
    if(arr_nav_list_L5.length>0){
      for (let iL4 = 0; iL4 < arr_nav_list_L4.length; iL4++) {

        childL5 = arr_nav_list_L5.filter(x=>x.parent_id==arr_nav_list_L4[iL4].table_id) ;
        if(childL5.length>0) arr_nav_list_L4[iL4].children = childL5;
        
      }
    }

    let childL4 ;
    if(arr_nav_list_L4.length>0){
      for (let iL3 = 0; iL3 < arr_nav_list_L3.length; iL3++) {

        childL4 = arr_nav_list_L4.filter(x=>x.parent_id==arr_nav_list_L3[iL3].table_id) ;
        if(childL4.length>0) arr_nav_list_L3[iL3].children = childL4;
        
      }
    }

    let childL3 ;
    if(arr_nav_list_L3.length>0){
      for (let iL2 = 0; iL2 < arr_nav_list_L2.length; iL2++) {

        childL3 = arr_nav_list_L3.filter(x=>x.parent_id==arr_nav_list_L2[iL2].table_id) ;
        if(childL3.length>0) arr_nav_list_L2[iL2].children = childL3;
        
      }
    }

    let childL2 ;
    if(arr_nav_list_L2.length>0){
      for (let iL1 = 0; iL1 < arr_nav_list_L1.length; iL1++) {

        childL2 = arr_nav_list_L2.filter(x=>x.parent_id==arr_nav_list_L1[iL1].table_id) ;
        if(childL2.length>0) arr_nav_list_L1[iL1].children = childL2;
        
      }
    }

    arr_final_nav_list = arr_nav_list_L1;

    debugger;
    final_res = {
      status: arr_final_nav_list.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: arr_final_nav_list.length > 0 ? 'SUCCESS' : 'DATA NOT FOUND',
      count : arr_final_nav_list.length,
      data: arr_final_nav_list
    }
  } catch (err) {
  
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    return  final_res;
  }
};



module.exports = {
  Master: Master,
  Country: Country,
  State: State,
  City: City,
  ChargerConfigurationKey: ChargerConfigurationKey,
  Question: Question
};