const {sql,pool} = require("./db.js");

const Brand = function(brand) {
    this.id = brand.id ,
    this.name = brand.name ,
    this.description = brand.description,
    this.status = brand.status ,
    this.created_date = brand.created_date ,
    this.created_by = brand.created_by,
    this.modify_date = brand.modify_date ,
    this.modify_by = brand.modify_by
};

Brand.getAll = result => {
  sql.query("SELECT id,name FROM vehicle_brand_mst where status = 'Y' order by name", (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    result(null, res);
  });
};

module.exports = Brand;