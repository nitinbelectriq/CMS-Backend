var otpGenerator = require('otp-generator');
const request = require('request');
const { sql, pool } = require("../models/db");

function generateOTP() {
    let newOTP = 0;

    newOTP = otpGenerator.generate(6, { alphabets: false, upperCase: false, specialChars: false });

    return newOTP;
}

function generatePassword() {
    let newPassword = 0;
    
    newPassword = otpGenerator.generate(6, { alphabets: true, upperCase: false, specialChars: true });

    return newPassword;
}

async function sendOTP(action, otp, mobile_no, email) {

    let text;
    let entity_id = '1401366180000014430';
    let template_id = '1407159912792781073';
    // if(action == 'FORGOT_PASSWORD'){
    //     text = `Please find the OTP ${otp} to reset your password`;
    //     template_id = 1407159912792781073;
    // }else if(action == 'REGISTER'){
    //     text = `Please find your OTP ${otp} for one time registration`;
    //     template_id = 1407159912792781073;
    // }else if(action == 'RESEND'){
    //     text = `Please find your OTP ${otp} for one time registration`;
    //     template_id = 1407159912792781073;
    // }
    text = `Your OTP is ${otp}`
    // let url = `http://onex-ultimo.in/api/pushsms?user=Exicom2019&authkey=92DhnvBR183E&sender=Exichg&
    // mobile=${mobile_no}&text=${text}&rpt=1`;
    
    let url = `http://www.onex-ultimo.in/api/pushsms?user=Exicom2019&authkey=92l5MK3SZjFJk&sender=Exichg&mobile=${mobile_no}&entityid=${entity_id}&templateid=${template_id}&text=${text}&rpt=1&summary=1&output=json`;

    let promise = new Promise((resolve, reject) => {
        request(url, { json: true }, (err, res, body) => {
            

            if (err) {
                resolve({
                    status: false,
                    message: err.code
                });
                return console.log('errrrrrr', err);
            }

            if (body.STATUS == "ERROR") {

                resolve({
                    status: false,
                    message: body.RESPONSE
                });
                // return console.log(`body : ${body.battery_log} , bin no : ${batteryId}`);
            } else {
                resolve({
                    status: true,
                    message: body.RESPONSE
                });
            }


        });
    });

    return await promise;
}

async function getClientIdAndRoleByUserId(user_id) {

    var datetime = new Date();
    let final_res;
    let resp;

    
  let stmt = ` select umn.client_id, cm.name , urm.id as role_id , rm.code as role_code, 
    rm.name as role_name
    from user_mst_new umn left join client_mst cm on umn.client_id = cm.id and cm.status='Y'
    left join user_role_mapping urm on umn.id = urm.user_id and urm.status = 'Y'
    left join role_mst rm on urm.role_id = rm.id and rm.status = 'Y'
    where umn.id = ${user_id} and umn.status='Y' `;

  try {
    
    resp = await pool.query(stmt);

    final_res = {
      status: resp.length > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.length > 0 ? 'SUCCESS' : 'FAILED',
      count : 1,
      data: resp
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    return final_res;
  }
    
}

module.exports = {
    generateOTP,
    sendOTP,
    generatePassword,
    getClientIdAndRoleByUserId
}