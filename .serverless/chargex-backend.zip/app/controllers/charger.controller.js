const myModule = require("../models/charger.model.js");

const Charger = myModule.Charger;  
const ChargerStationMap = myModule.ChargerStationMap;  
const ClientChargerMap = myModule.ClientChargerMap;  

exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  
  // Create a Vehicle
  const charger = new Charger({
    name : req.body.name ,
    serial_no : req.body.serial_no,
    batch_id : req.body.batch_id ,
    station_id : req.body.station_id,
    model_id : req.body.model_id,
    current_version_id : req.body.current_version_id ,
    no_of_guns : req.body.no_of_guns,
    
    address1  :  !!req.body.address1 ? req.body.address1 : '' ,
    address2  :  !!req.body.address2 ? req.body.address2 : '' ,
    PIN  :  !!req.body.PIN ? req.body.PIN : 0 ,
    landmark  :  !!req.body.landmark ? req.body.landmark : '' ,
    city_id  :  !!req.body.city_id ? req.body.city_id : 0 ,
    state_id  :  !!req.body.state_id ? req.body.state_id : 0 ,
    country_id  :  !!req.body.country_id ? req.body.country_id : 0 ,
    
    Lat : req.body.Lat,
    Lng : req.body.Lng,
    OTA_Config : !!req.body.OTA_Config ? req.body.OTA_Config : 0,
    Periodic_Check_Ref_Time : !!req.body.Periodic_Check_Ref_Time ? req.body.Periodic_Check_Ref_Time : '2000-01-01 00:00:00',
    Periodicity_in_hours : !!req.body.Periodicity_in_hours ? req.body.Periodicity_in_hours : 12,
    When_to_Upgrade : !!req.body.When_to_Upgrade ? req.body.When_to_Upgrade : 'IMMEDIATE',
    Upgrade_Specific_Time : !!req.body.Upgrade_Specific_Time ? req.body.Upgrade_Specific_Time : '00:00:00',
    is_available : req.body.is_available,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by,
    connector_data : req.body.connector_data

  });

  // Save Customer in the database
  Charger.create(charger, (err, data) => {
    res.send(data);
  });
};

exports.update = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const charger = new Charger({
    id : req.body.id,
    name : req.body.name ,
    serial_no : req.body.serial_no,
    batch_id : req.body.batch_id ,
    model_id : req.body.model_id,
    station_id : req.body.station_id,
    current_version_id : req.body.current_version_id ,
    no_of_guns : req.body.no_of_guns,
    address1  :  !!req.body.address1 ? req.body.address1 : '' ,
    address2  :  !!req.body.address2 ? req.body.address2 : '' ,
    PIN  :  !!req.body.PIN ? req.body.PIN : 0 ,
    landmark  :  !!req.body.landmark ? req.body.landmark : '' ,
    city_id  :  !!req.body.city_id ? req.body.city_id : 0 ,
    state_id  :  !!req.body.state_id ? req.body.state_id : 0 ,
    country_id  :  !!req.body.country_id ? req.body.country_id : 0 ,
    Lat : req.body.Lat,
    Lng : req.body.Lng,
    OTA_Config : req.body.OTA_Config,
    Periodic_Check_Ref_Time : req.body.Periodic_Check_Ref_Time,
    Periodicity_in_hours : req.body.Periodicity_in_hours,
    When_to_Upgrade : req.body.When_to_Upgrade,
    Upgrade_Specific_Time : req.body.Upgrade_Specific_Time,
    is_available : req.body.is_available,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by,
    connector_data : req.body.connector_data
  });

  // Save Customer in the database
  Charger.update(charger, (err, data) => {
    res.send(data);
  });
};

exports.dispatchChargers = (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const clientChargerMap = new ClientChargerMap({
    id : req.body.id,
    charger_id : req.body.charger_id,
    client_id : req.body.client_id,
    sub_client_id : req.body.sub_client_id,
    dispatch_status : req.body.dispatch_status,
    dispatch_by : req.body.dispatch_by,
    dispatch_date : req.body.dispatch_date,
    status : req.body.status,
    created_date : req.body.created_date,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date,
    modify_by : req.body.modify_by,
    charger_data : req.body.charger_data
  });

  // Save Customer in the database
  ClientChargerMap.dispatchChargers(clientChargerMap, (err, data) => {
    res.send(data);
  });
};

exports.updateClientChargers = (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const clientChargerMap = new ClientChargerMap({
    id : req.body.id,
    charger_id : req.body.charger_id,
    client_id : req.body.client_id,
    sub_client_id : req.body.sub_client_id,
    dispatch_status : req.body.dispatch_status,
    dispatch_by : req.body.dispatch_by,
    dispatch_date : req.body.dispatch_date,
    status : req.body.status,
    created_date : req.body.created_date,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date,
    modify_by : req.body.modify_by,
    charger_data : req.body.charger_data
  });
  // Save Customer in the database
  ClientChargerMap.updateClientChargers(clientChargerMap, (err, data) => {
    res.send(data);
  });
};

exports.addChargerToStation = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Vehicle
  const chargerStationMap = new ChargerStationMap({
    id : req.body.id,
    charger_id : req.body.charger_id ,
    station_id : req.body.station_id,
    is_available : req.body.is_available,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  ChargerStationMap.addChargerToStation(chargerStationMap, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Customer."
      });
    else res.send(data);
  });
};


exports.addChargerToStationMultiple = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Vehicle
  const chargerStationMap = new ChargerStationMap({
    id : req.body.id,
    charger_id : req.body.charger_id ,
    station_id : req.body.station_id,
    is_available : req.body.is_available,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by,
    charger_data: req.body.charger_data
  });

  // Save Customer in the database
  ChargerStationMap.addChargerToStationMultiple(chargerStationMap, (err, data) => {
    
    res.send(data);
  });
};

exports.removeChargerFromStation = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Vehicle
  const chargerStationMap = new ChargerStationMap({
    id : req.body.id,
    charger_id : req.body.charger_id ,
    station_id : req.body.station_id,
    is_available : req.body.is_available,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  ChargerStationMap.removeChargerFromStation(chargerStationMap, (err, data) => {
   res.send(data);
  });
};

exports.getChargers = (req, res) => {

  Charger.getChargers( (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id "
        });
      }
    } else res.send(data);
  });
};

exports.getChargersDynamicFilter = (req, res) => {

  Charger.getChargersDynamicFilter(req.body, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id "
        });
      }
    } else res.send(data);
  });
};

exports.getPlantChargers = (req, res) => {

  Charger.getPlantChargers( (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id "
        });
      }
    } else res.send(data);
  });
};

exports.getClientChargers = (req, res) => {
  let userDetails = req.body.userDetails[0];
  Charger.getClientChargers( userDetails,(err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id "
        });
      }
    } else res.send(data);
  });
};

exports.getClientChargersNotMappedToAnyStation = (req, res) => {
  let client_id = req.params.client_id;
  
  Charger.getClientChargersNotMappedToAnyStation( client_id,(err, data) => {
    
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id "
        });
      }
    } else res.send(data);
  });
};

exports.getChargersByStationId = (req, res) => {
  Charger.getChargersByStationId(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Chargers with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Chargers with id " + req.params.id
        });
      }
    } else res.send(data);
  });
};

exports.getChargersByMappedStationId = (req, res) => {
  Charger.getChargersByMappedStationId(req.params.id, (err, data) => {
    res.send(data);
  });
};

exports.getChargerById = (req, res) => {
  Charger.getChargerById(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id " + req.params.id
        });
      }
    } else res.send(data);
  });
};

exports.getChargerByDisplayId = (req, res) => {
  
  let display_id = req.params.display_id.trim().toUpperCase();
  Charger.getChargerByDisplayId(display_id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.name}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id " + req.params.name
        });
      }
    } else res.send(data);
  });
};

exports.getChargersByClient_CPO_StationId = (req, res) => {
  
  Charger.getChargersByClient_CPO_StationId(req.body, (err, data) => {
     res.send(data);
  });
};

exports.getAllChargersByUserId = (req, res) => {
  Charger.getAllChargersByUserId(req.params.id, (err, data) => {
     res.send(data);
  });
};

exports.getChargerBySerialNo = (req, res) => {
  let params = {
    srNo : req.params.srNo,
    station_id : req.params.station_id
  }

  Charger.getChargerBySerialNo(params , (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with srNo " + req.params
        });
      }
    } else res.send(data);
  });
};


exports.delete = (req, res) => {
  Charger.delete(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `Not found vehicle with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Customer with id " + req.params.id
        });
      }
    } else res.send({ message: `Customer was deleted successfully!` });
  });
};

exports.deleteChargerFromClient = (req, res) => {
  Charger.deleteChargerFromClient(req.params.id,req.params.user_id, (err, data) => {
    res.status(200).send(data);
  });
};

