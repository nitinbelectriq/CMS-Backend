const Manufacturers = require("../models/manufacturer.model.js");

exports.getManufacturers = (req, res) => {
    Manufacturers.getManufacturers((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving io types."
            });
        else res.send(data);
    });
};