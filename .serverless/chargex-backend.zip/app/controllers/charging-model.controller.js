const myModule = require("../models/charging-model.model.js");

const ChargingModel = myModule.ChargingModel;  

exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  const chargingModel = new ChargingModel({
    id : req.body.id,
    client_id : req.body.client_id,
    charger_type_id : req.body.charger_type_id,
    manufacturer_id : req.body.manufacturer_id ,
    charger_model_type_id : req.body.charger_model_type_id,
    battery_backup : req.body.battery_backup,
    code : req.body.code,
    name : req.body.name,
    description : req.body.description,
    communication_protocol_id : req.body.communication_protocol_id,
    communication_mode : req.body.communication_mode,
    card_reader_type : req.body.card_reader_type,
    no_of_connectors : req.body.no_of_connectors,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by,
    connector_data : req.body.connector_data
  });

  // Save Customer in the database
  ChargingModel.create(chargingModel, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Customer."
      });
    else res.send(data);
  });
};

exports.update = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Vehicle
  const chargingModel = new ChargingModel({
    id : req.body.id,
    client_id : req.body.client_id,
    charger_type_id : req.body.charger_type_id,
    manufacturer_id : req.body.manufacturer_id ,
    charger_model_type_id : req.body.charger_model_type_id,
    battery_backup : req.body.battery_backup,
    code : req.body.code,
    name : req.body.name,
    description : req.body.description,
    communication_protocol_id : req.body.communication_protocol_id,
    communication_mode : req.body.communication_mode,
    card_reader_type : req.body.card_reader_type,
    no_of_connectors : req.body.no_of_connectors,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by,
    connector_data : req.body.connector_data
  });

  // Save Customer in the database
  ChargingModel.update(chargingModel, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Customer."
      });
    else res.send(data);
  });
};

exports.getChargingModels = (req, res) => {
  ChargingModel.getChargingModels( (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id "
        });
      }
    } else res.send(data);
  });
};

exports.getChargingModelsAll = (req, res) => {
  ChargingModel.getChargingModelsAll( (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id "
        });
      }
    } else res.send(data);
  });
};

exports.getChargingModelById = (req, res) => {
  ChargingModel.getChargingModelById(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id " + req.params.id
        });
      }
    } else res.send(data);
  });
};

exports.getChargingModelByClientId = (req, res) => {
  ChargingModel.getChargingModelByClientId(req.params.client_id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.client_id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with client_id " + req.params.client_id
        });
      }
    } else res.send(data);
  });
};

exports.getChargingModelByChargerTypeId = (req, res) => {
  ChargingModel.getChargingModelByChargerTypeId(req.params.charger_type_id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.charger_type_id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with charger_type_id " + req.params.charger_type_id
        });
      }
    } else res.send(data);
  });
};


exports.delete = (req, res) => {
  ChargingModel.delete(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `Not found vehicle with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Customer with id " + req.params.id
        });
      }
    } else res.send({ message: `Customer was deleted successfully!` });
  });
};

