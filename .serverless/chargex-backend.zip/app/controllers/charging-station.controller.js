const myModule = require("../models/charging-station.model");

const ChargingStation = myModule.ChargingStation;  

exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Vehicle
  const chargingStation = new ChargingStation({
    cpo_id : req.body.cpo_id,
    name : req.body.name ,
    code : req.body.code ,
    description : req.body.description,

    // address : req.body.address,
    // pin : req.body.pin,
    address1  :  !!req.body.address1 ? req.body.address1 : '' ,
    address2  :  !!req.body.address2 ? req.body.address2 : '' ,
    PIN  :  !!req.body.PIN ? req.body.PIN : 0 ,
    landmark  :  !!req.body.landmark ? req.body.landmark : '' ,
    city_id  :  !!req.body.city_id ? req.body.city_id : 0 ,
    state_id  :  !!req.body.state_id ? req.body.state_id : 0 ,
    country_id  :  !!req.body.country_id ? req.body.country_id : 0 ,

    lat : req.body.lat,
    lng : req.body.lng,
    location_type_id : req.body.location_type_id,
    cp_name : req.body.cp_name,
    mobile : req.body.mobile,
    email : req.body.email,
    commissioned_dt : req.body.commissioned_dt,
    register_as : req.body.register_as,
    electricity_line_id : req.body.electricity_line_id,
    o_time : req.body.o_time,
    c_time : req.body.c_time,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by

  });

  // Save Customer in the database
  ChargingStation.create(chargingStation, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Customer."
      });
    else res.send(data);
  });
};

exports.update = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Vehicle
  const chargingStation = new ChargingStation({
    id : req.body.id,
    cpo_id : req.body.cpo_id,
    name : req.body.name ,
    code : req.body.code ,
    description : req.body.description,
    
    // address : req.body.address,
    // pin : req.body.pin,
    address1  :  !!req.body.address1 ? req.body.address1 : '' ,
    address2  :  !!req.body.address2 ? req.body.address2 : '' ,
    PIN  :  !!req.body.PIN ? req.body.PIN : 0 ,
    landmark  :  !!req.body.landmark ? req.body.landmark : '' ,
    city_id  :  !!req.body.city_id ? req.body.city_id : 0 ,
    state_id  :  !!req.body.state_id ? req.body.state_id : 0 ,
    country_id  :  !!req.body.country_id ? req.body.country_id : 0 ,

    lat : req.body.lat,
    lng : req.body.lng,
    location_type_id : req.body.location_type_id,
    cp_name : req.body.cp_name,
    mobile : req.body.mobile,
    email : req.body.email,
    commissioned_dt : req.body.commissioned_dt,
    register_as : req.body.register_as,
    electricity_line_id : req.body.electricity_line_id,
    o_time : req.body.o_time,
    c_time : req.body.c_time,
    status : req.body.status ,
    created_date : req.body.created_date ,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date ,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  ChargingStation.update(chargingStation, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Customer."
      });
    else res.send(data);
  });
};

exports.getChargingStations = (req, res) => {
  ChargingStation.getChargingStations( (err, data) => {
    res.status(200).send(data)
  });
};
exports.getAllChargingStationsWithChargersAndConnectors = (req, res) => {
  ChargingStation.getAllChargingStationsWithChargersAndConnectors( (err, data) => {
    res.status(200).send(data)
  });
};
exports.getAllChargingStationsWithChargersAndConnectorsCW = (req, res) => {
  let user_id = req.params.user_id;

  ChargingStation.getAllChargingStationsWithChargersAndConnectorsCW( user_id, (err, data) => {
    res.status(200).send(data)
  });
};
exports.getAllChargingStationsWithChargersAndConnectorsUW = (req, res) => {
  let user_id = req.params.user_id;

  ChargingStation.getAllChargingStationsWithChargersAndConnectorsUW( user_id, (err, data) => {
    res.status(200).send(data)
  });
};

exports.getChargingStationById = (req, res) => {
  ChargingStation.getChargingStationById(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id " + req.params.id
        });
      }
    } else res.send(data);
  });
};

exports.getChargingStationByCpoId = (req, res) => {
  ChargingStation.getChargingStationByCpoId(req.params.cpo_id, (err, data) => {
    res.status(200).send(data)
  });
};

exports.getChargingStationsWithTotalChargersByCPOId = (req, res) => {
  ChargingStation.getChargingStationsWithTotalChargersByCPOId(req.params.cpo_id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.cpo_id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with cpo_id " + req.params.cpo_id
        });
      }
    } else res.send(data);
  });
};

exports.getChargingStationByClientId = (req, res) => {
  ChargingStation.getChargingStationByClientId(req.params.client_id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Charging Station with id ${req.params.client_id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Charging Station with client_id " + req.params.client_id
        });
      }
    } else res.send(data);
  });
};


exports.delete = (req, res) => {
  ChargingStation.delete(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `Not found vehicle with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Customer with id " + req.params.id
        });
      }
    } else res.send({ message: `Customer was deleted successfully!` });
  });
};

