const CommunicationProtocols = require("../models/communication-protocol.model.js");

exports.findAll = (req, res) => {
    CommunicationProtocols.getAll((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving communication protocols."
            });
        else res.send(data);
    });
};