const ChargerModelType = require("../models/charger-model-type.model.js");

exports.findAll = (req, res) => {
    ChargerModelType.getAll((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Charger Model Types."
            });
        else res.send(data);
    });
};