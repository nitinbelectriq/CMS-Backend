const { City } = require("../models/master.model.js");
const myModule = require("../models/master.model.js");

const Master = myModule.Master;
const Country = myModule.Country;
const State = myModule.State;
const Question = myModule.Question;
const ChargerConfigurationKey = myModule.ChargerConfigurationKey;

exports.getLocationTypes = (req, res) => {
  Master.getLocationTypes((err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};
exports.getChargerRegistrationTypes = (req, res) => {
  Master.getChargerRegistrationTypes((err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};
exports.getElectricitylineTypes = (req, res) => {
  Master.getElectricitylineTypes((err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};


exports.createCountry = (req, res) => {
  debugger
  if (!req.body) {
    res.status(200).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const country = new Country({
    id : req.body.id,
    name : req.body.name,
    description : req.body.description,
    iso_code : req.body.iso_code,
    country_code : req.body.country_code,
    status : req.body.status,
    created_date : req.body.created_date,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  Country.createCountry(country, (err, data) => {
    debugger
    res.send(data);
  });
};

exports.updateCountry = (req, res) => {
  debugger
  if (!req.body) {
    res.status(200).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const country = new Country({
    id : req.body.id,
    name : req.body.name,
    description : req.body.description,
    iso_code : req.body.iso_code,
    country_code : req.body.country_code,
    status : req.body.status,
    created_date : req.body.created_date,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  Country.updateCountry(country, (err, data) => {
    debugger
    res.send(data);
  });
};

exports.deleteCountry = (req, res) => {

  // Save Customer in the database
  Country.deleteCountry(req.params.id,req.params.user_id, (err, data) => {
    debugger
    res.status(200).send(data);
  });
};



exports.getAllCountries = (req, res) => {

  Country.getAllCountries((err, data) => {
    res.send(data);
  });
};
exports.getCountries = (req, res) => {

  Country.getCountries((err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};



//CRUD states==========

exports.createState = (req, res) => {
  debugger
  if (!req.body) {
    res.status(200).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const state = new State({
    id : req.body.id,
    country_id : req.body.country_id,
    name : req.body.name,
    description : req.body.description,
    status : req.body.status,
    created_date : req.body.created_date,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  State.createState(state, (err, data) => {
    debugger
    res.send(data);
  });
};

exports.updateState = (req, res) => {
  debugger
  if (!req.body) {
    res.status(200).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const state = new State({
    id : req.body.id,
    country_id : req.body.country_id,
    name : req.body.name,
    description : req.body.description,
    status : req.body.status,
    created_date : req.body.created_date,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  State.updateState(state, (err, data) => {
    debugger
    res.send(data);
  });
};

exports.deleteState = (req, res) => {

  // Save Customer in the database
  State.deleteState(req.params.id,req.params.user_id, (err, data) => {
    debugger
    res.status(200).send(data);
  });
};

exports.getAllStates = (req, res) => {
  State.getAllStates((err, data) => {
   res.send(data);
  });
};

exports.getStates = (req, res) => {
  State.getStates((err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};
exports.getStateByCountry = (req, res) => {

  State.getStateByCountry(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};
exports.getCountryByState = (req, res) => {

  Country.getCountryByState(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};



//CRUD city==========

exports.createCity = (req, res) => {
  debugger
  if (!req.body) {
    res.status(200).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const city = new City({
    id : req.body.id,
    state_id : req.body.state_id,
    name : req.body.name,
    description : req.body.description,
    status : req.body.status,
    created_date : req.body.created_date,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  City.createCity(city, (err, data) => {
    debugger
    res.send(data);
  });
};

exports.updateCity = (req, res) => {
  debugger
  if (!req.body) {
    res.status(200).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Vehicle
  const city = new City({
    id : req.body.id,
    state_id : req.body.state_id,
    name : req.body.name,
    description : req.body.description,
    status : req.body.status,
    created_date : req.body.created_date,
    created_by : req.body.created_by,
    modify_date : req.body.modify_date,
    modify_by : req.body.modify_by
  });

  // Save Customer in the database
  City.updateCity(city, (err, data) => {
    debugger
    res.send(data);
  });
};

exports.deleteCity = (req, res) => {

  // Save Customer in the database
  City.deleteCity(req.params.id,req.params.user_id, (err, data) => {
    debugger
    res.status(200).send(data);
  });
};


exports.getCities = (req, res) => {
  City.getCities((err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};

exports.getAllCities = (req, res) => {
  City.getAllCities((err, data) => {
    res.send(data);
  });
};


exports.getCityByState = (req, res) => {
  City.getCityByState(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};
exports.getStateByCity = (req, res) => {
  State.getStateByCity(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};
exports.getCountryStateByPIN = (req, res) => {

  Country.getCountryStateByPIN(req.params.PIN, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      }
    } else res.send(data);
  });
};

exports.getChargerConfigurationKeys = (req, res) => {

  ChargerConfigurationKey.getChargerConfigurationKeys( (err, data) => {
     res.send(data);
  });
};

exports.getQuestions = (req, res) => {
  Question.getQuestions((err, data) => {
    res.send(data);
  });
};







