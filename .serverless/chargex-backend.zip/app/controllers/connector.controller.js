const Connector = require("../models/connector.model.js");
  


exports.findAllConnectorTypesByVehicleModelId = (req, res) => {
  Connector.getAllConnectorTypesByVehicleModelId(req.params.vehicleModelId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.vehicleModelId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id " + req.params.vehicleModelId
        });
      }
    } else res.send(data);
  });
};
exports.findAllConnectorTypesByVehicleModelIdPublished = (req, res) => {
  Connector.getAllConnectorTypesByVehicleModelIdPublished(req.params.vehicleModelId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.vehicleModelId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id " + req.params.vehicleModelId
        });
      }
    } else res.send(data);
  });
};

exports.findAllConnectorTypesExcludingVModelId = (req, res) => {
  Connector.getAllConnectorTypesExcludingVModelId(req.params.vehicleModelId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `All connector types are mapped with this vehicle model`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving with id " + req.params.vehicleModelId
        });
      }
    } else res.send(data);
  });
};
exports.getAllCTypesExcludingOtherAlreadyMapped = (req, res) => {
  Connector.getAllCTypesExcludingOtherAlreadyMapped(req.params, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.vehicleModelId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id " + req.params.vehicleModelId
        });
      }
    } else res.send(data);
  });
};

exports.findAllConnectorTypes = (req, res) => {
  Connector.getAllConnectorTypes( (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving " 
        });
      }
    } else res.send(data);
  });
};
