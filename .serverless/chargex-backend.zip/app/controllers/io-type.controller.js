const IoTypes = require("../models/io-type.model.js");

exports.findAll = (req, res) => {
    IoTypes.getAll((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving io types."
            });
        else res.send(data);
    });
};