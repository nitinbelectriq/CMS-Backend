const Brand = require("../models/brand.model.js");


exports.create = (req, res) => {
    // Validate request
    if (!req.body) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
    }
  
    const brand = new Brand({
        id : req.body.id ,
        name : req.body.name ,
        description : req.body.description,
        status : req.body.status ,
        created_date : req.body.created_date ,
        created_by : req.body.created_by,
        modify_date : req.body.modify_date ,
        modify_by : req.body.modify_by
    });
  
    // Save Brand in the database
    Brand.create(brand, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Brand."
        });
      else res.send(data);
    });
  };
  
  exports.findAll = (req, res) => {
    Brand.getAll((err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving customers."
        });
      else res.send(data);
    });
  };
  
  exports.findOne = (req, res) => {
    Brand.findById(req.params.customerId, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Brand with id ${req.params.customerId}.`
          });
        } else {
          res.status(500).send({
            message: "Error retrieving Brand with id " + req.params.customerId
          });
        }
      } else res.send(data);
    });
  };
  
  exports.update = (req, res) => {
    // Validate Request
    if (!req.body) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
    }
  
    Brand.updateById(
      req.params.customerId,
      new Brand(req.body),
      (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found Brand with id ${req.params.customerId}.`
            });
          } else {
            res.status(500).send({
              message: "Error updating Brand with id " + req.params.customerId
            });
          }
        } else res.send(data);
      }
    );
  };
  
  exports.delete = (req, res) => {
    Brand.remove(req.params.customerId, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Brand with id ${req.params.customerId}.`
          });
        } else {
          res.status(500).send({
            message: "Could not delete Brand with id " + req.params.customerId
          });
        }
      } else res.send({ message: `Brand was deleted successfully!` });
    });
  };
 
  
  exports.deleteAll = (req, res) => {
    Brand.removeAll((err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while removing all customers."
        });
      else res.send({ message: `All Customers were deleted successfully!` });
    });
  };