const myModule = require("../models/analytics.model.js");

const TransactionList = myModule.TransactionList; 

//---------Start Analytics-----------------------------//
exports.getTransactionList = (req, res) => {

  TransactionList.getTransactionList(req.body, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(200).send({
          message: `NOT_FOUND`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Date with transaction "
        });
      }
    } else res.send(data);
  });
};

exports.getDurationList = (req, res) => {
  
  TransactionList.getDurationList(req.body, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(200).send({
            message: `NOT_FOUND`
          });
        } else {
          res.status(500).send({
            message: "Error retrieving Date with duration "
          });
        }
      } else res.send(data);
    });
  };

//------End Analytics---------------------------------//
 