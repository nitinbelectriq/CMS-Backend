// module.exports = {
//     HOST: "localhost",
//     USER: "root",
//     PASSWORD: "sa",
//     DB: "exicharger",
//     PORT : 3306
//   };
module.exports = {
    HOST: "192.168.170.151",
    USER: "exicharger",
    PASSWORD: "Exi#234#Charger",
    // PASSWORD: "exicharger@321#",
    DB: "exicharger",
    PORT : 3306
  };
// module.exports = {
//     HOST: "192.168.170.151",
//     USER: "exicharger",
//     PASSWORD: "exicharger@111#",
//     // PASSWORD: "exicharger@321#",
//     DB: "exicharger",
//     PORT : 3306
//   };