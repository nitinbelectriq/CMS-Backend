module.exports = {
  secret: 'exicomcmssecretkey123344'
};