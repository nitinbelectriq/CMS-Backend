module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const masters = require("../controllers/master.controller.js");
  
    app.get("/master/getLocationTypes", masters.getLocationTypes);
    app.get("/master/getChargerRegistrationTypes", masters.getChargerRegistrationTypes);
    app.get("/master/getElectricitylineTypes", masters.getElectricitylineTypes);

    app.post("/master/createCountry", masters.createCountry);
    app.post("/master/updateCountry", masters.updateCountry);
    app.delete("/master/deleteCountry/:id/:user_id", masters.deleteCountry);
    app.get("/master/getAllCountries", masters.getAllCountries);
    app.get("/master/getCountries", masters.getCountries);
    app.get("/master/getCountryByState/:id", masters.getCountryByState);

    app.post("/master/createState", masters.createState);
    app.post("/master/updateState", masters.updateState);
    app.delete("/master/deleteState/:id/:user_id", masters.deleteState);
    app.get("/master/getAllStates", masters.getAllStates);
    app.get("/master/getStates", masters.getStates);
    app.get("/master/getStateByCountry/:id", masters.getStateByCountry);
    app.get("/master/getStateByCity/:id", masters.getStateByCity);

    app.post("/master/createCity", masters.createCity);
    app.post("/master/updateCity", masters.updateCity);
    app.delete("/master/deleteCity/:id/:user_id", masters.deleteCity);
    app.get("/master/getAllCities", masters.getAllCities);
    app.get("/master/getCities", masters.getCities);
    app.get("/master/getCityByState/:id", masters.getCityByState);
    app.get("/master/getCountryStateByPIN/:PIN", masters.getCountryStateByPIN);
    app.get("/master/getChargerConfigurationKeys", masters.getChargerConfigurationKeys);

    app.get("/master/getQuestions", masters.getQuestions);


  };