module.exports = app => {
    const users = require("../controllers/user-management.controller.js");

    // create a new User
    app.post("/user/create", users.create);
    // get user
   // app.get("/getusers", users.getUsers);   
      // get user client wise
    app.get("/user/getUsersCW/:user_id", users.getUsersCW); 
    // get active user client wise
    app.get("/user/getActiveUsersCW/:user_id", users.getActiveUsersCW);
    app.get("/user/getActiveUsersByClient/:client_id", users.getActiveUsersByClient);
    app.get("/usermanagement/getUserById/:id", users.getUserById);

    // get active user role mapped client wise
    app.get("/user/getRoleListWithRolesAssignedToUserCW/:client_id/:user_id/:project_id", users.getRoleListWithRolesAssignedToUserCW); 
    app.get("/user/getUserRoleMappingCW/:login_id/:project_id", users.getUserRoleMappingCW); 
    //update user role mapping
    app.post("/user/updateUserRoleMapping", users.updateUserRoleMapping);

     //Save user role mapping in database
     app.post("/user/userRoleMapping", users.userRoleMapping);
      
    //udate user
    app.post("/user/update", users.update);
    app.delete("/user/delete/:id/:user_id", users.delete);
    app.delete("/user/deleteUserRoleMapping/:id/:user_id", users.deleteUserRoleMapping);

    app.get("/user/userChargingHistory/:id", users.userChargingHistory);
    // create a new Role
    app.post("/user/userStationMapping", users.userStationMapping);
    //udate user Station Mapping
    app.post("/user/updateUserStationMapping", users.updateUserStationMapping);
     

    
};