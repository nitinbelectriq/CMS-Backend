module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const chargerMonitorings = require("../controllers/charger-monitoring.controller.js");
  
    // // register a new vehicle
    // app.post("/chargerMonitoring/create", chargerMonitorings.create);

    // // update register a new vehicle
    // app.post("/chargerMonitoring/update", chargerMonitorings.update);

    //get all registered vehicles
    app.get("/chargerMonitoring/getMenus", chargerMonitorings.getMenus);
    app.get("/chargerMonitoring/getAvailabilityType", chargerMonitorings.getAvailabilityType);

    // // Retrieve all vehicleModels
    // app.get("/chargerMonitoring/getCpoById/:id", chargerMonitorings.getCpoById);
    
    // // Retrieve all vehicleModels
    // app.get("/chargerMonitoring/getCpoByClientId/:client_id", chargerMonitorings.getCpoByClientId);

    // // Delete a registered vehicle with id
    // app.delete("/chargerMonitoring/delete/:id", chargerMonitorings.delete);    
  };