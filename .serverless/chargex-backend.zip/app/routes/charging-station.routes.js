module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const chargingStations = require("../controllers/charging-station.controller.js");
  
    // register a new vehicle
    app.post("/chargingStation/create", chargingStations.create);

    // update register a new vehicle
    app.post("/chargingStation/update", chargingStations.update);

    //get all registered vehicles
    app.get("/chargingStation/getChargingStations", chargingStations.getChargingStations);
    app.get("/chargingStation/getAllChargingStationsWithChargersAndConnectors", chargingStations.getAllChargingStationsWithChargersAndConnectors);
    
    //client wise
    app.get("/chargingStation/getAllChargingStationsWithChargersAndConnectorsCW/:user_id", chargingStations.getAllChargingStationsWithChargersAndConnectorsCW);
    
    app.get("/chargingStation/getAllChargingStationsWithChargersAndConnectorsUW/:user_id", chargingStations.getAllChargingStationsWithChargersAndConnectorsUW);

    // Retrieve all vehicleModels
    app.get("/chargingStation/getChargingStationById/:id", chargingStations.getChargingStationById);
    
    // Retrieve all vehicleModels
    app.get("/chargingStation/getChargingStationByCpoId/:cpo_id", chargingStations.getChargingStationByCpoId);
    app.get("/chargingStation/getChargingStationsWithTotalChargersByCPOId/:cpo_id", chargingStations.getChargingStationsWithTotalChargersByCPOId);

    // Retrieve all vehicleModels
    app.get("/chargingStation/getChargingStationByClientId/:client_id", chargingStations.getChargingStationByClientId);

    // Delete a registered vehicle with id
    app.delete("/chargingStation/delete/:id", chargingStations.delete);    
  };