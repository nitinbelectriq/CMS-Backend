const { checkToken } = require('../middleware/jwttoken')

module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const chargerTypes = require("../controllers/charger-type.controller.js");
  
    // register a new vehicle
    app.post("/chargerType/create", chargerTypes.create);
    
    // update register a new vehicle
    app.post("/chargerType/update", chargerTypes.update);

    //get all registered vehicles
    app.get("/chargerType/getChargerTypes", checkToken, chargerTypes.getChargerTypes);

    app.get("/chargerType/getActiveChargerTypes", checkToken, chargerTypes.getActiveChargerTypes);

    // Retrieve all vehicleModels
    app.get("/chargerType/getChargerTypeById/:id", chargerTypes.getChargerTypeById);

    // Delete a registered vehicle with id
    app.delete("/chargerType/delete/:id", chargerTypes.delete);
    
  };