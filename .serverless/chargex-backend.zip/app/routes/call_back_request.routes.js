const { authenticateUser } = require("../middleware/authentication.js");

module.exports = app => {
    const cbr = require("../controllers/call_back_request.controller.js");

    // login to get token
    app.post("/cbr/getCallHistory", cbr.getCallHistory);
    app.get("/cbr/getAllCallHistory", cbr.getAllCallHistory);
    app.post("/cbr/createRequest", cbr.createRequest);
    app.post("/cbr/closeRequest", cbr.closeRequest);
    // app.post("/register", cbr.register);
    // app.post("/verifyUser", cbr.verifyUser);
    // // app.post("/verifyUserAlexa", cbr.verifyUserAlexa);
    // app.post("/forgotpassword", cbr.forgotpassword);
    // app.post("/updatepassword", cbr.updatepassword);
    // app.post("/webforgotpassword", cbr.Webforgotpassword);
    // app.post("/getOTP",authenticateUser, cbr.getOTP);


    
};