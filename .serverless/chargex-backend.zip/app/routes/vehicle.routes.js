module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const vehicles = require("../controllers/vehicle.controller.js");
  
    // register a new vehicle
    app.post("/vehicles", vehicles.create);
    // update register a new vehicle
    app.post("/updateRegisteredVehicle", vehicles.updateRegisteredVehicle);

    // map a vehicle model with charger type
    app.post("/vModel_Ctype", vehicles.vModel_CTypeMap);

    //get all registered vehicles
    app.get("/vehicles", vehicles.findAllVehicles);

    //get all registered vehicles by user
    app.get("/vehicles/getVehiclesByUserId/:id", vehicles.getVehiclesByUserId);

    // Retrieve all vehicleModels
    app.get("/vehicleModels/:brandId", vehicles.findAllVehicleModelsByBrandId);

    // Retrieve all vehicle Types
    app.get("/vehicleTypes", vehicles.findAllVehicleTypes);

    // Retrieve all vehicle model and charger type mapping
    app.get("/vModel_CTypes", vehicles.findAllvModel_CTypes);

    // Retrieve all PUBLISHED vehicle model 
    app.get("/publishedVModel", vehicles.findAllPublishedVModel);


    // publish with changes  vehicle model and charger type
    app.post("/publishVModel_CTYpe", vehicles.publishVModel_CTYpe);

    // moderate with changes vehicle model and charger type
    app.post("/moderateVModel_CTYpe", vehicles.moderateVModel_CTYpe);


    // publish vehicle model and charger type
    app.post("/publishVModel_CTYpeWithoutModify", vehicles.publishVModel_CTYpeWithoutModify);

    // moderate vehicle model and charger type
    app.post("/moderateVModel_CTYpeWithoutModify", vehicles.moderateVModel_CTYpeWithoutModify);

    // Delete a registered vehicle with id
    app.delete("/deleteRegisteredVehicle/:id", vehicles.deleteRegisteredVehicle);
    app.delete("/deleteC_Type_V_Model_Mapping/:id/:user_id", vehicles.deleteC_Type_V_Model_Mapping);
  
    
  };