const { checkToken } = require('../middleware/jwttoken')

module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const chargerBatches = require("../controllers/charger-batch.controller.js");
  
    // register a new vehicle
    app.post("/chargerBatch/create", chargerBatches.create);

    // update register a new vehicle
    app.post("/chargerBatch/update", chargerBatches.update);

    //get all registered vehicles
    app.get("/chargerBatch/getChargerBatches", chargerBatches.getChargerBatches);

    // Retrieve all vehicleModels

    app.get("/chargerBatch/getChargerBatchById/:id", chargerBatches.getChargerBatchById);

    // Delete a registered vehicle with id
    app.delete("/chargerBatch/delete/:id", chargerBatches.delete);
    
  };