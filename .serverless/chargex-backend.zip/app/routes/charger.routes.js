const { checkToken } = require('../middleware/jwttoken')
const { getUserDetails } = require('../middleware/authentication')

module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const chargers = require("../controllers/charger.controller.js");
  
    // register a new vehicle
    app.post("/charger/create", chargers.create);

    // update register a new vehicle
    app.post("/charger/update", chargers.update);
    app.post("/charger/dispatchChargers", chargers.dispatchChargers);

    //get all registered vehicles
    app.get("/charger/getChargers", chargers.getChargers);
    app.post("/charger/getChargersDynamicFilter", chargers.getChargersDynamicFilter);

    // Retrieve all vehicleModels
    app.get("/charger/getChargersByStationId/:id", chargers.getChargersByStationId);
    app.get("/charger/getChargersByMappedStationId/:id", chargers.getChargersByMappedStationId);

    app.get("/charger/getChargerById/:id", chargers.getChargerById);

    app.get("/charger/getChargerByDisplayId/:display_id", chargers.getChargerByDisplayId);

    app.get("/charger/getChargerBySerialNo/:srNo", chargers.getChargerBySerialNo);

    // Delete a registered vehicle with id
    app.delete("/charger/delete/:id", chargers.delete);

    // update register a new vehicle
    app.post("/charger/addChargerToStationMultiple", chargers.addChargerToStationMultiple);
    app.post("/charger/addChargerToStation", chargers.addChargerToStation);
    app.post("/charger/removeChargerFromStation", chargers.removeChargerFromStation);
    app.post("/charger/getChargersByClient_CPO_StationId", chargers.getChargersByClient_CPO_StationId);
    app.post("/charger/updateClientChargers", chargers.updateClientChargers);
    app.get("/charger/getAllChargersByUserId/:id", chargers.getAllChargersByUserId);

    app.get("/charger/getPlantChargers", chargers.getPlantChargers);
    app.get("/charger/getClientChargers/:user_id", getUserDetails, chargers.getClientChargers);
    app.get("/charger/getClientChargersNotMappedToAnyStation/:client_id", chargers.getClientChargersNotMappedToAnyStation);

    app.delete("/charger/deleteChargerFromClient/:id/:user_id", chargers.deleteChargerFromClient);

    
  };