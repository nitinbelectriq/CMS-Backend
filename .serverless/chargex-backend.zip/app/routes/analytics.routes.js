const { checkToken } = require('../middleware/jwttoken')
const { getUserDetails } = require('../middleware/authentication')

module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const analytics = require("../controllers/analytics.controller");
     
    
    //get transaction list
    app.post("/analytics/getTransactionList", analytics.getTransactionList);

    //get transaction list
    app.post("/analytics/getDurationList", analytics.getDurationList);

    
    
  };