const { authenticateUser } = require("../middleware/authentication.js");

module.exports = app => {
    const login = require("../controllers/login.controller.js");

    // login to get token
    app.post("/login", login.authorize);
    app.post("/register", login.register);
    app.post("/verifyUser", login.verifyUser);
    // app.post("/verifyUserAlexa", login.verifyUserAlexa);
    app.post("/forgotpassword", authenticateUser,login.forgotpassword);
    app.post("/updatepassword", login.updatepassword);
    app.post("/webforgotpassword", login.Webforgotpassword);
    app.post("/getOTP",authenticateUser, login.getOTP);
    app.post("/getOTPAnonymous", login.getOTPAnonymous);


    
};