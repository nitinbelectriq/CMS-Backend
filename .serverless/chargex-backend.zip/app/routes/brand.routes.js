module.exports = app => {
    const brands = require("../controllers/brand.controller.js");
  
    app.get("/brands", brands.findAll);
  
  };