const { checkToken } = require('../middleware/jwttoken')
module.exports = app => {
     
    const alexa = require("../controllers/alexa.controller.js");
  
     
     app.post("/alexa", alexa.authorize);
    
  };