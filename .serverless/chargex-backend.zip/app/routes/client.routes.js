const { checkToken } = require('../middleware/jwttoken')

module.exports = app => {
    // const customers = require("../controllers/customer.controller.js");
    const clients = require("../controllers/client.controller.js");
  
    // register a new vehicle
    app.post("/client/create", clients.create);
    // update register a new vehicle
    app.post("/client/update", clients.update);

    //get all registered vehicles
    app.get("/client/getClients", checkToken, clients.getClients);
    //get all registered vehicles
    app.get("/client/getClientsCW/:user_id", checkToken, clients.getClientsCW);

    app.get("/client/getActiveClientsCW/:user_id", clients.getActiveClientsCW);

    // Retrieve all vehicleModels
    app.get("/client/getClientById/:id", clients.getClientById);

    // Delete a registered vehicle with id
    app.delete("/client/delete/:id", clients.delete);
    
  };