
const environment={
    fileuploadpath:"",
    fileuploadtemppath:"",
    baseUrl:"",
    port:"",
    fileuploadUri:"",
    fileserverurl:""
}

module.exports={
    environment
    
}