module.exports = {
  secret: 'Belectriqcmssecretkey123344'
};