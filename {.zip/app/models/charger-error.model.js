const { sql, pool } = require("./db.js");
const _utility = require("../utility/_utility");

// constructor
const Client = function (client) {
  this.id = client.id,
    this.name = client.name,
    this.description = client.description,
    this.gst_no=client.gst_no,
    this.tin_no=client.tin_no,
    this.address = client.address,
    this.logoPath = client.logoPath,
    this.mobile = client.mobile,
    this.email = client.email,

    this.address1 = client.address1;
  this.address2 = client.address2;
  this.PIN = client.PIN;
  this.landmark = client.landmark;
  this.city_id = client.city_id;
  this.state_id = client.state_id;
  this.country_id = client.country_id;

  this.cp_name = client.cp_name,
    this.status = client.status,
    this.created_date = client.created_date,
    this.created_by = client.created_by,
    this.modify_date = client.modify_date,
    this.modify_by = client.modify_by
};

const ClientModuleMapping = function (clientModuleMapping) {
  this.id = clientModuleMapping.id,
  this.client_id = clientModuleMapping.client_id,
  this.booking_allowed = clientModuleMapping.booking_allowed,
  this.payment_allowed=clientModuleMapping.payment_allowed,
  this.reward_allowed=clientModuleMapping.reward_allowed,
  this.penalty_allowed=clientModuleMapping.penalty_allowed,
  this.otp_authentication=clientModuleMapping.otp_authentication,
  this.invoice_allowed=clientModuleMapping.invoice_allowed,
  this.status = clientModuleMapping.status,
  this.created_date = clientModuleMapping.created_date,
  this.created_by = clientModuleMapping.created_by,
  this.modify_date = clientModuleMapping.modify_date,
  this.modified_by = clientModuleMapping.modified_by
};

Client.create = async (newClient, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt = `insert into client_mst (name,description,gst_no,tin_no,
    address1  ,address2  ,PIN  ,landmark  ,city_id ,state_id ,country_id ,
    logoPath,  mobile,email,cp_name,status,created_date,createdby )
    VALUES ('${newClient.name}','${newClient.description}','${newClient.gst_no}','${newClient.tin_no}',
    '${newClient.address1}','${newClient.address2}',${newClient.PIN},'${newClient.landmark}',${newClient.city_id},${newClient.state_id},${newClient.country_id},
    '${newClient.logoPath}',  '${newClient.mobile}','${newClient.email}','${newClient.cp_name}',
    '${newClient.status}',?,${newClient.created_by}) `;

  try {
    resp = await pool.query(stmt,[datetime]);

    final_res = {
      status: resp.insertId > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.insertId > 0 ? 'SUCCESS' : 'FAILED',
      count : 1,
      data: [{id:resp.insertId}]
    }
  } catch (err) {
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

  // sql.query(stmt, (err, res) => {

  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   result(null, { id: res.insertId, ...newClient });
  // });
};

Client.update = async (newClient, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt = `update client_mst set 
  name = '${newClient.name}',description = '${newClient.description}',gst_no = '${newClient.gst_no}',tin_no = '${newClient.tin_no}',
  address1='${newClient.address1}'  ,address2 ='${newClient.address2}' ,PIN =${newClient.PIN} ,
  landmark ='${newClient.landmark}' ,city_id=${newClient.city_id} ,state_id=${newClient.state_id} ,
  country_id=${newClient.country_id} ,
  logoPath = '${newClient.logoPath}',mobile = '${newClient.mobile}',email = '${newClient.email}',
  cp_name = '${newClient.cp_name}',status = '${newClient.status}',
  modifyby = ${newClient.modify_by},modify_date = ? 
  where id =  ${newClient.id}`;
  try {
    resp = await pool.query(stmt,[datetime]);

    final_res = {
      status: resp.affectedRows > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.affectedRows > 0 ? 'SUCCESS' : 'FAILED',
      count : 1,
      data: [{id:newClient.id}]
    }
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

  // sql.query(stmt, (err, res) => {

  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   result(null, { id: res.insertId, ...newClient });
  // });
};


Client.getClients = result => {

  let stmt = `select cm.id,  cm.name,cm.description,
    cm.address1  ,cm.address2  ,cm.PIN  ,cm.landmark  ,
    cm.city_id , city.name as city_name, cm.state_id, sm.name as state_name, cm.country_id, country.name as country_name,
    cm.logoPath,cm.mobile,cm.email,cm.cp_name,cm.gst_no,cm.tin_no,cm.status,cm.created_date,cm.createdby,cm.modifyby,cm.modify_date
    from client_mst cm inner join city_mst city on cm.city_id = city.id
    inner join state_mst sm on cm.state_id = sm.id
    inner join country_mst country on cm.country_id = country.id
    where cm.status <> 'D'
    order by cm.id desc`;

  sql.query(stmt, (err, res) => {

    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};


Client.getClientsCW = async (login_id,result) => {

  let stmt='';
  let clientAndRoleDetails = await _utility.getClientIdAndRoleByUserId(login_id);
  let client_id = clientAndRoleDetails.data[0].client_id;
  // let role_code = clientAndRoleDetails.data[0].role_code;
  let isSA =  ( clientAndRoleDetails.data.filter(x=>x.role_code=='SA').length > 0) ? true : false;

  if(isSA){
    stmt = `select cm.id,  cm.name,cm.description,
    cm.address1  ,cm.address2  ,cm.PIN  ,cm.landmark  ,
    cm.city_id , city.name as city_name, cm.state_id, sm.name as state_name, cm.country_id, country.name as country_name,
    cm.logoPath,cm.mobile,cm.email,cm.cp_name,cm.gst_no,cm.tin_no,cm.status,cm.created_date,cm.createdby,cm.modifyby,cm.modify_date
    from client_mst cm inner join city_mst city on cm.city_id = city.id
    inner join state_mst sm on cm.state_id = sm.id
    inner join country_mst country on cm.country_id = country.id
    where cm.status <> 'D'
    order by cm.id desc`;
  }else{
    stmt = `select cm.id,  cm.name,cm.description,
    cm.address1  ,cm.address2  ,cm.PIN  ,cm.landmark  ,
    cm.city_id , city.name as city_name, cm.state_id, sm.name as state_name, cm.country_id, country.name as country_name,
    cm.logoPath,cm.mobile,cm.email,cm.cp_name,cm.gst_no,cm.tin_no,cm.status,cm.created_date,cm.createdby,cm.modifyby,cm.modify_date
    from client_mst cm inner join city_mst city on cm.city_id = city.id
    inner join state_mst sm on cm.state_id = sm.id
    inner join country_mst country on cm.country_id = country.id
    where cm.status <> 'D' and cm.id = ${client_id}
    order by cm.id desc`;
  }

  // stmt = `select cm.id,  cm.name,cm.description,
  //   cm.address1  ,cm.address2  ,cm.PIN  ,cm.landmark  ,
  //   cm.city_id , city.name as city_name, cm.state_id, sm.name as state_name, cm.country_id, country.name as country_name,
  //   cm.logoPath,cm.mobile,cm.email,cm.cp_name,cm.status,cm.created_date,cm.createdby,cm.modifyby,cm.modify_date
  //   from client_mst cm inner join city_mst city on cm.city_id = city.id
  //   inner join state_mst sm on cm.state_id = sm.id
  //   inner join country_mst country on cm.country_id = country.id
  //   where cm.status <> 'D'
  //   order by cm.id desc`;

  sql.query(stmt, (err, res) => {

    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

Client.getActiveClientsCW = async (login_id,result) => {

  let stmt='';
  let clientAndRoleDetails = await _utility.getClientIdAndRoleByUserId(login_id);
  let client_id = clientAndRoleDetails.data[0].client_id;
  // let role_code = clientAndRoleDetails.data[0].role_code;
  let isSA =  ( clientAndRoleDetails.data.filter(x=>x.role_code=='SA').length > 0) ? true : false;

  if(isSA){
    stmt = `select cm.id,  cm.name,cm.description,
    cm.address1  ,cm.address2  ,cm.PIN  ,cm.landmark  ,
    cm.city_id , city.name as city_name, cm.state_id, sm.name as state_name, cm.country_id, country.name as country_name,
    cm.logoPath,cm.mobile,cm.email,cm.cp_name,cm.gst_no,cm.tin_no,cm.status,cm.created_date,cm.createdby,cm.modifyby,cm.modify_date
    from client_mst cm inner join city_mst city on cm.city_id = city.id
    inner join state_mst sm on cm.state_id = sm.id
    inner join country_mst country on cm.country_id = country.id
    where cm.status = 'Y'
    order by cm.id desc`;
  }else{
    stmt = `select cm.id,  cm.name,cm.description,
    cm.address1  ,cm.address2  ,cm.PIN  ,cm.landmark  ,
    cm.city_id , city.name as city_name, cm.state_id, sm.name as state_name, cm.country_id, country.name as country_name,
    cm.logoPath,cm.mobile,cm.email,cm.cp_name,cm.gst_no,cm.tin_no,cm.status,cm.created_date,cm.createdby,cm.modifyby,cm.modify_date
    from client_mst cm inner join city_mst city on cm.city_id = city.id
    inner join state_mst sm on cm.state_id = sm.id
    inner join country_mst country on cm.country_id = country.id
    where cm.status = 'Y' and cm.id = ${client_id}
    order by cm.id desc`;
  }

  sql.query(stmt, (err, res) => {

    if (err) {
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

Client.getClientById = (id, result) => {

  let stmt = `select cm.id,  cm.name,cm.description,
      cm.address1  ,cm.address2  ,cm.PIN  ,cm.landmark  ,
      cm.city_id , city.name as city_name, cm.state_id, sm.name as state_name, cm.country_id, country.name as country_name,
      cm.logoPath,cm.mobile,cm.email,cm.cp_name,cm.gst_no,cm.tin_no,cm.status,cm.created_date,cm.createdby,cm.modifyby,cm.modify_date
      from client_mst cm inner join city_mst city on cm.city_id = city.id
      inner join state_mst sm on cm.state_id = sm.id
      inner join country_mst country on cm.country_id = country.id
      WHERE cm.id = ? and cm.status = 'Y'`;
  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

Client.delete = (id, result) => {

  let stmt = `Update client_mst set status = 'D' WHERE id = ?`;
  sql.query(stmt, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};


ClientModuleMapping.createClientModuleMapping = async (params, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt = `insert into client_module_config (client_id , booking_allowed, 
    payment_allowed,reward_allowed,penalty_allowed,otp_authentication,invoice_allowed,
    status,created_date,created_by ) 
  values (${params.client_id},${params.booking_allowed},${params.payment_allowed},
    ${params.reward_allowed},${params.penalty_allowed},${params.otp_authentication},
    ${params.invoice_allowed},'${params.status}',?,${params.created_by});`;

  try {
    resp = await pool.query(stmt,[datetime]);

    final_res = {
      status: resp.insertId > 0 ? true : false,
      err_code: `ERROR : 0`,
      message: resp.insertId > 0 ? 'SUCCESS' : 'FAILED',
      count : 1,
      data: [{id:resp.insertId}]
    }
  } catch (err) {
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }

  
};

ClientModuleMapping.updateClientModuleMapping = async (params, result) => {
  var datetime = new Date();
  let final_res;
  let resp;

  let stmt = `update client_module_config set 
  client_id =${params.client_id} , booking_allowed = ${params.booking_allowed}, 
  payment_allowed =${params.payment_allowed} ,reward_allowed = ${params.reward_allowed},
  penalty_allowed = ${params.penalty_allowed},otp_authentication = ${params.otp_authentication},
  invoice_allowed = ${params.invoice_allowed},
  status = '${params.status}', modified_by = ${params.modified_by},modified_date = ? 
  where id =  ${params.id}`;
  try {
    
    resp = await pool.query(stmt,[datetime]);
    if(resp.affectedRows > 0){
      final_res = {
        status: true,
        err_code: `ERROR : 0`,
        message: 'SUCCESS' ,
        count : 1,
        data: [{id: params.id}]
      }
    }else{
      final_res = {
        status:  false,
        err_code: `ERROR : 1`,
        message: 'DATA_NOT_FOUND',
        count : 0,
        data: [{id: params.id}]
      }
    }
   
  } catch (err) {
    
    final_res = {
      status: false,
      err_code: `ERROR : ${err.code}`,
      message: `ERROR : ${err.message}`,
      count : 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }
};


ClientModuleMapping.getClientModuleMapping = async (result) => {

  let resp;
  let final_res;

  let stmt = `select cmc.client_id , cmc.booking_allowed, cmc.payment_allowed, 
  cmc.reward_allowed,cmc.penalty_allowed,cmc.otp_authentication,cmc.invoice_allowed,
  cmc.status,cmc.created_date,cmc.created_by , cm.id,  cm.name,cm.description
  from client_module_config cmc inner join client_mst cm on cmc.client_id=cm.id and cm.status='Y'
  where cmc.status <> 'D'
  order by cmc.id desc`;

try {
  resp = await pool.query(stmt);
  
  if (resp.length > 0) {
    final_res = {
      status: true,
      message:  'DATA_FOUND' ,
      count: resp.length,
      data: resp
    }
  }else{
    final_res = {
      status: false,
      message:  'DATA_NOT_FOUND',
      count: 0,
      data: []
    }
  }

} catch (err) {
  final_res = {
    status: false,
    message: "ERROR",
    count: 0,
    data: []
  }
} finally {
  result(null, final_res);
}

  // sql.query(stmt, (err, res) => {

  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   if (res.length) {
  //     result(null, res);
  //     return;
  //   }

  //   // not found Customer with the id
  //   result({ kind: "not_found" }, null);
  // });
};

ClientModuleMapping.getClientModuleMappingById = async (id,result) => {

  let stmt='';
  let resp;
  let final_res;
  
    stmt = `select cmc.client_id , cmc.booking_allowed, cmc.payment_allowed, 
    cmc.reward_allowed,cmc.penalty_allowed,cmc.otp_authentication,cmc.invoice_allowed,
    cmc.status,cmc.created_date,cmc.created_by , cm.id,  cm.name,cm.description
    from client_module_config cmc inner join client_mst cm on cmc.client_id=cm.id and cm.status='Y'
    where cmc.id = ? `;
   
  try {
    resp = await pool.query(stmt,[id]);
    
    if (resp.length > 0) {
      final_res = {
        status: true,
        message:  'DATA_FOUND' ,
        count: resp.length,
        data: resp
      }
    }else{
      final_res = {
        status: false,
        message:  'DATA_NOT_FOUND',
        count: 0,
        data: []
      }
    }

  } catch (err) {
    final_res = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }


  // sql.query(stmt, (err, res) => {

  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   if (res.length) {
  //     result(null, res);
  //     return;
  //   }

  //   // not found Customer with the id
  //   result({ kind: "not_found" }, null);
  // });
};

ClientModuleMapping.getClientModuleMappingByClientId = async (client_id,result) => {

  let stmt='';
  let resp;
  let final_res;
  
    stmt = `select cmc.client_id , cmc.booking_allowed, cmc.payment_allowed, 
    cmc.reward_allowed,cmc.penalty_allowed,cmc.otp_authentication,cmc.invoice_allowed,
    cmc.status,cmc.created_date,cmc.created_by , cm.id,  cm.name,cm.description
    from client_module_config cmc inner join client_mst cm on cmc.client_id=cm.id and cm.status='Y'
    where cmc.client_id = ? and cmc.status='Y'`;
   
  try {
    resp = await pool.query(stmt,[client_id]);
    
    if (resp.length > 0) {
      final_res = {
        status: true,
        message:  'DATA_FOUND' ,
        count: resp.length,
        data: resp
      }
    }else{
      final_res = {
        status: false,
        message:  'DATA_NOT_FOUND',
        count: 0,
        data: []
      }
    }

  } catch (err) {
    
    final_res = {
      status: false,
      message: "ERROR",
      count: 0,
      data: []
    }
  } finally {
    result(null, final_res);
  }


  // sql.query(stmt, (err, res) => {

  //   if (err) {
  //     result(err, null);
  //     return;
  //   }

  //   if (res.length) {
  //     result(null, res);
  //     return;
  //   }

  //   // not found Customer with the id
  //   result({ kind: "not_found" }, null);
  // });
};

module.exports = {
  Client: Client,
  ClientModuleMapping: ClientModuleMapping
};